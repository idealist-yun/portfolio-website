"""Route the lab's /api/* calls to lab.actions (mirrors lab/server.py)."""
import json
from pathlib import Path

from idd_agent_sim.lab import actions

ROOT = Path("/home/pyodide/idd")


def handle(method, path, body_json):
    try:
        if method == "GET":
            if path == "/api/state":
                return 200, json.dumps(actions.lab_state(ROOT), ensure_ascii=False)
            if path.startswith("/api/runs/"):
                run_id = path[len("/api/runs/"):]
                try:
                    return 200, json.dumps(actions.load_lab_run(ROOT, run_id), ensure_ascii=False)
                except ValueError as error:
                    return 404, json.dumps({"error": str(error)})
            return 404, json.dumps({"error": "not found: " + path})
        payload = json.loads(body_json or "{}")
        if path == "/api/agents":
            data = actions.create_agent(ROOT, payload)
        elif path == "/api/scenarios":
            data = actions.create_scenario(ROOT, payload)
        elif path == "/api/run":
            data = actions.run_lab_experiment(ROOT, payload)
        else:
            return 404, json.dumps({"error": "not found: " + path})
        return 200, json.dumps(data, ensure_ascii=False)
    except ValueError as error:
        return 400, json.dumps({"error": str(error)}, ensure_ascii=False)
    except Exception as error:  # surface unexpected errors to the UI toast
        return 500, json.dumps({"error": "Engine error: " + repr(error)})
