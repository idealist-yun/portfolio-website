import argparse

from .experiment import run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Run an IDD agent simulation experiment.")
    parser.add_argument(
        "config",
        nargs="?",
        default="pipelines/baseline.yaml",
        help="Path to an experiment pipeline YAML file.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Directory for events.jsonl, summary.json, and caregiver_report.txt.",
    )
    args = parser.parse_args()

    result = run_experiment(args.config, args.output_dir)
    print(result.simulation.summary())
    print(f"events={result.events_path}")
    print(f"summary={result.summary_path}")
    print(f"caregiver_report={result.caregiver_report_path}")


if __name__ == "__main__":
    main()
