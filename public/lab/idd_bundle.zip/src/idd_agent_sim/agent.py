from dataclasses import dataclass

from .profiles import FunctionalProfile
from .testbed.scenario import ScenarioStep


@dataclass(frozen=True)
class Agent:
    """IDD simulation agent initialized from a functional profile."""

    agent_id: str
    profile: FunctionalProfile

    @classmethod
    def from_config(cls, config: dict) -> "Agent":
        return cls(
            agent_id=str(config["id"]),
            profile=FunctionalProfile.from_config(config),
        )

    def unmet_need_for(self, step: ScenarioStep, domain: str) -> float:
        capacity = min(self.profile.self_sufficiency, self.profile.functional_capacity(domain))
        return max(0.0, step.demand - capacity)

    def can_complete(self, step: ScenarioStep, domain: str) -> bool:
        return self.unmet_need_for(step, domain) == 0.0
