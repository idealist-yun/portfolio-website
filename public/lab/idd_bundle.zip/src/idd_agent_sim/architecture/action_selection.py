from dataclasses import dataclass

from idd_agent_sim.architecture.perception import Observation
from idd_agent_sim.architecture.planning import AdjustedPlan
from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints
from idd_agent_sim.architecture.support import SupportDecision


@dataclass(frozen=True)
class ActionDecision:
    action_type: str
    completed: bool
    unmet_need: float
    confidence: float
    explanation: str


class ActionSelectionModule:
    def select(
        self,
        observation: Observation,
        plan: AdjustedPlan,
        constraints: IDDProfileConstraints,
        support: SupportDecision,
    ) -> ActionDecision:
        sequencing_penalty = max(0.0, 1 - constraints.sequencing_tolerance) * 0.1
        unmet_need = max(
            0.0,
            observation.perceived_demand + sequencing_penalty - constraints.independent_capacity,
        )

        if unmet_need == 0:
            return ActionDecision(
                action_type="independent_completion",
                completed=True,
                unmet_need=0.0,
                confidence=constraints.independent_capacity,
                explanation="The adjusted plan was completed independently.",
            )

        if support.closes_gap and support.partner is not None:
            return ActionDecision(
                action_type="supported_completion",
                completed=True,
                unmet_need=unmet_need,
                confidence=min(1.0, constraints.independent_capacity + support.available_support),
                explanation=f"Support from {support.partner} closed the execution gap.",
            )

        if plan.support_primed:
            return ActionDecision(
                action_type="support_request_blocked",
                completed=False,
                unmet_need=unmet_need,
                confidence=constraints.independent_capacity,
                explanation="The agent requested support, but available support did not close the gap.",
            )

        return ActionDecision(
            action_type="execution_bottleneck",
            completed=False,
            unmet_need=unmet_need,
            confidence=constraints.independent_capacity,
            explanation="Task demand exceeded the agent's independent execution capacity.",
        )

