from dataclasses import dataclass, replace

from idd_agent_sim.agent import Agent
from idd_agent_sim.architecture.action_selection import ActionDecision, ActionSelectionModule
from idd_agent_sim.architecture.character import (
    CharacterGrowthModule,
    CharacterState,
    InsightNote,
    ScenarioExperience,
)
from idd_agent_sim.architecture.cognition import CognitionModule, LongTermRecord
from idd_agent_sim.architecture.emotion import EmotionState
from idd_agent_sim.architecture.functional_state import FunctionalState
from idd_agent_sim.architecture.humanoid_state import HumanoidState
from idd_agent_sim.architecture.learning import LearningSignal, LearningUpdateModule
from idd_agent_sim.architecture.memory import (
    AgentMemory,
    MemoryTrace,
    ReflectionNote,
    ScratchState,
    SpatialMemoryTrace,
)
from idd_agent_sim.architecture.perception import Observation, PerceptionModule
from idd_agent_sim.architecture.planning import AdjustedPlan, PlanningModule, ScenarioPlan
from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints
from idd_agent_sim.profiles import DimensionalGap
from idd_agent_sim.architecture.reflection import ReflectionModule
from idd_agent_sim.architecture.retrieval import ContextRetrievalModule, RetrievedContext
from idd_agent_sim.architecture.support import SupportDecision, SupportSeekingModule
from idd_agent_sim.environment import EnvironmentEngine, EnvironmentFeedback, EnvironmentState
from idd_agent_sim.skills import Skill, SkillLibrary, TaskContext
from idd_agent_sim.testbed import Scenario, ScenarioStep
from idd_agent_sim.world import World


@dataclass(frozen=True)
class AgentStepResult:
    observation: Observation
    constraints: IDDProfileConstraints
    scenario_plan: ScenarioPlan
    adjusted_plan: AdjustedPlan
    support: SupportDecision
    decision: ActionDecision
    environment_feedback: EnvironmentFeedback
    retrieved_context: RetrievedContext
    retrieved_skills: list[Skill]
    emotion_level: float
    emotional_shift: float
    replan_triggered: bool
    replan_count: int
    reflection: ReflectionNote
    learning_signal: LearningSignal
    loop_stages: list[str]
    humanoid_state: HumanoidState
    functional_state: FunctionalState
    dimensional_gaps: tuple[DimensionalGap, ...] = ()

    @property
    def exceeded_dimensions(self) -> tuple[str, ...]:
        return tuple(gap.dimension for gap in self.dimensional_gaps if gap.exceeded)

    @property
    def binding_dimension(self) -> str:
        exceeded = [gap for gap in self.dimensional_gaps if gap.exceeded]
        if not exceeded:
            return ""
        return max(exceeded, key=lambda gap: gap.gap).dimension


@dataclass(frozen=True)
class ScenarioConclusion:
    """Personality-system output produced after one scenario finishes."""

    scenario_id: str
    insight: InsightNote
    character: CharacterState
    new_growth_notes: tuple[str, ...]
    long_term_records: tuple[LongTermRecord, ...]


class IDDAgentArchitecture:
    """Profile-constrained agent loop for one IDD agent."""

    def __init__(
        self,
        agent: Agent,
        skills: SkillLibrary,
        memory: AgentMemory | None = None,
        emotion: EmotionState | None = None,
        humanoid_state: HumanoidState | None = None,
        functional_state: FunctionalState | None = None,
        environment_state: EnvironmentState | None = None,
    ) -> None:
        self.agent = agent
        self.skills = skills
        self.memory = memory or AgentMemory()
        self.emotion = emotion or EmotionState()
        self.humanoid_state = humanoid_state or HumanoidState()
        self.functional_state = functional_state or FunctionalState.from_profile(agent.profile)
        self.environment_state = environment_state
        self.environment = EnvironmentEngine()
        self.perception = PerceptionModule()
        self.retrieval = ContextRetrievalModule()
        self.planning = PlanningModule()
        self.reflection = ReflectionModule()
        self.learning = LearningUpdateModule()
        self.support = SupportSeekingModule()
        self.action_selection = ActionSelectionModule()
        self.character = CharacterState.from_profile_config(agent.profile.character)
        self.cognition = CognitionModule()
        self.character_growth = CharacterGrowthModule()
        self.long_term_records: list[LongTermRecord] = []
        self.insights: list[InsightNote] = []
        self._scenario_plans: dict[str, ScenarioPlan] = {}

    def execute_step(
        self,
        scenario: Scenario,
        step: ScenarioStep,
        world: World,
    ) -> AgentStepResult:
        self.humanoid_state = self.humanoid_state.with_support_availability(
            world.support_availability
        )
        if self.environment_state is None:
            self.environment_state = world.environment_for(self.agent.profile)
        constraints = self.humanoid_state.apply_to_constraints(
            IDDProfileConstraints.from_profile(
                self.agent.profile,
                scenario.domain,
                required_skill=step.required_skill,
            )
        )
        scenario_plan = self._scenario_plan_for(scenario, constraints)
        dimensional_gaps = self.agent.profile.dimensional_gaps(step.demand_dimensions)
        exceeded_dimensions = tuple(
            gap.dimension for gap in dimensional_gaps if gap.exceeded
        )
        loop_stages: list[str] = []
        loop_stages.append("long_plan")
        observation = self.perception.observe(step, constraints, self.environment_state)
        loop_stages.append("perceive")
        skill_context = TaskContext(
            task_description=f"{scenario.description} {step.label}",
            domain=scenario.domain,
            required_skill=step.required_skill,
            available_affordances=self._available_affordances(world),
            observed_cues=tuple(observation.visible_cues),
            missed_cues=tuple(observation.missed_cues),
            emotion_level=self.emotion.level,
            accessible_skill_names=self.agent.profile.accessible_skill_names(
                scenario.domain,
                support_available=world.support_availability > 0,
                state_pressure=self.humanoid_state.state_pressure,
            ),
        )
        retrieved_context = self.retrieval.retrieve(
            self.skills,
            skill_context,
            self.memory.retrieve_bundle(
                scenario.scenario_id,
                step.step_id,
                required_objects=step.required_objects,
                required_people=step.required_people,
            ),
        )
        loop_stages.append("retrieve")
        baseline_plan = self.planning.baseline_plan(observation, scenario_plan)
        adjusted_plan = self.planning.adjust_plan(
            baseline_plan,
            observation,
            constraints,
            retrieved_context,
            scenario_plan,
        )
        loop_stages.append("plan")
        # Same effective demand the action-selection module uses, so the
        # support decision sees the true gap (including sequencing penalty).
        sequencing_penalty = max(0.0, 1 - constraints.sequencing_tolerance) * 0.1
        unmet_need = max(
            0.0,
            observation.perceived_demand
            + sequencing_penalty
            - constraints.independent_capacity,
        )
        exceeded_gaps = [gap for gap in dimensional_gaps if gap.exceeded]
        binding_dimension = (
            max(exceeded_gaps, key=lambda gap: gap.gap).dimension
            if exceeded_gaps
            else ""
        )
        support = self.support.decide(
            self.agent.profile,
            world,
            unmet_need,
            adjusted_plan.support_primed,
            self.humanoid_state,
            retrieved_context.memory_traces,
            domain=scenario.domain,
            binding_dimension=binding_dimension,
        )
        decision = self.action_selection.select(observation, adjusted_plan, constraints, support)
        loop_stages.append("act")
        self.emotion, emotional_shift, replan_triggered = self.emotion.update(decision, constraints)
        replan_count = 0
        if replan_triggered:
            adjusted_plan = self.planning.replan_after_emotional_shift(
                adjusted_plan,
                emotional_shift,
            )
            replan_count = 1
            loop_stages.append("replan")
            support = self.support.decide(
                self.agent.profile,
                world,
                unmet_need,
                adjusted_plan.support_primed,
                self.humanoid_state,
                retrieved_context.memory_traces,
                domain=scenario.domain,
                binding_dimension=binding_dimension,
            )
            decision = self.action_selection.select(
                observation,
                adjusted_plan,
                constraints,
                support,
            )
        environment_feedback, self.environment_state = self.environment.apply_action(
            step,
            decision,
            self.environment_state,
            support.partner,
        )
        loop_stages.append("environment")
        if decision.unmet_need > 0 and exceeded_dimensions:
            decision = replace(
                decision,
                explanation=(
                    f"{decision.explanation} Demand exceeded profile capacity on: "
                    f"{', '.join(exceeded_dimensions)}."
                ),
            )
        if environment_feedback.blocked and decision.completed:
            decision = ActionDecision(
                action_type="environment_blocked",
                completed=False,
                unmet_need=max(decision.unmet_need, 0.01),
                confidence=decision.confidence,
                explanation=environment_feedback.explanation,
            )
        reflection = self.reflection.reflect(
            scenario_id=scenario.scenario_id,
            step_id=step.step_id,
            observation=observation,
            decision=decision,
            environment_feedback=environment_feedback,
            support=support,
            emotional_shift=emotional_shift,
        )
        loop_stages.append("reflect")
        self.humanoid_state = self.humanoid_state.update_after_action(
            decision,
            constraints,
            support.partner,
        )
        previous_adaptive = self.functional_state.adaptive_estimate_for(scenario.domain)
        previous_support_need = self.functional_state.support_need_for(scenario.domain)
        self.functional_state = self.functional_state.update_after_step(
            scenario_id=scenario.scenario_id,
            step_id=step.step_id,
            domain=scenario.domain,
            action_type=decision.action_type,
            completed=decision.completed,
            unmet_need=decision.unmet_need,
            state_pressure=self.humanoid_state.state_pressure,
            missed_cues=tuple(observation.missed_cues),
            support_partner=support.partner,
        )
        learning_signal = self.learning.signal(
            decision=decision,
            environment_feedback=environment_feedback,
            reflection=reflection,
            previous_adaptive=previous_adaptive,
            updated_adaptive=self.functional_state.adaptive_estimate_for(scenario.domain),
            previous_support_need=previous_support_need,
            updated_support_need=self.functional_state.support_need_for(scenario.domain),
        )
        self.memory.record(
            MemoryTrace(
                scenario_id=scenario.scenario_id,
                step_id=step.step_id,
                action_type=decision.action_type,
                completed=decision.completed,
                emotion_level=self.emotion.level,
                explanation=decision.explanation,
                support_partner=support.partner,
            )
        )
        self.memory.record_reflection(reflection)
        self.memory.record_spatial(
            SpatialMemoryTrace(
                scenario_id=scenario.scenario_id,
                step_id=step.step_id,
                visible_objects=tuple(observation.visible_objects),
                visible_people=tuple(observation.visible_people),
                blocked_objects=tuple(observation.blocked_objects),
                environment_cues=tuple(observation.environment_cues),
            )
        )
        self.memory.update_scratch(
            ScratchState(
                step_id=step.step_id,
                current_plan=adjusted_plan.intended_action,
                emotion_level=self.emotion.level,
                support_partner=support.partner,
            )
        )
        loop_stages.append("update")

        return AgentStepResult(
            observation=observation,
            constraints=constraints,
            scenario_plan=scenario_plan,
            adjusted_plan=adjusted_plan,
            support=support,
            decision=decision,
            environment_feedback=environment_feedback,
            retrieved_context=retrieved_context,
            retrieved_skills=retrieved_context.skills,
            emotion_level=self.emotion.level,
            emotional_shift=emotional_shift,
            replan_triggered=replan_triggered,
            replan_count=replan_count,
            reflection=reflection,
            learning_signal=learning_signal,
            loop_stages=loop_stages,
            humanoid_state=self.humanoid_state,
            functional_state=self.functional_state,
            dimensional_gaps=dimensional_gaps,
        )

    def conclude_scenario(self, scenario: Scenario) -> ScenarioConclusion:
        """Run the personality system after a scenario: cognition archive,
        Insight summary, and chain-like character growth."""
        scenario_traces = [
            trace
            for trace in self.memory.short_term
            if trace.scenario_id == scenario.scenario_id
        ]
        scenario_reflections = [
            note
            for note in self.memory.reflections
            if note.scenario_id == scenario.scenario_id
        ]
        new_records = self.cognition.archive(self.character, scenario_traces)
        self.long_term_records.extend(new_records)

        experience = ScenarioExperience.from_traces(
            scenario.scenario_id,
            scenario_traces,
            scenario_reflections,
        )
        insight = self.character_growth.insight(self.character, experience)
        self.insights.append(insight)

        previous_growth_length = len(self.character.growth_log)
        self.character = self.character_growth.grow(
            self.character,
            experience,
            fatigue=self.humanoid_state.fatigue,
        )
        return ScenarioConclusion(
            scenario_id=scenario.scenario_id,
            insight=insight,
            character=self.character,
            new_growth_notes=self.character.growth_log[previous_growth_length:],
            long_term_records=tuple(new_records),
        )

    def _available_affordances(self, world: World) -> frozenset[str]:
        affordances: set[str] = set(
            self.environment_state.affordances() if self.environment_state else ()
        )
        if world.support_availability > 0 and self.agent.profile.support:
            affordances.add("support_available")
        return frozenset(affordances)

    def _scenario_plan_for(
        self,
        scenario: Scenario,
        constraints: IDDProfileConstraints,
    ) -> ScenarioPlan:
        if scenario.scenario_id not in self._scenario_plans:
            self._scenario_plans[scenario.scenario_id] = self.planning.scenario_plan(
                scenario,
                constraints,
            )
        return self._scenario_plans[scenario.scenario_id]
