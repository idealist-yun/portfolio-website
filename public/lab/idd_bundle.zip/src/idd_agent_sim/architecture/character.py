"""Evolving Agents-style five-dimension character system.

Implements the proposal's Character Growth design: a five-dimension character
structure (basic information, current state, traits, conflict, preference)
with a sequential chain update across the four non-static dimensions, plus an
Insight submodule that summarizes scenario experience against the complete
character structure.

All updates are deterministic, bounded scaffold rules. They are not clinical
personality measurements.
"""

from dataclasses import dataclass, field, replace
from typing import Any

from idd_agent_sim.architecture.memory import MemoryTrace, ReflectionNote


BIG_FIVE_TRAITS = (
    "openness",
    "conscientiousness",
    "extraversion",
    "agreeableness",
    "neuroticism",
)


def _clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class CharacterState:
    """Five-dimension character structure from the proposal."""

    basic_information: dict[str, Any] = field(default_factory=dict)
    current_state: dict[str, Any] = field(default_factory=dict)
    traits: dict[str, float] = field(default_factory=dict)
    conflicts: dict[str, float] = field(default_factory=dict)
    preferences: dict[str, Any] = field(default_factory=dict)
    growth_log: tuple[str, ...] = ()

    @classmethod
    def from_profile_config(cls, character: dict[str, Any]) -> "CharacterState":
        traits = {
            name: _clamp(float(value))
            for name, value in character.get("traits", {}).items()
        }
        for trait in BIG_FIVE_TRAITS:
            traits.setdefault(trait, 0.5)
        return cls(
            basic_information=dict(character.get("basic_information", {})),
            current_state=dict(character.get("current_state", {})),
            traits=traits,
            conflicts={
                name: _clamp(float(value))
                for name, value in character.get("conflicts", {}).items()
            },
            preferences=dict(character.get("preferences", {})),
        )

    def trait(self, name: str) -> float:
        return _clamp(float(self.traits.get(name, 0.5)))


@dataclass(frozen=True)
class ScenarioExperience:
    """Aggregated behavioral/emotional evidence from one scenario run."""

    scenario_id: str
    step_count: int
    completed_count: int
    supported_count: int
    mean_emotion: float
    peak_emotion: float
    reflection_count: int
    support_partners: tuple[str, ...]

    @property
    def completion_rate(self) -> float:
        return self.completed_count / self.step_count if self.step_count else 0.0

    @property
    def support_reliance(self) -> float:
        return self.supported_count / self.step_count if self.step_count else 0.0

    @classmethod
    def from_traces(
        cls,
        scenario_id: str,
        traces: list[MemoryTrace],
        reflections: list[ReflectionNote],
    ) -> "ScenarioExperience":
        emotions = [trace.emotion_level for trace in traces]
        return cls(
            scenario_id=scenario_id,
            step_count=len(traces),
            completed_count=sum(1 for trace in traces if trace.completed),
            supported_count=sum(
                1 for trace in traces if trace.action_type == "supported_completion"
            ),
            mean_emotion=sum(emotions) / len(emotions) if emotions else 3.5,
            peak_emotion=max(emotions) if emotions else 3.5,
            reflection_count=len(reflections),
            support_partners=tuple(
                dict.fromkeys(
                    trace.support_partner
                    for trace in traces
                    if trace.support_partner is not None
                )
            ),
        )


@dataclass(frozen=True)
class InsightNote:
    """Holistic scenario summary referencing the complete character structure."""

    scenario_id: str
    summary: str
    referenced_dimensions: tuple[str, ...]
    completion_rate: float
    support_reliance: float
    mean_emotion: float
    growth_notes: tuple[str, ...] = ()


class CharacterGrowthModule:
    """Insight generation and chain-like character growth updates."""

    def insight(
        self,
        character: CharacterState,
        experience: ScenarioExperience,
    ) -> InsightNote:
        fragments: list[str] = []
        setting = character.basic_information.get("setting")
        if setting:
            fragments.append(f"In the {setting} context")
        fragments.append(
            f"completed {experience.completed_count}/{experience.step_count} steps"
        )
        if experience.support_reliance > 0:
            partners = ", ".join(experience.support_partners) or "support partners"
            fragments.append(
                f"relied on {partners} for "
                f"{experience.support_reliance:.0%} of steps"
            )
        else:
            fragments.append("worked without direct support")
        if experience.peak_emotion >= 5.0:
            fragments.append("with a notable emotional peak")
        dominant_conflict = self._dominant_conflict(character)
        if dominant_conflict:
            fragments.append(f"touching the '{dominant_conflict}' conflict")

        return InsightNote(
            scenario_id=experience.scenario_id,
            summary=", ".join(fragments) + ".",
            referenced_dimensions=(
                "basic_information",
                "current_state",
                "traits",
                "conflicts",
                "preferences",
            ),
            completion_rate=experience.completion_rate,
            support_reliance=experience.support_reliance,
            mean_emotion=experience.mean_emotion,
        )

    def grow(
        self,
        character: CharacterState,
        experience: ScenarioExperience,
        fatigue: float,
    ) -> CharacterState:
        """Sequential chain update: current state -> traits -> conflicts -> preferences.

        Basic information stays static, matching the proposal's five-dimension
        design.
        """
        growth_notes: list[str] = []

        # 1) Current state responds to the raw experience.
        current_state = dict(character.current_state)
        current_state["mood"] = self._mood_label(experience.mean_emotion)
        current_state["fatigue"] = round(fatigue, 3)
        current_state["last_scenario_id"] = experience.scenario_id
        current_state["last_completion_rate"] = round(experience.completion_rate, 3)

        # 2) Traits respond to the updated current state.
        traits = dict(character.traits)
        volatility = _clamp((experience.peak_emotion - experience.mean_emotion) / 3.5)
        neuroticism_delta = (volatility - 0.3) * 0.04
        conscientiousness_delta = (experience.completion_rate - 0.5) * 0.04
        traits["neuroticism"] = _clamp(character.trait("neuroticism") + neuroticism_delta)
        traits["conscientiousness"] = _clamp(
            character.trait("conscientiousness") + conscientiousness_delta
        )
        if experience.support_partners:
            traits["agreeableness"] = _clamp(character.trait("agreeableness") + 0.01)
        if abs(neuroticism_delta) >= 0.02 or abs(conscientiousness_delta) >= 0.02:
            growth_notes.append(
                f"traits shifted after {experience.scenario_id} "
                f"(volatility={volatility:.2f}, "
                f"completion={experience.completion_rate:.2f})"
            )

        # 3) Conflicts respond to the updated traits and support pattern.
        conflicts = dict(character.conflicts)
        independence_pressure = experience.support_reliance - experience.completion_rate
        for name, level in character.conflicts.items():
            if "independence" in name:
                conflicts[name] = _clamp(level + independence_pressure * 0.05)
                if abs(independence_pressure) >= 0.3:
                    growth_notes.append(
                        f"conflict '{name}' moved with support reliance "
                        f"{experience.support_reliance:.0%}"
                    )

        # 4) Preferences respond to the updated conflicts.
        preferences = dict(character.preferences)
        if experience.support_reliance >= 0.5:
            support_styles = list(preferences.get("support_style", []))
            reinforced = "reinforced: familiar partner support"
            if reinforced not in support_styles:
                support_styles.append(reinforced)
                growth_notes.append(
                    "preference update: familiar partner support reinforced"
                )
            preferences["support_style"] = support_styles
        elif experience.completion_rate >= 0.8:
            routines = list(preferences.get("routines", []))
            reinforced = "reinforced: independent routine attempts"
            if reinforced not in routines:
                routines.append(reinforced)
                growth_notes.append(
                    "preference update: independent routine attempts reinforced"
                )
            preferences["routines"] = routines

        return replace(
            character,
            current_state=current_state,
            traits=traits,
            conflicts=conflicts,
            preferences=preferences,
            growth_log=character.growth_log + tuple(growth_notes),
        )

    @staticmethod
    def _mood_label(mean_emotion: float) -> str:
        if mean_emotion >= 5.0:
            return "distressed"
        if mean_emotion >= 4.0:
            return "strained"
        if mean_emotion >= 2.5:
            return "neutral"
        return "settled"

    @staticmethod
    def _dominant_conflict(character: CharacterState) -> str | None:
        if not character.conflicts:
            return None
        return max(character.conflicts, key=character.conflicts.get)
