"""Evolving Agents-style cognition module.

Filters short-term memory traces into a trait-aligned long-term archive, so
fragmented step-level data can support holistic Insight summaries instead of
overwhelming them. Retention rules are deterministic scaffold heuristics, not
clinical memory models.
"""

from dataclasses import dataclass

from idd_agent_sim.architecture.character import CharacterState
from idd_agent_sim.architecture.memory import MemoryTrace


@dataclass(frozen=True)
class LongTermRecord:
    trace: MemoryTrace
    retention_reason: str
    trait_alignment: float


class CognitionModule:
    """Archives short-term traces into long-term records aligned with traits."""

    BASE_RETENTION_THRESHOLD = 0.55

    def archive(
        self,
        character: CharacterState,
        traces: list[MemoryTrace],
    ) -> list[LongTermRecord]:
        records: list[LongTermRecord] = []
        for trace in traces:
            alignment, reason = self._alignment(character, trace)
            if trace.importance >= self.BASE_RETENTION_THRESHOLD:
                records.append(
                    LongTermRecord(
                        trace=trace,
                        retention_reason=reason or "high_importance",
                        trait_alignment=alignment,
                    )
                )
            elif alignment >= 0.6:
                records.append(
                    LongTermRecord(
                        trace=trace,
                        retention_reason=reason,
                        trait_alignment=alignment,
                    )
                )
        return records

    @staticmethod
    def _alignment(character: CharacterState, trace: MemoryTrace) -> tuple[float, str]:
        """How strongly the trace resonates with the character's traits."""
        neuroticism = character.trait("neuroticism")
        conscientiousness = character.trait("conscientiousness")
        agreeableness = character.trait("agreeableness")

        emotional_salience = (trace.emotion_level / 7) * neuroticism
        if emotional_salience >= 0.45:
            return emotional_salience + 0.2, "emotionally_salient_for_trait_profile"
        if not trace.completed and conscientiousness >= 0.5:
            return conscientiousness + 0.1, "task_failure_salient_for_conscientiousness"
        if trace.support_partner is not None and agreeableness >= 0.55:
            return agreeableness, "support_interaction_salient_for_agreeableness"
        return max(emotional_salience, 0.0), ""
