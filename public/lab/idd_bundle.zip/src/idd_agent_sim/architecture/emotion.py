from dataclasses import dataclass

from idd_agent_sim.architecture.action_selection import ActionDecision
from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints


@dataclass(frozen=True)
class EmotionState:
    level: float = 3.5

    def update(
        self,
        decision: ActionDecision,
        constraints: IDDProfileConstraints,
    ) -> tuple["EmotionState", float, bool]:
        stress = decision.unmet_need * constraints.emotional_reactivity * 4
        if not decision.completed:
            stress += constraints.emotional_reactivity
        relief = 0.3 if decision.action_type == "supported_completion" else 0.0
        shift = max(0.0, stress - relief)
        next_level = max(0.0, min(7.0, self.level + shift))
        return EmotionState(next_level), shift, shift >= constraints.replan_trigger

