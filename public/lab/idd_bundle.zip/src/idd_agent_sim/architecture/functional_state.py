from dataclasses import dataclass, field, replace

from idd_agent_sim.architecture.profile_constraints import clamp
from idd_agent_sim.profiles import FunctionalProfile


@dataclass(frozen=True)
class BottleneckEvidence:
    scenario_id: str
    step_id: str
    domain: str
    action_type: str
    unmet_need: float
    state_pressure: float
    missed_cues: tuple[str, ...] = ()
    support_partner: str | None = None

    @property
    def care_gap_flag(self) -> bool:
        return self.unmet_need > 0 and self.action_type != "supported_completion"


@dataclass(frozen=True)
class FunctionalState:
    adaptive_estimates: dict[str, float] = field(default_factory=dict)
    support_need_estimates: dict[str, float] = field(default_factory=dict)
    bottleneck_evidence: list[BottleneckEvidence] = field(default_factory=list)

    @classmethod
    def from_profile(cls, profile: FunctionalProfile) -> "FunctionalState":
        estimates = dict(profile.adaptive_profile().domain_capacity)
        estimates.pop("default", None)
        support_need = dict(profile.support_need_profile().domain_intensity)
        return cls(
            adaptive_estimates=estimates,
            support_need_estimates=support_need,
        )

    def adaptive_estimate_for(self, domain: str) -> float:
        return self.adaptive_estimates.get(domain, 0.5)

    def support_need_for(self, domain: str) -> float:
        return self.support_need_estimates.get(domain, 0.5)

    def update_after_step(
        self,
        *,
        scenario_id: str,
        step_id: str,
        domain: str,
        action_type: str,
        completed: bool,
        unmet_need: float,
        state_pressure: float,
        missed_cues: tuple[str, ...],
        support_partner: str | None,
    ) -> "FunctionalState":
        adaptive = dict(self.adaptive_estimates)
        support_need = dict(self.support_need_estimates)
        previous_adaptive = adaptive.get(domain, 0.5)
        previous_support_need = support_need.get(domain, clamp(1.0 - previous_adaptive))

        adaptive_delta = 0.02 if completed and unmet_need == 0 else -(unmet_need * 0.08)
        if not completed:
            adaptive_delta -= 0.02

        support_delta = unmet_need * 0.25 + state_pressure * 0.10
        if missed_cues:
            support_delta += min(0.08, len(missed_cues) * 0.02)
        if action_type == "supported_completion":
            support_delta += 0.03
        if completed and unmet_need == 0:
            support_delta -= 0.02

        adaptive[domain] = clamp(previous_adaptive + adaptive_delta)
        support_need[domain] = clamp(previous_support_need + support_delta)

        evidence = list(self.bottleneck_evidence)
        if unmet_need > 0 or not completed or missed_cues:
            evidence.append(
                BottleneckEvidence(
                    scenario_id=scenario_id,
                    step_id=step_id,
                    domain=domain,
                    action_type=action_type,
                    unmet_need=unmet_need,
                    state_pressure=state_pressure,
                    missed_cues=missed_cues,
                    support_partner=support_partner,
                )
            )

        return replace(
            self,
            adaptive_estimates=adaptive,
            support_need_estimates=support_need,
            bottleneck_evidence=evidence,
        )

    def evidence_count_for(self, domain: str) -> int:
        return sum(1 for evidence in self.bottleneck_evidence if evidence.domain == domain)

    def care_gap_count_for(self, domain: str) -> int:
        return sum(
            1
            for evidence in self.bottleneck_evidence
            if evidence.domain == domain and evidence.care_gap_flag
        )
