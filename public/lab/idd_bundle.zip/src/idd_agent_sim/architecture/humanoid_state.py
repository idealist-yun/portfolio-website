from dataclasses import dataclass, field
from typing import Any

from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints, clamp


@dataclass(frozen=True)
class HumanoidState:
    fatigue: float = 0.0
    sensory_load: float = 0.0
    regulation_load: float = 0.0
    routine_stability: float = 1.0
    support_availability: float = 0.0
    support_relationships: dict[str, float] = field(default_factory=dict)

    @property
    def state_pressure(self) -> float:
        instability = 1.0 - self.routine_stability
        return clamp(
            (
                self.fatigue
                + self.sensory_load
                + self.regulation_load
                + instability
            )
            / 4
        )

    def apply_to_constraints(
        self,
        constraints: IDDProfileConstraints,
    ) -> IDDProfileConstraints:
        pressure = self.state_pressure
        return constraints.adjusted_for_state(
            independent_capacity_delta=-(pressure * 0.12),
            observation_bandwidth_delta=-(self.sensory_load * 0.08),
            support_trigger_delta=-(pressure * 0.10),
            emotional_reactivity_delta=self.regulation_load * 0.08,
        )

    def update_after_action(
        self,
        decision: Any,
        constraints: IDDProfileConstraints,
        support_partner: str | None = None,
    ) -> "HumanoidState":
        effort = clamp(decision.unmet_need + (0.1 if not decision.completed else 0.0))
        support_relief = 0.08 if decision.action_type == "supported_completion" else 0.0
        bottleneck_penalty = 0.12 if not decision.completed else 0.0
        relationships = dict(self.support_relationships)
        if support_partner is not None:
            current = relationships.get(support_partner, 0.5)
            relationship_delta = 0.05 if decision.completed else -0.03
            relationships[support_partner] = clamp(current + relationship_delta)

        return HumanoidState(
            fatigue=clamp(self.fatigue + effort * 0.08),
            sensory_load=clamp(self.sensory_load + bottleneck_penalty * constraints.emotional_reactivity),
            regulation_load=clamp(self.regulation_load + bottleneck_penalty - support_relief),
            routine_stability=clamp(self.routine_stability - bottleneck_penalty + support_relief),
            support_availability=self.support_availability,
            support_relationships=relationships,
        )

    def with_support_availability(self, support_availability: float) -> "HumanoidState":
        return HumanoidState(
            fatigue=self.fatigue,
            sensory_load=self.sensory_load,
            regulation_load=self.regulation_load,
            routine_stability=self.routine_stability,
            support_availability=clamp(support_availability),
            support_relationships=dict(self.support_relationships),
        )

    def relationship_closeness(self, partner: str) -> float:
        return clamp(self.support_relationships.get(partner, 0.5))
