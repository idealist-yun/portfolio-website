from dataclasses import dataclass

from idd_agent_sim.architecture.action_selection import ActionDecision
from idd_agent_sim.architecture.memory import ReflectionNote
from idd_agent_sim.environment import EnvironmentFeedback


@dataclass(frozen=True)
class LearningSignal:
    signal_type: str
    adaptive_delta: float
    support_need_delta: float
    reason: str


class LearningUpdateModule:
    def signal(
        self,
        *,
        decision: ActionDecision,
        environment_feedback: EnvironmentFeedback,
        reflection: ReflectionNote,
        previous_adaptive: float,
        updated_adaptive: float,
        previous_support_need: float,
        updated_support_need: float,
    ) -> LearningSignal:
        adaptive_delta = updated_adaptive - previous_adaptive
        support_need_delta = updated_support_need - previous_support_need

        if environment_feedback.missing_objects or environment_feedback.occupied_objects:
            signal_type = "environment_prerequisite_bottleneck"
            reason = "Environment prerequisites changed the support-learning signal."
        elif decision.completed and decision.unmet_need == 0:
            signal_type = "independent_success"
            reason = "Independent completion slightly strengthened adaptive estimate."
        elif decision.action_type == "supported_completion":
            signal_type = "supported_success"
            reason = "Supported completion preserved task success while increasing support need evidence."
        elif reflection.triggered:
            signal_type = "reflection_adjustment"
            reason = f"Reflection recommended: {reflection.adjustment}."
        elif decision.unmet_need > 0:
            signal_type = "care_gap"
            reason = "Unmet need increased support need evidence."
        else:
            signal_type = "stable"
            reason = "No meaningful learning pressure was detected."

        return LearningSignal(
            signal_type=signal_type,
            adaptive_delta=adaptive_delta,
            support_need_delta=support_need_delta,
            reason=reason,
        )
