from dataclasses import dataclass, field


@dataclass(frozen=True)
class MemoryTrace:
    scenario_id: str
    step_id: str
    action_type: str
    completed: bool
    emotion_level: float
    explanation: str
    support_partner: str | None = None

    @property
    def importance(self) -> float:
        score = self.emotion_level / 7
        if not self.completed:
            score += 0.3
        if self.support_partner is not None:
            score += 0.1
        return min(1.0, score)


@dataclass(frozen=True)
class ScratchState:
    step_id: str
    current_plan: str
    emotion_level: float
    support_partner: str | None = None


@dataclass(frozen=True)
class SpatialMemoryTrace:
    scenario_id: str
    step_id: str
    visible_objects: tuple[str, ...] = ()
    visible_people: tuple[str, ...] = ()
    blocked_objects: tuple[str, ...] = ()
    environment_cues: tuple[str, ...] = ()

    def matches(
        self,
        scenario_id: str,
        required_objects: tuple[str, ...] = (),
        required_people: tuple[str, ...] = (),
    ) -> bool:
        remembered_objects = set(self.visible_objects) | set(self.blocked_objects)
        remembered_people = set(self.visible_people)
        if remembered_objects.intersection(required_objects):
            return True
        if remembered_people.intersection(required_people):
            return True
        return False


@dataclass(frozen=True)
class ReflectionNote:
    scenario_id: str
    step_id: str
    summary: str
    triggered: bool
    adjustment: str

    def matches(self, scenario_id: str, step_id: str) -> bool:
        return self.scenario_id == scenario_id or self.step_id == step_id


@dataclass(frozen=True)
class MemoryBundle:
    short_term: list[MemoryTrace]
    associative: list[MemoryTrace]
    spatial: list[SpatialMemoryTrace] = field(default_factory=list)
    reflections: list[ReflectionNote] = field(default_factory=list)
    scratch: ScratchState | None = None

    @property
    def total_count(self) -> int:
        return (
            len(self.short_term)
            + len(self.associative)
            + len(self.spatial)
            + len(self.reflections)
            + (1 if self.scratch else 0)
        )


@dataclass
class AgentMemory:
    short_term: list[MemoryTrace] = field(default_factory=list)
    associative: list[MemoryTrace] = field(default_factory=list)
    spatial: list[SpatialMemoryTrace] = field(default_factory=list)
    reflections: list[ReflectionNote] = field(default_factory=list)
    scratch: ScratchState | None = None

    def record(self, trace: MemoryTrace) -> None:
        self.short_term.append(trace)
        if trace.importance >= 0.55:
            self.associative.append(trace)

    def record_spatial(self, trace: SpatialMemoryTrace) -> None:
        if trace.environment_cues:
            self.spatial.append(trace)

    def record_reflection(self, note: ReflectionNote) -> None:
        if note.triggered:
            self.reflections.append(note)

    def retrieve_recent(self, limit: int = 3) -> list[MemoryTrace]:
        return self.short_term[-limit:]

    def retrieve_associative(
        self,
        scenario_id: str,
        step_id: str,
        limit: int = 3,
    ) -> list[MemoryTrace]:
        matches = [
            trace
            for trace in self.associative
            if trace.scenario_id == scenario_id or trace.step_id == step_id
        ]
        return sorted(matches, key=lambda trace: trace.importance, reverse=True)[:limit]

    def retrieve_bundle(
        self,
        scenario_id: str,
        step_id: str,
        required_objects: tuple[str, ...] = (),
        required_people: tuple[str, ...] = (),
        recent_limit: int = 3,
        associative_limit: int = 3,
        spatial_limit: int = 3,
    ) -> MemoryBundle:
        return MemoryBundle(
            short_term=self.retrieve_recent(recent_limit),
            associative=self.retrieve_associative(
                scenario_id,
                step_id,
                associative_limit,
            ),
            spatial=self.retrieve_spatial(
                scenario_id,
                required_objects,
                required_people,
                spatial_limit,
            ),
            reflections=self.retrieve_reflections(scenario_id, step_id),
            scratch=self.scratch,
        )

    def retrieve_spatial(
        self,
        scenario_id: str,
        required_objects: tuple[str, ...] = (),
        required_people: tuple[str, ...] = (),
        limit: int = 3,
    ) -> list[SpatialMemoryTrace]:
        matches = [
            trace
            for trace in self.spatial
            if trace.matches(scenario_id, required_objects, required_people)
        ]
        return matches[-limit:]

    def retrieve_reflections(
        self,
        scenario_id: str,
        step_id: str,
        limit: int = 3,
    ) -> list[ReflectionNote]:
        matches = [
            note
            for note in self.reflections
            if note.matches(scenario_id, step_id)
        ]
        return matches[-limit:]

    def update_scratch(self, scratch: ScratchState) -> None:
        self.scratch = scratch
