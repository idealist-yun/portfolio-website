from dataclasses import dataclass

from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints
from idd_agent_sim.environment.state import EnvironmentState
from idd_agent_sim.testbed import ScenarioStep


@dataclass(frozen=True)
class Observation:
    step_id: str
    visible_cues: list[str]
    missed_cues: list[str]
    visible_objects: list[str]
    visible_people: list[str]
    blocked_objects: list[str]
    environment_cues: list[str]
    perceived_demand: float
    required_skill: str | None


class PerceptionModule:
    def observe(
        self,
        step: ScenarioStep,
        constraints: IDDProfileConstraints,
        environment_state: EnvironmentState | None = None,
    ) -> Observation:
        visible_cues = [step.label]
        missed_cues: list[str] = []
        visible_objects: list[str] = []
        visible_people: list[str] = []
        blocked_objects: list[str] = []
        environment_cues: list[str] = []

        if step.required_skill and constraints.observation_bandwidth >= 0.45:
            visible_cues.append(f"skill:{step.required_skill}")
        elif step.required_skill:
            missed_cues.append(f"skill:{step.required_skill}")

        if environment_state is not None:
            visible_objects = sorted(
                obj for obj in step.required_objects if obj in environment_state.available_objects
            )
            visible_people = sorted(
                person
                for person in step.required_people
                if person in environment_state.available_people
            )
            blocked_objects = sorted(
                obj for obj in step.required_objects if obj in environment_state.occupied_objects
            )
            missing_objects = sorted(
                obj
                for obj in step.required_objects
                if obj not in environment_state.available_objects
                and obj not in environment_state.occupied_objects
            )
            missing_people = sorted(
                person
                for person in step.required_people
                if person not in environment_state.available_people
            )
            environment_cues = [
                *(f"object:{obj}" for obj in visible_objects),
                *(f"person:{person}" for person in visible_people),
                *(f"blocked_object:{obj}" for obj in blocked_objects),
                *(f"missing_object:{obj}" for obj in missing_objects),
                *(f"missing_person:{person}" for person in missing_people),
            ]
            visible_cues.extend(environment_cues)
            missed_cues.extend(f"object:{obj}" for obj in missing_objects)
            missed_cues.extend(f"person:{person}" for person in missing_people)

        perceived_demand = step.demand + max(0.0, 0.5 - constraints.observation_bandwidth) * 0.2
        return Observation(
            step_id=step.step_id,
            visible_cues=visible_cues,
            missed_cues=missed_cues,
            visible_objects=visible_objects,
            visible_people=visible_people,
            blocked_objects=blocked_objects,
            environment_cues=environment_cues,
            perceived_demand=perceived_demand,
            required_skill=step.required_skill,
        )
