from dataclasses import dataclass

from idd_agent_sim.architecture.perception import Observation
from idd_agent_sim.architecture.profile_constraints import IDDProfileConstraints
from idd_agent_sim.architecture.retrieval import RetrievedContext
from idd_agent_sim.testbed import Scenario


@dataclass(frozen=True)
class ScenarioPlan:
    scenario_id: str
    domain: str
    routine_label: str
    step_ids: list[str]
    support_strategy: str
    rationale: str

    @property
    def total_steps(self) -> int:
        return len(self.step_ids)

    def index_for(self, step_id: str) -> int:
        if step_id not in self.step_ids:
            return 0
        return self.step_ids.index(step_id)


@dataclass(frozen=True)
class BaselinePlan:
    step_id: str
    intended_action: str
    required_skill: str | None
    scenario_plan_id: str
    scenario_step_index: int
    scenario_total_steps: int


@dataclass(frozen=True)
class AdjustedPlan:
    step_id: str
    intended_action: str
    required_skill: str | None
    scenario_plan_id: str
    scenario_step_index: int
    scenario_total_steps: int
    long_term_step_ids: list[str]
    support_strategy: str
    substep_count: int
    support_primed: bool
    rationale: str
    retrieved_skill_names: list[str]
    retrieved_memory_count: int
    short_term_memory_count: int
    associative_memory_count: int
    spatial_memory_count: int
    reflection_memory_count: int
    scratch_memory_used: bool
    replanned: bool = False


class PlanningModule:
    def scenario_plan(
        self,
        scenario: Scenario,
        constraints: IDDProfileConstraints,
    ) -> ScenarioPlan:
        support_strategy = (
            "prime_support_early"
            if constraints.support_trigger < 0.5
            else "attempt_independently_then_support"
        )
        return ScenarioPlan(
            scenario_id=scenario.scenario_id,
            domain=scenario.domain,
            routine_label=scenario.description or scenario.scenario_id,
            step_ids=[step.step_id for step in scenario.steps],
            support_strategy=support_strategy,
            rationale=(
                "Scenario-level routine plan created from the agent profile, "
                "scenario steps, and support trigger."
            ),
        )

    def baseline_plan(
        self,
        observation: Observation,
        scenario_plan: ScenarioPlan,
    ) -> BaselinePlan:
        return BaselinePlan(
            step_id=observation.step_id,
            intended_action=f"attempt:{observation.step_id}",
            required_skill=observation.required_skill,
            scenario_plan_id=scenario_plan.scenario_id,
            scenario_step_index=scenario_plan.index_for(observation.step_id),
            scenario_total_steps=scenario_plan.total_steps,
        )

    def adjust_plan(
        self,
        baseline: BaselinePlan,
        observation: Observation,
        constraints: IDDProfileConstraints,
        retrieved: RetrievedContext,
        scenario_plan: ScenarioPlan,
    ) -> AdjustedPlan:
        retrieved_skill_names = retrieved.skill_names
        has_support_skill = "request_support" in retrieved_skill_names
        support_primed = (
            observation.perceived_demand > constraints.support_trigger
            and has_support_skill
        )
        routine_rationale = (
            f" Long-term routine step {baseline.scenario_step_index + 1}/"
            f"{baseline.scenario_total_steps} under strategy "
            f"{scenario_plan.support_strategy}."
        )
        base_rationale = (
            "Plan split into smaller substeps due to adaptive-functioning constraints."
            if constraints.planning_granularity > 1
            else "Plan can be attempted as a single step."
        )
        retrieval_rationale = (
            f" Retrieved skills: {', '.join(retrieved_skill_names)}."
            if retrieved_skill_names
            else " No runnable skills were retrieved."
        )
        memory_rationale = (
            " Retrieved memory: "
            f"short_term={len(retrieved.memory.short_term)}, "
            f"associative={len(retrieved.memory.associative)}, "
            f"spatial={len(retrieved.memory.spatial)}, "
            f"reflections={len(retrieved.memory.reflections)}, "
            f"scratch={'yes' if retrieved.memory.scratch else 'no'}."
        )
        vineland_rationale = (
            " Vineland constraint signal: "
            f"evidence={constraints.vineland_evidence_count}, "
            f"prerequisite_gaps={constraints.vineland_prerequisite_gap_count}, "
            f"prompts={', '.join(constraints.active_prompt_conditions)}."
            if constraints.vineland_evidence_count > 0
            else ""
        )
        return AdjustedPlan(
            step_id=baseline.step_id,
            intended_action=baseline.intended_action,
            required_skill=baseline.required_skill,
            scenario_plan_id=baseline.scenario_plan_id,
            scenario_step_index=baseline.scenario_step_index,
            scenario_total_steps=baseline.scenario_total_steps,
            long_term_step_ids=scenario_plan.step_ids,
            support_strategy=scenario_plan.support_strategy,
            substep_count=constraints.planning_granularity,
            support_primed=support_primed,
            rationale=(
                routine_rationale
                + " "
                + base_rationale
                + retrieval_rationale
                + memory_rationale
                + vineland_rationale
            ),
            retrieved_skill_names=retrieved_skill_names,
            retrieved_memory_count=retrieved.memory.total_count,
            short_term_memory_count=len(retrieved.memory.short_term),
            associative_memory_count=len(retrieved.memory.associative),
            spatial_memory_count=len(retrieved.memory.spatial),
            reflection_memory_count=len(retrieved.memory.reflections),
            scratch_memory_used=retrieved.memory.scratch is not None,
        )

    def replan_after_emotional_shift(
        self,
        plan: AdjustedPlan,
        emotional_shift: float,
    ) -> AdjustedPlan:
        return AdjustedPlan(
            step_id=plan.step_id,
            intended_action=f"replan:{plan.step_id}",
            required_skill=plan.required_skill,
            scenario_plan_id=plan.scenario_plan_id,
            scenario_step_index=plan.scenario_step_index,
            scenario_total_steps=plan.scenario_total_steps,
            long_term_step_ids=plan.long_term_step_ids,
            support_strategy=plan.support_strategy,
            substep_count=plan.substep_count + 1,
            support_primed=True,
            rationale=(
                f"{plan.rationale} Replanned after emotional shift "
                f"{emotional_shift:.2f}; using a smaller next step and priming support."
            ),
            retrieved_skill_names=plan.retrieved_skill_names,
            retrieved_memory_count=plan.retrieved_memory_count,
            short_term_memory_count=plan.short_term_memory_count,
            associative_memory_count=plan.associative_memory_count,
            spatial_memory_count=plan.spatial_memory_count,
            reflection_memory_count=plan.reflection_memory_count,
            scratch_memory_used=plan.scratch_memory_used,
            replanned=True,
        )
