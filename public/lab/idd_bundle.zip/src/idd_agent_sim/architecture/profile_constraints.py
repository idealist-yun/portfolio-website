from dataclasses import dataclass
from dataclasses import replace

from idd_agent_sim.profiles import FunctionalProfile
from idd_agent_sim.profiles import VinelandConstraintSignal


def clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class IDDProfileConstraints:
    """Computational constraints derived from an IDD functional profile."""

    domain: str
    independent_capacity: float
    observation_bandwidth: float
    planning_granularity: int
    sequencing_tolerance: float
    support_trigger: float
    emotional_reactivity: float
    replan_trigger: float
    vineland_evidence_count: int = 0
    vineland_prerequisite_gap_count: int = 0
    vineland_prerequisite_uncertainty_count: int = 0
    active_prompt_conditions: tuple[str, ...] = ()
    related_vineland_skill_codes: tuple[str, ...] = ()
    constraint_source: str = "profile_baseline"

    @classmethod
    def from_profile(
        cls,
        profile: FunctionalProfile,
        domain: str,
        required_skill: str | None = None,
    ) -> "IDDProfileConstraints":
        traits = profile.constraint_traits(domain)
        constraints = cls(
            domain=traits.domain,
            independent_capacity=traits.independent_capacity,
            observation_bandwidth=traits.observation_bandwidth,
            planning_granularity=traits.planning_granularity,
            sequencing_tolerance=traits.sequencing_tolerance,
            support_trigger=traits.support_trigger,
            emotional_reactivity=traits.emotional_reactivity,
            replan_trigger=traits.replan_trigger,
        )
        return constraints.adjusted_for_vineland(
            profile.vineland_constraint_signal(domain, required_skill)
        )

    def adjusted_for_vineland(
        self,
        signal: VinelandConstraintSignal,
    ) -> "IDDProfileConstraints":
        if signal.evidence_count == 0:
            return replace(self, constraint_source=signal.source)

        intensity = signal.constraint_intensity
        emotional_reactivity = clamp(
            self.emotional_reactivity + (0.18 * intensity)
        )
        planning_delta = min(3, round(intensity * 3))
        if signal.prerequisite_gap_count > 0 and planning_delta == 0:
            planning_delta = 1

        return replace(
            self,
            observation_bandwidth=clamp(
                self.observation_bandwidth - (0.12 * intensity)
            ),
            planning_granularity=max(1, self.planning_granularity + planning_delta),
            sequencing_tolerance=clamp(
                self.sequencing_tolerance - (0.18 * intensity)
            ),
            support_trigger=clamp(self.support_trigger - (0.25 * intensity)),
            emotional_reactivity=emotional_reactivity,
            replan_trigger=max(0.5, (1.4 - emotional_reactivity) - (0.10 * intensity)),
            vineland_evidence_count=signal.evidence_count,
            vineland_prerequisite_gap_count=signal.prerequisite_gap_count,
            vineland_prerequisite_uncertainty_count=signal.prerequisite_uncertainty_count,
            active_prompt_conditions=signal.active_prompt_conditions,
            related_vineland_skill_codes=signal.related_functional_skill_codes,
            constraint_source=signal.source,
        )

    def adjusted_for_state(
        self,
        *,
        independent_capacity_delta: float = 0.0,
        observation_bandwidth_delta: float = 0.0,
        support_trigger_delta: float = 0.0,
        emotional_reactivity_delta: float = 0.0,
    ) -> "IDDProfileConstraints":
        emotional_reactivity = clamp(
            self.emotional_reactivity + emotional_reactivity_delta
        )
        return replace(
            self,
            independent_capacity=clamp(
                self.independent_capacity + independent_capacity_delta
            ),
            observation_bandwidth=clamp(
                self.observation_bandwidth + observation_bandwidth_delta
            ),
            support_trigger=clamp(self.support_trigger + support_trigger_delta),
            emotional_reactivity=emotional_reactivity,
            replan_trigger=max(0.6, 1.4 - emotional_reactivity),
        )
