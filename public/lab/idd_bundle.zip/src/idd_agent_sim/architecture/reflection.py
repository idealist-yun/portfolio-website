from idd_agent_sim.architecture.action_selection import ActionDecision
from idd_agent_sim.architecture.memory import ReflectionNote
from idd_agent_sim.architecture.perception import Observation
from idd_agent_sim.architecture.support import SupportDecision
from idd_agent_sim.environment import EnvironmentFeedback


class ReflectionModule:
    def reflect(
        self,
        scenario_id: str,
        step_id: str,
        observation: Observation,
        decision: ActionDecision,
        environment_feedback: EnvironmentFeedback,
        support: SupportDecision,
        emotional_shift: float,
    ) -> ReflectionNote:
        triggered = (
            not decision.completed
            or environment_feedback.blocked
            or emotional_shift > 0.25
            or bool(observation.missed_cues)
        )
        environment_prerequisite_blocked = bool(
            environment_feedback.missing_objects
            or environment_feedback.missing_people
            or environment_feedback.occupied_objects
        )
        if environment_prerequisite_blocked:
            adjustment = "check_environment_prerequisites_before_retry"
            summary = environment_feedback.explanation
        elif not decision.completed:
            adjustment = "increase_support_or_reduce_step_demand"
            summary = decision.explanation
        elif emotional_shift > 0.25:
            adjustment = "use_smaller_step_and_regulation_support"
            summary = "Emotional shift suggests the next plan should be gentler."
        elif observation.missed_cues:
            adjustment = "make_cues_more_explicit"
            summary = "Some task or environment cues were missed during perception."
        else:
            adjustment = "maintain_current_strategy"
            summary = "The step completed without a reflection trigger."

        if support.partner:
            summary = f"{summary} Support used: {support.partner}."

        return ReflectionNote(
            scenario_id=scenario_id,
            step_id=step_id,
            summary=summary,
            triggered=triggered,
            adjustment=adjustment,
        )
