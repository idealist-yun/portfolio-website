from dataclasses import dataclass

from idd_agent_sim.architecture.memory import MemoryBundle, MemoryTrace
from idd_agent_sim.skills import Skill, SkillLibrary, TaskContext


@dataclass(frozen=True)
class RetrievedContext:
    skills: list[Skill]
    memory: MemoryBundle

    @property
    def skill_names(self) -> list[str]:
        return [skill.name for skill in self.skills]

    @property
    def memory_traces(self) -> list[MemoryTrace]:
        return self.memory.short_term + self.memory.associative


class ContextRetrievalModule:
    def retrieve(
        self,
        skills: SkillLibrary,
        task_context: TaskContext,
        memory: MemoryBundle,
    ) -> RetrievedContext:
        return RetrievedContext(
            skills=skills.retrieve_for_context(task_context),
            memory=memory,
        )
