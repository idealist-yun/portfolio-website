from dataclasses import dataclass

from idd_agent_sim.architecture.humanoid_state import HumanoidState
from idd_agent_sim.architecture.memory import MemoryTrace
from idd_agent_sim.architecture.support_dependency import SupportDependencyModule
from idd_agent_sim.architecture.support_levels import required_support_level
from idd_agent_sim.profiles import FunctionalProfile
from idd_agent_sim.world import World


@dataclass(frozen=True)
class SupportDecision:
    partner: str | None
    available_support: float
    closes_gap: bool
    clinical_weight: float = 0.0
    relationship_closeness: float = 0.0
    memory_bonus: float = 0.0
    rationale: str = ""
    calibration_source: str = "hand_specified"
    support_level: str = "monitoring"
    domain_coverage: float = 0.0


class SupportSeekingModule:
    def __init__(self, dependency: SupportDependencyModule | None = None) -> None:
        self.dependency = dependency or SupportDependencyModule()

    def decide(
        self,
        profile: FunctionalProfile,
        world: World,
        unmet_need: float,
        support_primed: bool,
        humanoid_state: HumanoidState | None = None,
        memory_traces: list[MemoryTrace] | None = None,
        domain: str = "",
        binding_dimension: str = "",
    ) -> SupportDecision:
        if unmet_need <= 0 or not support_primed:
            return SupportDecision(
                None, 0.0, unmet_need <= 0, calibration_source="not_applicable"
            )

        humanoid_state = humanoid_state or HumanoidState()
        memory_traces = memory_traces or []
        score = self.dependency.select_partner(
            profile, humanoid_state, memory_traces, domain
        )
        support_level = required_support_level(
            unmet_need,
            binding_dimension,
            profile.support_need_profile().domain_intensity.get(domain),
        )
        if score is None:
            return SupportDecision(
                None,
                0.0,
                False,
                calibration_source="not_applicable",
                support_level=support_level,
            )

        available = score.clinical_weight * world.support_availability
        return SupportDecision(
            partner=score.partner,
            available_support=available,
            closes_gap=available >= unmet_need,
            clinical_weight=score.clinical_weight,
            relationship_closeness=score.relationship_closeness,
            memory_bonus=score.memory_bonus,
            rationale=(
                "Selected support partner from clinical dependency weight "
                f"({score.calibration_source}), relationship closeness, "
                "recent support memory, and scenario-domain coverage."
            ),
            calibration_source=score.calibration_source,
            support_level=support_level,
            domain_coverage=score.domain_coverage,
        )
