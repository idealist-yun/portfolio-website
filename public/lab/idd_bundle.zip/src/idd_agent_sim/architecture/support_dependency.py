"""Dedicated support-dependency scoring module.

Combines the proposal's hybrid partner-selection signals in one place:

- clinical dependency weight (SIS-A-calibrated when the profile has a SIS
  scaffold, otherwise hand-specified profile values);
- relationship closeness from the humanoid state layer;
- recent memory of successful supported completions.
"""

from dataclasses import dataclass

from idd_agent_sim.architecture.humanoid_state import HumanoidState
from idd_agent_sim.architecture.memory import MemoryTrace
from idd_agent_sim.clinical import AREA_TO_SIM_DOMAINS
from idd_agent_sim.profiles import FunctionalProfile

CLINICAL_WEIGHT_FACTOR = 0.65
CLOSENESS_FACTOR = 0.25
MEMORY_FACTOR = 0.10
DOMAIN_COVERAGE_FACTOR = 0.30


@dataclass(frozen=True)
class PartnerDependencyScore:
    partner: str
    clinical_weight: float
    relationship_closeness: float
    memory_bonus: float
    calibration_source: str
    domain_coverage: float = 0.0

    @property
    def total(self) -> float:
        return (
            self.clinical_weight * CLINICAL_WEIGHT_FACTOR
            + self.relationship_closeness * CLOSENESS_FACTOR
            + self.memory_bonus * MEMORY_FACTOR
            + self.domain_coverage * DOMAIN_COVERAGE_FACTOR
        )


class SupportDependencyModule:
    """Scores and ranks support partners for one decision point."""

    def score_partner(
        self,
        partner: str,
        profile: FunctionalProfile,
        humanoid_state: HumanoidState,
        memory_traces: list[MemoryTrace],
        domain: str = "",
    ) -> PartnerDependencyScore:
        support_needs = profile.support_need_profile()
        return PartnerDependencyScore(
            partner=partner,
            clinical_weight=support_needs.partner_weights.get(partner, 0.0),
            relationship_closeness=humanoid_state.relationship_closeness(partner),
            memory_bonus=self.memory_bonus(partner, memory_traces),
            calibration_source=support_needs.calibration_source,
            domain_coverage=self.domain_coverage(partner, profile, domain),
        )

    def select_partner(
        self,
        profile: FunctionalProfile,
        humanoid_state: HumanoidState,
        memory_traces: list[MemoryTrace],
        domain: str = "",
    ) -> PartnerDependencyScore | None:
        partner_weights = profile.support_need_profile().partner_weights
        if not partner_weights:
            return None
        scores = [
            self.score_partner(partner, profile, humanoid_state, memory_traces, domain)
            for partner in partner_weights
        ]
        return max(scores, key=lambda score: score.total)

    @staticmethod
    def domain_coverage(
        partner: str,
        profile: FunctionalProfile,
        domain: str,
    ) -> float:
        """1.0 when the partner's SIS activity areas cover this scenario
        domain, else 0.0. Without a SIS partner-area mapping there is no
        coverage signal."""
        if not domain or profile.sis is None:
            return 0.0
        partner_area_names = profile.sis.partner_areas.get(partner, ())
        covered_domains = {
            sim_domain
            for area in partner_area_names
            for sim_domain in AREA_TO_SIM_DOMAINS.get(area, ())
        }
        return 1.0 if domain in covered_domains else 0.0

    @staticmethod
    def memory_bonus(partner: str, memory_traces: list[MemoryTrace]) -> float:
        successful_support = [
            trace
            for trace in memory_traces
            if trace.support_partner == partner
            and trace.completed
            and trace.action_type == "supported_completion"
        ]
        return min(1.0, len(successful_support) / 3)
