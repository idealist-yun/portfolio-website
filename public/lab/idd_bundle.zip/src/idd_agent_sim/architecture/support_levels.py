"""Support-level hierarchy (least-to-most prompting).

Maps the simulation's scalar support gap plus the binding demand dimension
onto the clinically standard prompting hierarchy. The levels parallel the
SIS-A type-of-support rating structure, so SIS domain intensity can raise the
estimated level. This is an interpretive layer for intervention-point
analysis: it describes what kind of support the moment likely required, and
does not change whether support closed the gap.
"""

SUPPORT_LEVELS = (
    "monitoring",
    "verbal_prompt",
    "demonstration",
    "partial_physical",
    "full_support",
)

# Dimensions whose bottlenecks typically need at least this support level.
_DIMENSION_FLOORS = {
    "receptive_language": "verbal_prompt",
    "expressive_language": "verbal_prompt",
    "sequencing": "demonstration",
    "motor": "partial_physical",
}


def _index(level: str) -> int:
    return SUPPORT_LEVELS.index(level)


def required_support_level(
    unmet_need: float,
    binding_dimension: str = "",
    sis_domain_intensity: float | None = None,
) -> str:
    """Estimate the prompting level a support moment required."""
    if unmet_need <= 0:
        return "monitoring"
    if unmet_need <= 0.15:
        level = "verbal_prompt"
    elif unmet_need <= 0.30:
        level = "demonstration"
    elif unmet_need <= 0.50:
        level = "partial_physical"
    else:
        level = "full_support"

    floor = _DIMENSION_FLOORS.get(binding_dimension)
    if floor is not None and _index(floor) > _index(level):
        level = floor

    if sis_domain_intensity is not None and sis_domain_intensity >= 0.65:
        bumped = min(_index(level) + 1, len(SUPPORT_LEVELS) - 1)
        level = SUPPORT_LEVELS[bumped]
    return level
