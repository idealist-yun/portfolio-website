"""Formal K-Vineland-II scoring interfaces.

This module defines the *shape* of normed scoring so future work can plug in
manual-accurate rules without restructuring the codebase. Nothing here
implements or approximates normed scoring: v-scale conversion, standard
scores, percentile ranks, adaptive-level classification, and basal/ceiling
rules require the published K-Vineland-II norm tables, which this repository
must not embed. Every normed method on the scaffold engine raises
`NormedScoringUnavailable` so downstream code can never silently mistake
scaffold values for normed results.
"""

from dataclasses import dataclass
from typing import Protocol

from idd_agent_sim.clinical.vineland import VinelandItemResponse


class NormedScoringUnavailable(NotImplementedError):
    """Raised when a normed K-Vineland-II value is requested.

    Normed scoring needs the published manual's norm tables (age-banded
    v-scale conversions, standard-score tables, percentile ranks, and
    basal/ceiling rules). Until a licensed implementation is provided,
    simulation code must use normalized scaffold scores and must not present
    them as clinical results.
    """

    def __init__(self, requested: str) -> None:
        super().__init__(
            f"{requested} requires K-Vineland-II norm tables that are not "
            "implemented. Use normalized scaffold scores for simulation, and "
            "do not report them as normed clinical values."
        )


@dataclass(frozen=True)
class NormedSubdomainResult:
    """Target result shape for a future normed scoring engine."""

    subdomain: str
    raw_score: int
    v_scale_score: int
    age_equivalent_months: int | None = None


@dataclass(frozen=True)
class NormedDomainResult:
    domain: str
    standard_score: int
    percentile_rank: float
    adaptive_level: str


class VinelandScoringEngine(Protocol):
    """Interface a normed K-Vineland-II scoring engine must satisfy."""

    def raw_subdomain_score(
        self, subdomain: str, items: list[VinelandItemResponse]
    ) -> int:
        ...

    def apply_basal_ceiling(
        self, subdomain: str, items: list[VinelandItemResponse], age_months: int
    ) -> list[VinelandItemResponse]:
        ...

    def subdomain_result(
        self, subdomain: str, items: list[VinelandItemResponse], age_months: int
    ) -> NormedSubdomainResult:
        ...

    def domain_result(
        self, domain: str, subdomain_results: list[NormedSubdomainResult]
    ) -> NormedDomainResult:
        ...


class ScaffoldVinelandScoring:
    """The only scoring available today.

    Implements raw-score aggregation (no norms involved) and refuses every
    normed operation loudly.
    """

    def raw_subdomain_score(
        self, subdomain: str, items: list[VinelandItemResponse]
    ) -> int:
        """Sum of item scores on the 0/1/2 scale.

        `VinelandItemResponse` stores scores normalized to 0-1 (raw/2) and
        drops DK/N-O rows at parse time, so the raw sum is recovered by
        doubling. This is a raw sum, not a normed value.
        """
        from idd_agent_sim.clinical.vineland import canonical_subdomain

        target = canonical_subdomain(subdomain)
        return sum(
            round(item.score * 2)
            for item in items
            if item.subdomain == target
        )

    def apply_basal_ceiling(
        self, subdomain: str, items: list[VinelandItemResponse], age_months: int
    ) -> list[VinelandItemResponse]:
        raise NormedScoringUnavailable("Basal/ceiling application")

    def subdomain_result(
        self, subdomain: str, items: list[VinelandItemResponse], age_months: int
    ) -> NormedSubdomainResult:
        raise NormedScoringUnavailable("v-scale subdomain scoring")

    def domain_result(self, domain: str, subdomain_results) -> NormedDomainResult:
        raise NormedScoringUnavailable(
            "Standard score / percentile / adaptive level"
        )
