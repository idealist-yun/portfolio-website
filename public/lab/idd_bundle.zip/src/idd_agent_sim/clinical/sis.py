"""SIS-A-inspired support-intensity calibration scaffold.

This module stores structural SIS-A-style ratings only: activity area,
sequence, and the three rating dimensions (type of support, frequency, daily
support time). It does not copy SIS-A item text, and it is not a normed SIS-A
scoring engine: standard scores, percentile ranks, and the normed Support
Needs Index are not implemented. Derived values are normalized scaffold
intensities from 0.0 to 1.0 used only to calibrate simulation support
behavior.
"""

from dataclasses import dataclass, field
from typing import Any


SIS_ACTIVITY_AREAS = (
    "home_living",
    "community_living",
    "lifelong_learning",
    "employment",
    "health_safety",
    "social_activities",
    "protection_advocacy",
)

SUPPORT_TYPE_MAX = 2.0
FREQUENCY_MAX = 4.0
DAILY_SUPPORT_TIME_MAX = 4.0

# Which SIS-A activity areas inform each simulation domain's support intensity.
AREA_TO_SIM_DOMAINS = {
    "home_living": ("self_care", "meal", "household_tasks"),
    "community_living": ("community", "mobility", "activity"),
    "lifelong_learning": ("activity",),
    "employment": ("activity",),
    "health_safety": ("self_care", "meal", "community"),
    "social_activities": ("activity", "community"),
    "protection_advocacy": ("community",),
}


def _clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class SISItemRating:
    """One structural SIS-A-style item rating.

    Ratings follow the SIS-A rating ranges: type of support 0-2, frequency
    0-4, daily support time 0-4. Only structural fields are stored.
    """

    activity_area: str
    sequence: int
    support_type: float
    frequency: float
    daily_support_time: float

    @property
    def intensity(self) -> float:
        """Normalized 0-1 scaffold intensity for this item."""
        return _clamp(
            (
                _clamp(self.support_type / SUPPORT_TYPE_MAX)
                + _clamp(self.frequency / FREQUENCY_MAX)
                + _clamp(self.daily_support_time / DAILY_SUPPORT_TIME_MAX)
            )
            / 3
        )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "SISItemRating":
        area = str(config["activity_area"])
        if area not in SIS_ACTIVITY_AREAS:
            raise ValueError(
                f"Unknown SIS activity area '{area}'. "
                f"Expected one of {SIS_ACTIVITY_AREAS}."
            )
        return cls(
            activity_area=area,
            sequence=int(config.get("sequence", 0)),
            support_type=float(config["support_type"]),
            frequency=float(config["frequency"]),
            daily_support_time=float(config["daily_support_time"]),
        )


@dataclass(frozen=True)
class SISProfile:
    """SIS-A-inspired support-intensity scaffold for one simulated person.

    `partner_areas` optionally maps support partners to the activity areas
    they usually cover, so partner dependency weights can be calibrated from
    rated support intensity instead of hand-specified values.
    """

    source: str = "sis_a_scaffold"
    items: tuple[SISItemRating, ...] = ()
    partner_areas: dict[str, tuple[str, ...]] = field(default_factory=dict)

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "SISProfile":
        return cls(
            source=str(config.get("source", "sis_a_scaffold")),
            items=tuple(
                SISItemRating.from_config(item) for item in config.get("items", ())
            ),
            partner_areas={
                str(partner): tuple(str(area) for area in areas)
                for partner, areas in config.get("partner_areas", {}).items()
            },
        )

    def area_intensities(self) -> dict[str, float]:
        """Mean normalized intensity per rated activity area."""
        totals: dict[str, list[float]] = {}
        for item in self.items:
            totals.setdefault(item.activity_area, []).append(item.intensity)
        return {
            area: sum(values) / len(values)
            for area, values in totals.items()
        }

    def domain_intensities(self) -> dict[str, float]:
        """Simulation-domain support intensities derived from rated areas."""
        areas = self.area_intensities()
        domain_values: dict[str, list[float]] = {}
        for area, intensity in areas.items():
            for domain in AREA_TO_SIM_DOMAINS.get(area, ()):
                domain_values.setdefault(domain, []).append(intensity)
        return {
            domain: _clamp(sum(values) / len(values))
            for domain, values in domain_values.items()
        }

    def overall_intensity(self) -> float:
        areas = self.area_intensities()
        if not areas:
            return 0.0
        return _clamp(sum(areas.values()) / len(areas))

    def self_sufficiency_index(self) -> float:
        """Scaffold self-sufficiency estimate: inverse of overall intensity.

        This is not the normed SIS-A Support Needs Index.
        """
        if not self.items:
            return 0.5
        return _clamp(1.0 - self.overall_intensity())

    def partner_dependency_weights(
        self,
        fallback_weights: dict[str, float] | None = None,
    ) -> dict[str, float]:
        """Calibrate partner dependency weights from rated area intensities.

        A partner mapped to activity areas receives the mean intensity of
        their rated areas. Partners without area mappings keep their
        hand-specified fallback weight.
        """
        fallback_weights = dict(fallback_weights or {})
        areas = self.area_intensities()
        weights = dict(fallback_weights)
        for partner, partner_area_names in self.partner_areas.items():
            rated = [areas[area] for area in partner_area_names if area in areas]
            if rated:
                weights[partner] = _clamp(sum(rated) / len(rated))
        return weights
