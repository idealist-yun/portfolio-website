from __future__ import annotations

from typing import Any

from idd_agent_sim.clinical.vineland import (
    CONTENT_CATEGORY_SKILL_MAP,
    KVINELAND_SURVEY_STRUCTURE,
    clamp,
    shape_synthetic_skill_scores,
)


def generate_synthetic_vineland_profile(config: dict[str, Any]) -> dict[str, Any]:
    seed_scores = {
        str(skill_code): clamp(float(score))
        for skill_code, score in config.get("seed_skill_scores", {}).items()
    }
    shaped_scores = (
        shape_synthetic_skill_scores(
            seed_scores,
            minimum_prerequisite_ratio=float(
                config.get("minimum_prerequisite_ratio", 0.65)
            ),
        )
        if config.get("apply_generation_priors", True)
        else seed_scores
    )

    profile = {
        "id": str(config["id"]),
        "self_sufficiency": float(config.get("self_sufficiency", 0.55)),
        "vineland": {
            "source": str(config.get("source", "synthetic_k_vineland_generation_priors")),
            "items": skill_scores_to_vineland_items(shaped_scores),
        },
        "support": dict(config.get("support", {"caregiver": 0.8, "teacher": 0.55})),
        "character": dict(config.get("character", {})),
    }
    return profile


def generate_synthetic_vineland_profile_batch(
    config: dict[str, Any],
) -> list[dict[str, Any]]:
    defaults = dict(config.get("defaults", {}))
    profiles = []
    for item in config.get("profiles", ()):
        merged = {
            **defaults,
            **item,
            "support": {
                **dict(defaults.get("support", {})),
                **dict(item.get("support", {})),
            },
            "character": {
                **dict(defaults.get("character", {})),
                **dict(item.get("character", {})),
            },
        }
        profiles.append(generate_synthetic_vineland_profile(merged))
    return profiles


def skill_scores_to_vineland_items(skill_scores: dict[str, float]) -> list[dict[str, Any]]:
    item_map = functional_skill_item_map()
    items = []
    for skill_code, score in skill_scores.items():
        if skill_code not in item_map:
            continue
        subdomain, sequence, content_category = item_map[skill_code]
        items.append(
            {
                "subdomain": subdomain,
                "sequence": sequence,
                "content_category": content_category,
                "score": raw_vineland_score(score),
            }
        )
    return sorted(
        items,
        key=lambda item: (str(item["subdomain"]), int(item["sequence"])),
    )


def functional_skill_item_map() -> dict[str, tuple[str, int, str]]:
    item_map: dict[str, tuple[str, int, str]] = {}
    for structure in KVINELAND_SURVEY_STRUCTURE.values():
        subdomain = str(structure["korean_subdomain"])
        for index, content_category in enumerate(structure["content_categories"], start=1):
            if content_category not in CONTENT_CATEGORY_SKILL_MAP:
                continue
            skill_code = CONTENT_CATEGORY_SKILL_MAP[content_category][0]
            item_map[skill_code] = (subdomain, index * 4, content_category)
    return item_map


def raw_vineland_score(score: float) -> int:
    normalized = clamp(score)
    if normalized >= 0.85:
        return 2
    if normalized >= 0.45:
        return 1
    return 0
