import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


SUBDOMAIN_ALIASES = {
    "receptive": "receptive",
    "Receptive": "receptive",
    "expressive": "expressive",
    "Expressive": "expressive",
    "written": "written",
    "Written": "written",
    "personal": "personal",
    "Personal": "personal",
    "domestic": "domestic",
    "Domestic": "domestic",
    "community": "community",
    "Community": "community",
    "interpersonal_relationships": "interpersonal_relationships",
    "interpersonal": "interpersonal_relationships",
    "Interpersonal Relationships": "interpersonal_relationships",
    "play_and_leisure": "play_and_leisure",
    "Play and Leisure": "play_and_leisure",
    "coping_skills": "coping_skills",
    "Coping Skills": "coping_skills",
    "gross_motor": "gross_motor",
    "fine_motor": "fine_motor",
    "internalizing": "internalizing",
    "externalizing": "externalizing",
}

KVINELAND_SURVEY_STRUCTURE = {
    "receptive": {
        "domain": "communication",
        "korean_domain": "Communication",
        "korean_subdomain": "Receptive",
        "item_count": 20,
        "content_categories": ("Understanding", "Listening and Attending", "Following Instructions"),
    },
    "expressive": {
        "domain": "communication",
        "korean_domain": "Communication",
        "korean_subdomain": "Expressive",
        "item_count": 54,
        "content_categories": ("Prelinguistic", "Beginning Speech", "Conversing", "Conversation Skills", "Expressing Complex Ideas"),
    },
    "written": {
        "domain": "communication",
        "korean_domain": "Communication",
        "korean_subdomain": "Written",
        "item_count": 25,
        "content_categories": ("Beginning Reading", "Writing Skills", "Reading Skills"),
    },
    "personal": {
        "domain": "daily_living_skills",
        "korean_domain": "Daily Living Skills",
        "korean_subdomain": "Personal",
        "item_count": 41,
        "content_categories": ("Eating and Drinking", "Toileting", "Dressing", "Health Care", "Body Care", "Washing"),
    },
    "domestic": {
        "domain": "daily_living_skills",
        "korean_domain": "Daily Living Skills",
        "korean_subdomain": "Domestic",
        "item_count": 24,
        "content_categories": ("Safety Management", "Kitchen Tasks", "Housekeeping"),
    },
    "community": {
        "domain": "daily_living_skills",
        "korean_domain": "Daily Living Skills",
        "korean_subdomain": "Community",
        "item_count": 44,
        "content_categories": (
            "Telephone Skills",
            "Television and Radio",
            "Money Management",
            "Rules, Rights, Safety",
            "Time and Dates",
            "Computer Skills",
            "Restaurant Skills",
            "Job Skills",
            "Getting Around",
        ),
    },
    "interpersonal_relationships": {
        "domain": "socialization",
        "korean_domain": "Socialization",
        "korean_subdomain": "Interpersonal Relationships",
        "item_count": 38,
        "content_categories": (
            "Responding to Others",
            "Emotion Recognition and Expression",
            "Social Communication",
            "Imitation",
            "Making Friends",
            "Consideration",
            "Dating",
        ),
    },
    "play_and_leisure": {
        "domain": "socialization",
        "korean_domain": "Socialization",
        "korean_subdomain": "Play and Leisure",
        "item_count": 31,
        "content_categories": ("Playing", "Sharing and Cooperation", "Games", "Going Out with Friends", "Recognizing Social Cues"),
    },
    "coping_skills": {
        "domain": "socialization",
        "korean_domain": "Socialization",
        "korean_subdomain": "Coping Skills",
        "item_count": 30,
        "content_categories": (
            "Transitions",
            "Manners",
            "Apologizing",
            "Impulse Control",
            "Recognizing Social Risks",
            "Responsibility",
            "Keeping Secrets",
        ),
    },
}

CONTENT_CATEGORY_SKILL_MAP = {
    "Understanding": ("understand_concrete_information", ("verify_information",), ("visual_cue",)),
    "Listening and Attending": ("attend_to_spoken_information", ("sustain_task",), ("repeated_cue",)),
    "Following Instructions": ("follow_instructions", ("sequence_task",), ("single_step_instruction",)),
    "Prelinguistic": ("express_need_nonverbally", ("request_support",), ("supported_choice_or_aac",)),
    "Beginning Speech": ("express_basic_needs", ("request_support",), ("supported_choice_or_aac",)),
    "Conversing": ("participate_in_conversation", ("request_support", "verify_information"), ("communication_prompt",)),
    "Conversation Skills": ("use_conversation_strategy", ("request_support", "verify_information"), ("communication_prompt",)),
    "Expressing Complex Ideas": ("explain_complex_information", ("verify_information",), ("structured_choice",)),
    "Beginning Reading": ("recognize_written_symbols", ("verify_information",), ("visual_cue",)),
    "Writing Skills": ("write_functional_information", ("verify_information",), ("written_prompt",)),
    "Reading Skills": ("read_functional_information", ("verify_information",), ("written_prompt",)),
    "Eating and Drinking": ("eat_and_drink", ("sequence_task",), ("task_breakdown_for_self_care",)),
    "Toileting": ("toileting_routine", ("sequence_task", "sustain_task"), ("privacy_and_step_prompt",)),
    "Dressing": ("dressing_routine", ("sequence_task",), ("task_breakdown_for_self_care",)),
    "Health Care": ("health_management", ("verify_information", "sequence_task"), ("caregiver_check_in",)),
    "Body Care": ("body_care", ("sequence_task",), ("task_breakdown_for_self_care",)),
    "Washing": ("washing_routine", ("sequence_task", "sustain_task"), ("task_breakdown_for_self_care",)),
    "Safety Management": ("home_safety", ("check_prerequisites",), ("safety_prompt",)),
    "Kitchen Tasks": ("kitchen_task", ("sequence_task", "check_prerequisites"), ("supervised_domestic_task",)),
    "Housekeeping": ("household_organization", ("sequence_task",), ("visual_checklist",)),
    "Telephone Skills": ("phone_use", ("request_support", "verify_information"), ("communication_prompt",)),
    "Television and Radio": ("media_use", ("verify_information",), ("visual_cue",)),
    "Money Management": ("money_management", ("verify_information",), ("caregiver_check_in",)),
    "Rules, Rights, Safety": ("community_safety_rules", ("check_prerequisites", "verify_information"), ("safety_prompt",)),
    "Time and Dates": ("time_orientation", ("verify_information",), ("visual_schedule",)),
    "Computer Skills": ("computer_use", ("verify_information",), ("guided_technology_use",)),
    "Restaurant Skills": ("restaurant_skill", ("request_support", "verify_information"), ("community_script",)),
    "Job Skills": ("work_routine", ("sequence_task", "sustain_task"), ("work_task_breakdown",)),
    "Getting Around": ("community_navigation", ("navigate_environment",), ("guided_community_navigation",)),
    "Responding to Others": ("respond_to_others", ("request_support",), ("social_prompt",)),
    "Emotion Recognition and Expression": ("recognize_and_express_emotion", ("request_support",), ("emotion_labeling_support",)),
    "Social Communication": ("social_communication", ("request_support", "verify_information"), ("social_prompt",)),
    "Imitation": ("imitate_model", ("sequence_task",), ("modeling_prompt",)),
    "Making Friends": ("make_friends", ("request_support",), ("social_prompt",)),
    "Consideration": ("show_consideration", ("request_support",), ("social_prompt",)),
    "Dating": ("romantic_social_boundary", ("verify_information",), ("social_boundary_support",)),
    "Playing": ("play_skill", ("sustain_task",), ("structured_leisure_choice",)),
    "Sharing and Cooperation": ("share_and_cooperate", ("request_support",), ("cooperative_prompt",)),
    "Games": ("game_rule_following", ("sequence_task", "sustain_task"), ("rule_visualization",)),
    "Going Out with Friends": ("peer_navigation", ("navigate_environment",), ("peer_or_caregiver_accompaniment",)),
    "Recognizing Social Cues": ("recognize_social_cues", ("verify_information",), ("explicit_social_cue",)),
    "Transitions": ("transition_between_activities", ("replan_after_block",), ("transition_warning_and_regulation_time",)),
    "Manners": ("use_manners", ("request_support",), ("social_script",)),
    "Apologizing": ("repair_social_mistake", ("request_support",), ("social_script",)),
    "Impulse Control": ("impulse_control", ("replan_after_block",), ("regulation_support",)),
    "Recognizing Social Risks": ("recognize_social_risk", ("check_prerequisites", "verify_information"), ("safety_prompt",)),
    "Responsibility": ("responsibility_follow_through", ("sustain_task",), ("visual_checklist",)),
    "Keeping Secrets": ("privacy_and_confidentiality", ("verify_information",), ("social_boundary_support",)),
}

SUBDOMAIN_FALLBACK_SKILL_MAP = {
    "receptive": ("receptive_communication", ("verify_information",), ("visual_cue",)),
    "expressive": ("expressive_communication", ("request_support",), ("supported_choice_or_aac",)),
    "written": ("functional_literacy", ("verify_information",), ("written_prompt",)),
    "personal": ("personal_daily_living", ("sequence_task",), ("task_breakdown_for_self_care",)),
    "domestic": ("domestic_daily_living", ("sequence_task",), ("visual_checklist",)),
    "community": ("community_daily_living", ("navigate_environment", "verify_information"), ("guided_community_navigation",)),
    "interpersonal_relationships": ("interpersonal_socialization", ("request_support",), ("social_prompt",)),
    "play_and_leisure": ("leisure_socialization", ("sustain_task",), ("structured_leisure_choice",)),
    "coping_skills": ("coping_and_regulation", ("replan_after_block",), ("transition_warning_and_regulation_time",)),
}

FUNCTIONAL_SKILL_PREREQUISITES = {
    "understand_concrete_information": (),
    "attend_to_spoken_information": ("understand_concrete_information",),
    "follow_instructions": ("understand_concrete_information", "attend_to_spoken_information"),
    "express_need_nonverbally": (),
    "express_basic_needs": ("express_need_nonverbally",),
    "participate_in_conversation": ("express_basic_needs", "attend_to_spoken_information"),
    "use_conversation_strategy": ("participate_in_conversation",),
    "explain_complex_information": ("use_conversation_strategy", "understand_concrete_information"),
    "recognize_written_symbols": ("understand_concrete_information",),
    "write_functional_information": ("recognize_written_symbols",),
    "read_functional_information": ("recognize_written_symbols",),
    "eat_and_drink": (),
    "toileting_routine": ("follow_instructions",),
    "dressing_routine": ("follow_instructions",),
    "health_management": ("understand_concrete_information", "follow_instructions"),
    "body_care": ("follow_instructions",),
    "washing_routine": ("body_care", "follow_instructions"),
    "home_safety": ("understand_concrete_information",),
    "kitchen_task": ("home_safety", "follow_instructions"),
    "household_organization": ("follow_instructions", "responsibility_follow_through"),
    "phone_use": ("express_basic_needs", "understand_concrete_information"),
    "media_use": ("recognize_written_symbols", "understand_concrete_information"),
    "money_management": ("understand_concrete_information", "recognize_written_symbols"),
    "community_safety_rules": ("home_safety", "understand_concrete_information"),
    "time_orientation": ("recognize_written_symbols",),
    "computer_use": ("recognize_written_symbols", "follow_instructions"),
    "restaurant_skill": ("participate_in_conversation", "money_management"),
    "work_routine": ("follow_instructions", "time_orientation", "responsibility_follow_through"),
    "community_navigation": ("community_safety_rules", "time_orientation", "phone_use"),
    "respond_to_others": (),
    "recognize_and_express_emotion": ("respond_to_others",),
    "social_communication": ("respond_to_others", "express_basic_needs"),
    "imitate_model": ("respond_to_others", "attend_to_spoken_information"),
    "make_friends": ("social_communication", "share_and_cooperate"),
    "show_consideration": ("recognize_and_express_emotion", "social_communication"),
    "romantic_social_boundary": ("recognize_social_risk", "social_communication"),
    "play_skill": (),
    "share_and_cooperate": ("play_skill", "respond_to_others"),
    "game_rule_following": ("share_and_cooperate", "follow_instructions"),
    "peer_navigation": ("community_navigation", "share_and_cooperate"),
    "recognize_social_cues": ("social_communication", "recognize_and_express_emotion"),
    "transition_between_activities": ("follow_instructions",),
    "use_manners": ("respond_to_others", "social_communication"),
    "repair_social_mistake": ("recognize_and_express_emotion", "use_manners"),
    "impulse_control": ("transition_between_activities", "recognize_and_express_emotion"),
    "recognize_social_risk": ("recognize_social_cues", "community_safety_rules"),
    "responsibility_follow_through": ("follow_instructions", "transition_between_activities"),
    "privacy_and_confidentiality": ("recognize_social_risk", "responsibility_follow_through"),
}


@dataclass(frozen=True)
class VinelandItemResponse:
    subdomain: str
    sequence: int
    score: float
    content_category: str | None = None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "VinelandItemResponse | None":
        raw_score = config.get("score")
        if raw_score in {None, "DK", "N/O", "NA"}:
            return None
        return cls(
            subdomain=canonical_subdomain(str(config["subdomain"])),
            sequence=int(config["sequence"]),
            score=clamp(float(raw_score) / 2.0),
            content_category=(
                str(config["content_category"])
                if config.get("content_category") not in {None, ""}
                else None
            ),
        )


@dataclass(frozen=True)
class VinelandSkillEvidence:
    subdomain: str
    sequence: int
    content_category: str | None
    functional_skill_code: str
    simulation_skills: tuple[str, ...]
    support_conditions: tuple[str, ...]
    prerequisite_skill_codes: tuple[str, ...]
    score: float

    @property
    def access_level(self) -> str:
        if self.score >= 0.85:
            return "independent"
        if self.score >= 0.45:
            return "supported"
        return "limited"

    @property
    def developmental_level(self) -> str:
        if self.sequence <= 10:
            return "foundational"
        if self.sequence <= 25:
            return "intermediate"
        return "advanced"


@dataclass(frozen=True)
class VinelandGenerationPrior:
    target_skill_code: str
    prerequisite_skill_codes: tuple[str, ...]
    target_sequence: int | None = None
    usage: str = "synthetic_profile_generation"


@dataclass(frozen=True)
class VinelandSkillAccessSpec:
    skill_name: str
    domain: str
    access_level: str
    source_subdomains: tuple[str, ...]


@dataclass(frozen=True)
class VinelandProfile:
    subdomain_scores: dict[str, float]
    item_responses: tuple[VinelandItemResponse, ...] = ()
    source: str = "k_vineland_ii_scaffold"

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "VinelandProfile":
        item_responses = tuple(
            response
            for item in config.get("items", ())
            if (response := VinelandItemResponse.from_config(item)) is not None
        )
        item_scores = aggregate_item_scores(item_responses)
        subdomain_scores = dict(item_scores)
        for raw_key, value in config.get("subdomains", {}).items():
            subdomain_scores[canonical_subdomain(str(raw_key))] = clamp(float(value))
        return cls(
            subdomain_scores=subdomain_scores,
            item_responses=item_responses,
            source=str(config.get("source", "k_vineland_ii_scaffold")),
        )

    def score_for(self, subdomain: str, default: float = 0.5) -> float:
        return self.subdomain_scores.get(canonical_subdomain(subdomain), default)

    def domain_scores(self, fallback: dict[str, float] | None = None) -> dict[str, float]:
        fallback = fallback or {}
        communication = average_available(
            self.score_for("receptive", fallback.get("communication", 0.5)),
            self.score_for("expressive", fallback.get("communication", 0.5)),
            self.score_for("written", fallback.get("communication", 0.5)),
        )
        daily = average_available(
            self.score_for("personal", fallback.get("daily_living_skills", 0.5)),
            self.score_for("domestic", fallback.get("daily_living_skills", 0.5)),
            self.score_for("community", fallback.get("daily_living_skills", 0.5)),
        )
        social = average_available(
            self.score_for("interpersonal_relationships", fallback.get("socialization", 0.5)),
            self.score_for("play_and_leisure", fallback.get("socialization", 0.5)),
            self.score_for("coping_skills", fallback.get("socialization", 0.5)),
        )
        motor = average_available(
            self.score_for("gross_motor", fallback.get("motor_skills", 0.5)),
            self.score_for("fine_motor", fallback.get("motor_skills", 0.5)),
        )
        maladaptive = average_available(
            self.score_for("internalizing", fallback.get("maladaptive_behavior", 0.2)),
            self.score_for("externalizing", fallback.get("maladaptive_behavior", 0.2)),
        )
        return {
            "communication": communication,
            "daily_living_skills": daily,
            "socialization": social,
            "motor_skills": motor,
            "maladaptive_behavior": maladaptive,
        }

    def adaptive_capacities(self, self_sufficiency: float) -> dict[str, float]:
        personal = self.score_for("personal", self_sufficiency)
        domestic = self.score_for("domestic", self_sufficiency)
        community = self.score_for("community", self_sufficiency)
        receptive = self.score_for("receptive", self_sufficiency)
        expressive = self.score_for("expressive", self_sufficiency)
        coping = self.score_for("coping_skills", self_sufficiency)
        return {
            "self_care": personal,
            "meal": average_available(personal, domestic),
            "household_tasks": domestic,
            "mobility": average_available(community, coping),
            "community": average_available(community, receptive, expressive),
            "activity": average_available(community, receptive, coping),
            "default": self_sufficiency,
        }

    def support_intensities(self) -> dict[str, float]:
        capacities = self.adaptive_capacities(self_sufficiency=0.5)
        return {
            domain: clamp(1.0 - capacity)
            for domain, capacity in capacities.items()
            if domain != "default"
        }

    def skill_access_specs(self, has_support: bool) -> tuple[VinelandSkillAccessSpec, ...]:
        specs = [
            VinelandSkillAccessSpec("check_prerequisites", "general", "independent", ("receptive",)),
            VinelandSkillAccessSpec("replan_after_block", "general", "state_dependent", ("coping_skills",)),
        ]
        if has_support and self.score_for("expressive", 0.5) >= 0.25:
            specs.append(
                VinelandSkillAccessSpec(
                    "request_support",
                    "general",
                    access_level_for(self.score_for("expressive"), independent_at=0.70),
                    ("expressive", "interpersonal_relationships"),
                )
            )
        specs.extend(
            [
                VinelandSkillAccessSpec(
                    "locate_object",
                    "self_care",
                    supported_access(
                        average_available(self.score_for("personal"), self.score_for("receptive")),
                        has_support,
                    ),
                    ("personal", "receptive"),
                ),
                VinelandSkillAccessSpec(
                    "sequence_task",
                    "self_care",
                    supported_access(
                        average_available(
                            self.score_for("personal"),
                            self.score_for("receptive"),
                            self.score_for("coping_skills"),
                        ),
                        has_support,
                    ),
                    ("personal", "receptive", "coping_skills"),
                ),
                VinelandSkillAccessSpec(
                    "sustain_task",
                    "self_care",
                    access_level_for(
                        average_available(self.score_for("personal"), self.score_for("coping_skills")),
                        independent_at=0.70,
                    ),
                    ("personal", "coping_skills"),
                ),
                VinelandSkillAccessSpec(
                    "navigate_environment",
                    "activity",
                    supported_access(
                        average_available(self.score_for("community"), self.score_for("coping_skills")),
                        has_support,
                    ),
                    ("community", "coping_skills"),
                ),
                VinelandSkillAccessSpec(
                    "verify_information",
                    "activity",
                    supported_access(
                        average_available(
                            self.score_for("receptive"),
                            self.score_for("expressive"),
                            self.score_for("written"),
                            self.score_for("community"),
                        ),
                        has_support,
                    ),
                    ("receptive", "expressive", "written", "community"),
                ),
            ]
        )
        return tuple(specs)

    def prompt_conditions(self) -> tuple[str, ...]:
        prompts: list[str] = []
        if self.score_for("receptive") < 0.45:
            prompts.extend(["single_step_instruction", "visual_cue"])
        if self.score_for("expressive") < 0.45:
            prompts.append("supported_choice_or_aac")
        if self.score_for("personal") < 0.45:
            prompts.append("task_breakdown_for_self_care")
        if self.score_for("community") < 0.45:
            prompts.append("guided_community_navigation")
        if self.score_for("coping_skills") < 0.45:
            prompts.append("transition_warning_and_regulation_time")
        for evidence in self.skill_evidence():
            if evidence.access_level != "independent":
                prompts.extend(evidence.support_conditions)
        return tuple(dict.fromkeys(prompts))

    def skill_evidence(self) -> tuple[VinelandSkillEvidence, ...]:
        return tuple(item_to_skill_evidence(item) for item in self.item_responses)

    def prerequisite_graph(self) -> dict[str, tuple[str, ...]]:
        return {
            evidence.functional_skill_code: evidence.prerequisite_skill_codes
            for evidence in self.skill_evidence()
        }

    def generation_priors(self) -> tuple[VinelandGenerationPrior, ...]:
        return tuple(
            VinelandGenerationPrior(
                target_skill_code=evidence.functional_skill_code,
                prerequisite_skill_codes=evidence.prerequisite_skill_codes,
                target_sequence=evidence.sequence,
            )
            for evidence in self.skill_evidence()
            if evidence.prerequisite_skill_codes
        )

    @classmethod
    def from_response_csv(
        cls,
        path: str | Path,
        *,
        source: str = "k_vineland_ii_response_csv",
    ) -> "VinelandProfile":
        with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            items = [
                {
                    "subdomain": row.get("subdomain") or row.get("Subdomain"),
                    "sequence": row.get("sequence") or row.get("Sequence"),
                    "score": row.get("score") or row.get("Score"),
                    "content_category": (
                        row.get("content_category")
                        or row.get("Content Category")
                        or row.get("category")
                        or row.get("Category")
                    ),
                }
                for row in reader
            ]
        return cls.from_config({"source": source, "items": items})


def canonical_subdomain(value: str) -> str:
    normalized = value.strip()
    if normalized not in SUBDOMAIN_ALIASES:
        raise ValueError(f"Unknown Vineland subdomain: {value}")
    return SUBDOMAIN_ALIASES[normalized]


def aggregate_item_scores(items: tuple[VinelandItemResponse, ...]) -> dict[str, float]:
    grouped: dict[str, list[float]] = {}
    for item in items:
        grouped.setdefault(item.subdomain, []).append(item.score)
    return {
        subdomain: sum(scores) / len(scores)
        for subdomain, scores in grouped.items()
        if scores
    }


def item_to_skill_evidence(item: VinelandItemResponse) -> VinelandSkillEvidence:
    if item.content_category and item.content_category in CONTENT_CATEGORY_SKILL_MAP:
        functional_code, simulation_skills, support_conditions = CONTENT_CATEGORY_SKILL_MAP[
            item.content_category
        ]
    else:
        functional_code, simulation_skills, support_conditions = SUBDOMAIN_FALLBACK_SKILL_MAP[
            item.subdomain
        ]
    return VinelandSkillEvidence(
        subdomain=item.subdomain,
        sequence=item.sequence,
        content_category=item.content_category,
        functional_skill_code=functional_code,
        simulation_skills=simulation_skills,
        support_conditions=support_conditions,
        prerequisite_skill_codes=FUNCTIONAL_SKILL_PREREQUISITES.get(functional_code, ()),
        score=item.score,
    )


def vineland_generation_priors(
    skill_codes: tuple[str, ...] | None = None,
) -> tuple[VinelandGenerationPrior, ...]:
    selected = set(skill_codes) if skill_codes is not None else None
    return tuple(
        VinelandGenerationPrior(
            target_skill_code=skill_code,
            prerequisite_skill_codes=prerequisite_codes,
            target_sequence=None,
        )
        for skill_code, prerequisite_codes in FUNCTIONAL_SKILL_PREREQUISITES.items()
        if prerequisite_codes and (selected is None or skill_code in selected)
    )


def shape_synthetic_skill_scores(
    seed_scores: dict[str, float],
    priors: tuple[VinelandGenerationPrior, ...] | None = None,
    *,
    minimum_prerequisite_ratio: float = 0.65,
) -> dict[str, float]:
    """Use Vineland hierarchy priors to make generated profiles more coherent.

    This is only for virtual-person generation. It should not be used to
    correct, reject, or reinterpret real caregiver-reported Vineland responses.
    """

    shaped = {skill_code: clamp(score) for skill_code, score in seed_scores.items()}
    generation_priors = priors or vineland_generation_priors()
    ratio = clamp(minimum_prerequisite_ratio)

    for _ in range(len(generation_priors) + 1):
        changed = False
        for prior in generation_priors:
            if prior.target_skill_code not in shaped:
                continue
            minimum_score = clamp(shaped[prior.target_skill_code] * ratio)
            for prerequisite in prior.prerequisite_skill_codes:
                current_score = shaped.get(prerequisite, 0.0)
                if current_score < minimum_score:
                    shaped[prerequisite] = minimum_score
                    changed = True
        if not changed:
            break

    return shaped


def average_available(*values: float) -> float:
    available = [value for value in values if value is not None]
    if not available:
        return 0.5
    return clamp(sum(available) / len(available))


def access_level_for(score: float, *, independent_at: float = 0.60) -> str:
    return "independent" if score >= independent_at else "state_dependent"


def supported_access(score: float, has_support: bool) -> str:
    if score >= 0.60:
        return "independent"
    return "supported" if has_support else "state_dependent"


def load_vineland_response_csv(path: str | Path) -> VinelandProfile:
    return VinelandProfile.from_response_csv(path)


def load_vineland_response_items(path: str | Path) -> list[dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        return [
            {
                "subdomain": row.get("subdomain") or row.get("Subdomain"),
                "sequence": row.get("sequence") or row.get("Sequence"),
                "score": row.get("score") or row.get("Score"),
                "content_category": (
                    row.get("content_category")
                    or row.get("Content Category")
                    or row.get("category")
                    or row.get("Category")
                ),
            }
            for row in reader
        ]
