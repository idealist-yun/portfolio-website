"""Virtual-person builder.

Creates complete, internally consistent virtual-person profiles from named
templates: K-Vineland-style synthetic items (via generation priors), SIS-A
scaffold ratings whose intensities mirror the functional levels, a
five-dimension character block, and partner-area mappings. Every generated
profile is synthetic virtual-person data, never real-person assessment
output.

Templates express clinical intent at the subdomain level; the builder turns
them into the concrete structures the simulation consumes, so a new virtual
person plus a runnable pipeline is one function (or one CLI) call away.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from idd_agent_sim.clinical.synthetic import (
    functional_skill_item_map,
    generate_synthetic_vineland_profile,
)
from idd_agent_sim.clinical.vineland import KVINELAND_SURVEY_STRUCTURE, clamp

# english subdomain -> korean questionnaire subdomain
_SUBDOMAIN_KOREAN = {
    key: str(structure["korean_subdomain"])
    for key, structure in KVINELAND_SURVEY_STRUCTURE.items()
}

DEFAULT_SUBDOMAIN_LEVEL = 0.6

TEMPLATES: dict[str, dict[str, Any]] = {
    "communication_support_needs": {
        "description": (
            "Strong daily living skills; receptive/expressive language "
            "requires prompting, so verification-heavy steps bottleneck."
        ),
        "subdomain_levels": {
            "receptive": 0.30,
            "expressive": 0.35,
            "written": 0.40,
            "personal": 0.90,
            "domestic": 0.85,
            "community": 0.50,
            "interpersonal_relationships": 0.55,
            "play_and_leisure": 0.60,
            "coping_skills": 0.60,
        },
        "sis_area_targets": {
            "home_living": 0.25,
            "community_living": 0.55,
            "health_safety": 0.50,
            "social_activities": 0.45,
            "lifelong_learning": 0.60,
        },
        "support": {"caregiver": 0.5, "speech_therapist": 0.5},
        "partner_areas": {
            "caregiver": ["home_living", "health_safety"],
            "speech_therapist": ["lifelong_learning", "social_activities"],
        },
        "character": {
            "basic_information": {"age": 19, "setting": "family home"},
            "current_state": {"mood": "neutral"},
            "traits": {"agreeableness": 0.7, "extraversion": 0.3},
            "conflicts": {"wanting_to_be_understood": 0.7},
            "preferences": {
                "routines": ["picture schedule"],
                "support_style": ["visual cue before verbal prompt"],
            },
        },
    },
    "daily_living_support_needs": {
        "description": (
            "Communicates well; personal/domestic routines need sequencing "
            "and sustained-attention support."
        ),
        "subdomain_levels": {
            "receptive": 0.90,
            "expressive": 0.85,
            "written": 0.85,
            "personal": 0.30,
            "domestic": 0.25,
            "community": 0.50,
            "interpersonal_relationships": 0.65,
            "play_and_leisure": 0.60,
            "coping_skills": 0.45,
        },
        "sis_area_targets": {
            "home_living": 0.70,
            "community_living": 0.45,
            "health_safety": 0.55,
            "social_activities": 0.30,
            "lifelong_learning": 0.40,
        },
        "support": {"caregiver": 0.6, "occupational_therapist": 0.5},
        "partner_areas": {
            "caregiver": ["home_living", "health_safety"],
            "occupational_therapist": ["home_living", "lifelong_learning"],
        },
        "character": {
            "basic_information": {"age": 24, "setting": "supported apartment"},
            "current_state": {"mood": "neutral"},
            "traits": {"conscientiousness": 0.4, "neuroticism": 0.55},
            "conflicts": {"independence_vs_safety": 0.7},
            "preferences": {
                "routines": ["same order every day", "timer for each step"],
                "support_style": ["demonstration before independent attempt"],
            },
        },
    },
    "high_support_needs": {
        "description": (
            "Substantial support needs across domains; most ADL steps are "
            "support-mediated with physical assistance at motor steps."
        ),
        "subdomain_levels": {
            "receptive": 0.25,
            "expressive": 0.20,
            "written": 0.15,
            "personal": 0.25,
            "domestic": 0.20,
            "community": 0.20,
            "interpersonal_relationships": 0.35,
            "play_and_leisure": 0.40,
            "coping_skills": 0.30,
        },
        "sis_area_targets": {
            "home_living": 0.80,
            "community_living": 0.85,
            "health_safety": 0.80,
            "social_activities": 0.60,
            "lifelong_learning": 0.75,
        },
        "support": {"caregiver": 0.8, "support_worker": 0.7},
        "partner_areas": {
            "caregiver": ["home_living", "health_safety", "social_activities"],
            "support_worker": ["community_living", "lifelong_learning"],
        },
        "character": {
            "basic_information": {"age": 27, "setting": "group home"},
            "current_state": {"mood": "settled"},
            "traits": {"agreeableness": 0.75, "openness": 0.35},
            "conflicts": {"comfort_vs_new_experiences": 0.6},
            "preferences": {
                "routines": ["familiar caregiver present", "quiet environment"],
                "support_style": ["hand-over-hand for new motor tasks"],
            },
        },
    },
    "emerging_independence": {
        "description": (
            "Near-independent across domains; occasional monitoring-level "
            "support at community verification steps."
        ),
        "subdomain_levels": {
            "receptive": 0.90,
            "expressive": 0.88,
            "written": 0.86,
            "personal": 0.92,
            "domestic": 0.88,
            "community": 0.75,
            "interpersonal_relationships": 0.88,
            "play_and_leisure": 0.86,
            "coping_skills": 0.85,
        },
        "sis_area_targets": {
            "home_living": 0.20,
            "community_living": 0.35,
            "health_safety": 0.25,
            "social_activities": 0.20,
            "lifelong_learning": 0.30,
        },
        "support": {"job_coach": 0.4, "peer": 0.3},
        "partner_areas": {
            "job_coach": ["community_living", "lifelong_learning"],
            "peer": ["social_activities"],
        },
        "character": {
            "basic_information": {"age": 22, "setting": "independent living training"},
            "current_state": {"mood": "neutral"},
            "traits": {"conscientiousness": 0.65, "extraversion": 0.55},
            "conflicts": {"independence_vs_safety": 0.45},
            "preferences": {
                "routines": ["self-checklist review"],
                "support_style": ["check-in after, not during"],
            },
        },
    },
}


def template_names() -> list[str]:
    return sorted(TEMPLATES)


def build_virtual_person(
    template: str,
    person_id: str,
    subdomain_overrides: dict[str, float] | None = None,
) -> dict[str, Any]:
    """Build a full profile config dict from a template."""
    if template not in TEMPLATES:
        raise KeyError(
            f"Unknown template '{template}'. Available: {template_names()}"
        )
    spec = TEMPLATES[template]
    levels = {**spec["subdomain_levels"], **(subdomain_overrides or {})}
    unknown = set(levels) - set(KVINELAND_SURVEY_STRUCTURE)
    if unknown:
        raise ValueError(
            f"Unknown subdomains {sorted(unknown)}. "
            f"Expected a subset of {sorted(KVINELAND_SURVEY_STRUCTURE)}."
        )

    seed_scores = _seed_scores_from_levels(levels)
    base = generate_synthetic_vineland_profile(
        {
            "id": person_id,
            "seed_skill_scores": seed_scores,
            "source": f"virtual_person_template:{template}",
            "support": spec["support"],
            "character": spec["character"],
        }
    )
    # SIS scaffold ratings mirroring the template's support-intensity intent;
    # self_sufficiency is intentionally omitted so it derives from the SIS
    # scaffold index.
    base.pop("self_sufficiency", None)
    base["sis"] = {
        "source": f"virtual_person_template:{template}",
        "items": _sis_items_from_targets(spec["sis_area_targets"]),
        "partner_areas": {
            partner: list(areas)
            for partner, areas in spec["partner_areas"].items()
        },
    }
    base["template"] = template
    base["template_description"] = spec["description"]
    return base


def _seed_scores_from_levels(levels: dict[str, float]) -> dict[str, float]:
    item_map = functional_skill_item_map()
    korean_to_level = {
        _SUBDOMAIN_KOREAN[subdomain]: clamp(float(level))
        for subdomain, level in levels.items()
    }
    return {
        skill_code: korean_to_level.get(subdomain, DEFAULT_SUBDOMAIN_LEVEL)
        for skill_code, (subdomain, _seq, _cat) in item_map.items()
    }


def _sis_items_from_targets(targets: dict[str, float]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for area, target in sorted(targets.items()):
        intensity = clamp(float(target))
        base_frequency = round(intensity * 4)
        items.append(
            {
                "activity_area": area,
                "sequence": 1,
                "support_type": round(intensity * 2),
                "frequency": base_frequency,
                "daily_support_time": round(intensity * 4),
            }
        )
        items.append(
            {
                "activity_area": area,
                "sequence": 2,
                "support_type": round(intensity * 2),
                "frequency": max(0, min(4, base_frequency - 1)),
                "daily_support_time": round(intensity * 3),
            }
        )
    return items


PROFILE_HEADER = (
    "# Synthetic virtual person generated by the virtual-person builder.\n"
    "# Template: {template} — {description}\n"
    "# This is virtual-person data, not a real assessment.\n"
)


def write_virtual_person(profile: dict[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    header = PROFILE_HEADER.format(
        template=profile.get("template", "custom"),
        description=profile.get("template_description", ""),
    )
    body = yaml.safe_dump(profile, allow_unicode=True, sort_keys=False)
    path.write_text(header + body, encoding="utf-8")
    return path


def build_pipeline_config(
    name: str,
    profile_paths: list[str],
    scenario_path: str = "../../data/scenarios/adl_iadl_expanded.yaml",
    support_availability: float = 0.8,
) -> dict[str, Any]:
    """Pipeline config that runs the generated people through a scenario set.

    The default world environment matches `adl_iadl_expanded.yaml`
    requirements so no step is environment-blocked out of the box.
    """
    return {
        "simulation": {
            "name": name,
            "purpose": "Run generated virtual persons through ADL/IADL scenarios.",
        },
        "outputs": {"dir": f"outputs/{name}"},
        "profile_paths": profile_paths,
        "scenario_path": scenario_path,
        "world": {
            "support_availability": support_availability,
            "environment": {
                "available_objects": [
                    "clothes", "towel", "cereal", "bowl", "medication",
                    "shopping_list", "cleaning_cloth", "dishes",
                    "laundry_basket",
                ],
                "available_people": [
                    "caregiver", "teacher", "job_coach", "peer",
                    "support_worker", "speech_therapist",
                    "occupational_therapist",
                ],
            },
        },
    }


def write_pipeline(config: dict[str, Any], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return path
