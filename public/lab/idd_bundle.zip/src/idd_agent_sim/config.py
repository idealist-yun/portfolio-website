from pathlib import Path
from typing import Any

import yaml


def load_pipeline_config(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as file:
        config = yaml.safe_load(file)
    if not isinstance(config, dict):
        raise ValueError(f"Pipeline config must be a mapping: {path}")
    return config


def load_yaml(path: str | Path) -> dict[str, Any]:
    return load_pipeline_config(path)
