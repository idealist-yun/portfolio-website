"""Self-contained HTML dashboard builder for experiment outputs.

Reads the artifacts written by ``ExperimentRunner`` (events, insights,
summary, comparison/validation reports, caregiver report, sandbox replay)
and produces one dependency-free ``dashboard.html`` file that can be opened
directly in a browser. This is the lightweight local viewer version of the
proposal's interactive analytics dashboard (IDD profile & relationship
tracking plus the interpreter module).
"""

import base64
import json
from pathlib import Path

from idd_agent_sim.dashboard_template import TEMPLATE as _TEMPLATE

_MAP_IMAGE_PATH = Path(__file__).parent / "sandbox" / "assets" / "ville_map.jpg"


def _map_image_data_uri() -> str | None:
    """The pre-rendered Ville map (scripts/render_ville_map.py), inlined."""
    if not _MAP_IMAGE_PATH.exists():
        return None
    encoded = base64.b64encode(_MAP_IMAGE_PATH.read_bytes()).decode("ascii")
    return f"data:image/jpeg;base64,{encoded}"


def _read_json(path: Path):
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list:
    if not path.exists():
        return []
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


def collect_dashboard_data(output_dir: str | Path) -> dict:
    """Gather every experiment artifact the dashboard can render."""
    output_dir = Path(output_dir)
    replay_meta = None
    replay_movement = None
    map_layout = None
    replay_root = output_dir / "sandbox_replay"
    if replay_root.exists():
        for simulation_dir in sorted(replay_root.iterdir()):
            meta_path = simulation_dir / "meta.json"
            movement_path = simulation_dir / "master_movement.json"
            if meta_path.exists() and movement_path.exists():
                replay_meta = _read_json(meta_path)
                replay_movement = _read_json(movement_path)
                map_layout = _read_json(simulation_dir / "map_layout.json")
                break
    return {
        "output_dir": str(output_dir),
        "summary": _read_json(output_dir / "summary.json"),
        "events": _read_jsonl(output_dir / "events.jsonl"),
        "insights": _read_jsonl(output_dir / "insights.jsonl"),
        "comparison": _read_json(output_dir / "comparison_report.json"),
        "bottleneck": _read_json(output_dir / "bottleneck_report.json"),
        "validation": _read_json(output_dir / "validation_report.json"),
        "caregiver_report": _read_text(output_dir / "caregiver_report.txt"),
        "replay_meta": replay_meta,
        "replay_movement": replay_movement,
        "map_layout": map_layout,
        "map_image": _map_image_data_uri(),
    }


def build_dashboard(
    output_dir: str | Path,
    dashboard_path: str | Path | None = None,
) -> Path:
    """Build ``dashboard.html`` inside (or at) the requested location."""
    output_dir = Path(output_dir)
    data = collect_dashboard_data(output_dir)
    if not data["events"]:
        raise FileNotFoundError(
            f"No events.jsonl found in {output_dir}; run an experiment first."
        )
    target = Path(dashboard_path) if dashboard_path else output_dir / "dashboard.html"
    payload = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    target.write_text(
        _TEMPLATE.replace("__DASHBOARD_DATA__", payload),
        encoding="utf-8",
    )
    return target


