"""HTML template for the viewer-first dashboard.

Design intent: the first thing on screen is the Ville with agents living
their day — the Generative Agents demo experience — with playback controls
that work. Analytics live in tabs below the stage and never compete with
the map for attention. UI labels are Korean (the researcher-facing
language); stable English strings are kept in subtitles for tests and
cross-referencing with code/docs.
"""

TEMPLATE = r"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IDD Agent Simulation Dashboard</title>
<style>
:root {
  color-scheme: light dark;
  --bg: #f6f7f9; --panel: #ffffff; --text: #1c2733; --muted: #5b6b7c;
  --line: #d8dee6; --accent: #2563eb; --warn: #b45309; --bad: #b91c1c;
  --good: #15803d; --stage: #0f1a12;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #10151b; --panel: #1a2129; --text: #e8edf2; --muted: #9aa8b6;
    --line: #2c3742; --accent: #7aa2ff; --warn: #f59e0b; --bad: #f87171;
    --good: #4ade80;
  }
}
:root[data-theme="dark"] {
  --bg: #10151b; --panel: #1a2129; --text: #e8edf2; --muted: #9aa8b6;
  --line: #2c3742; --accent: #7aa2ff; --warn: #f59e0b; --bad: #f87171;
  --good: #4ade80;
}
:root[data-theme="light"] {
  --bg: #f6f7f9; --panel: #ffffff; --text: #1c2733; --muted: #5b6b7c;
  --line: #d8dee6; --accent: #2563eb; --warn: #b45309; --bad: #b91c1c;
  --good: #15803d;
}
* { box-sizing: border-box; }
body {
  margin: 0; background: var(--bg); color: var(--text);
  font: 14px/1.55 -apple-system, "Segoe UI", "Apple SD Gothic Neo", Roboto, sans-serif;
}
h1 { font-size: 1.1rem; margin: 0; }
h2 { font-size: 1rem; margin: 0 0 .6rem; }
.en { color: var(--muted); font-weight: 400; font-size: .74rem; letter-spacing: .02em; }
.sub { color: var(--muted); }

/* ---- top bar ---- */
.topbar {
  display: flex; flex-wrap: wrap; align-items: baseline; gap: .4rem 1rem;
  padding: .7rem 1.1rem; border-bottom: 1px solid var(--line);
  background: var(--panel);
}
.topbar .stats { margin-left: auto; display: flex; gap: .45rem; flex-wrap: wrap; }
.pill {
  font-size: .74rem; padding: .12rem .6rem; border-radius: 999px;
  border: 1px solid var(--line); color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.pill.bad { color: var(--bad); border-color: color-mix(in srgb, var(--bad) 40%, transparent); }
.pill.good { color: var(--good); border-color: color-mix(in srgb, var(--good) 40%, transparent); }

/* ---- stage (map + detail) ---- */
.stage {
  display: grid; grid-template-columns: minmax(0, 1fr) 300px;
  gap: .9rem; padding: .9rem 1.1rem; align-items: start;
}
@media (max-width: 900px) { .stage { grid-template-columns: 1fr; } }

.mapcard { background: var(--stage); border-radius: 12px; overflow: hidden; border: 1px solid var(--line); }
.mapwrap {
  position: relative; aspect-ratio: 7 / 5; background: #6ec24a;
  max-height: min(66vh, 620px);
  width: min(100%, calc(min(66vh, 620px) * 1.4));
  margin-inline: auto;
}
.mapwrap img { position: absolute; inset: 0; width: 100%; height: 100%; display: block; image-rendering: auto; }
.mapwrap canvas { position: absolute; inset: 0; width: 100%; height: 100%; cursor: pointer; }

.hud {
  display: flex; align-items: center; gap: .7rem;
  padding: .55rem .8rem; background: color-mix(in srgb, var(--panel) 92%, transparent);
  border-top: 1px solid var(--line); flex-wrap: wrap;
}
.hud button {
  background: var(--accent); border: none; color: #fff; font: inherit;
  border-radius: 8px; padding: .35rem .9rem; cursor: pointer; font-weight: 600;
}
.hud button.secondary { background: transparent; color: var(--text); border: 1px solid var(--line); }
.timeline { flex: 1; min-width: 160px; position: relative; padding-top: 8px; }
.timeline input[type=range] { width: 100%; margin: 0; accent-color: var(--accent); }
.markers { position: absolute; left: 0; right: 0; top: 0; height: 6px; }
.markers i { position: absolute; width: 5px; height: 5px; border-radius: 50%; background: var(--warn); transform: translateX(-50%); }
.markers i.bad { background: var(--bad); }
.stepnum { font-variant-numeric: tabular-nums; color: var(--muted); font-size: .8rem; white-space: nowrap; }

.caption {
  padding: .5rem .9rem .7rem; font-size: .84rem; color: var(--muted);
  background: color-mix(in srgb, var(--panel) 92%, transparent);
  display: grid; gap: .15rem;
}
.caption b { color: var(--text); font-weight: 600; }

.chips { display: flex; flex-wrap: wrap; gap: .45rem; padding: .6rem .9rem; background: color-mix(in srgb, var(--panel) 92%, transparent); border-top: 1px solid var(--line); }
.chip {
  display: inline-flex; align-items: center; gap: .4rem; cursor: pointer;
  border: 1px solid var(--line); border-radius: 999px; padding: .25rem .7rem;
  font-size: .82rem; background: var(--panel); color: var(--text);
}
.chip .dot { width: 10px; height: 10px; border-radius: 50%; }
.chip.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent); }

/* ---- agent detail panel ---- */
.detail { background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 1rem; position: sticky; top: .9rem; }
.detail h2 { display: flex; align-items: center; gap: .5rem; }
.detail .dot { width: 12px; height: 12px; border-radius: 50%; display: inline-block; }
.kv { display: grid; grid-template-columns: auto 1fr; gap: .25rem .7rem; font-size: .84rem; margin: .6rem 0; }
.kv dt { color: var(--muted); white-space: nowrap; }
.kv dd { margin: 0; }
.now { background: var(--bg); border: 1px solid var(--line); border-radius: 8px; padding: .55rem .7rem; font-size: .85rem; margin-bottom: .6rem; }
.now .loc { color: var(--muted); font-size: .76rem; margin-top: .2rem; }

/* ---- tabs ---- */
.tabs { display: flex; gap: .3rem; padding: 0 1.1rem; border-bottom: 1px solid var(--line); overflow-x: auto; }
.tabs button {
  background: none; border: none; border-bottom: 2px solid transparent;
  font: inherit; color: var(--muted); padding: .6rem .8rem; cursor: pointer; white-space: nowrap;
}
.tabs button.on { color: var(--text); border-bottom-color: var(--accent); font-weight: 600; }
.tabpane { display: none; padding: 1rem 1.1rem 2rem; }
.tabpane.on { display: block; }
.grid { display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); }
.panel { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 1rem; overflow-x: auto; }
.panel.wide { grid-column: 1 / -1; }

table { border-collapse: collapse; width: 100%; font-size: .82rem; }
th, td { border-bottom: 1px solid var(--line); padding: .35rem .5rem; text-align: left; vertical-align: top; }
th { color: var(--muted); font-weight: 600; }
tr.bottleneck td { background: color-mix(in srgb, var(--bad) 12%, transparent); }
.badge { display: inline-block; border-radius: 999px; padding: 0 .55rem; font-size: .75rem; }
.badge.pass { background: color-mix(in srgb, var(--good) 18%, transparent); color: var(--good); }
.badge.fail { background: color-mix(in srgb, var(--bad) 18%, transparent); color: var(--bad); }
.badge.manual, .badge.not_applicable { background: color-mix(in srgb, var(--warn) 16%, transparent); color: var(--warn); }
.legend { display: flex; gap: .9rem; flex-wrap: wrap; font-size: .78rem; color: var(--muted); margin-top: .4rem; }
.legend span::before { content: "— "; font-weight: 700; }
.insight { border: 1px solid var(--line); border-radius: 8px; padding: .6rem .8rem; margin-bottom: .6rem; }
.insight .growth { color: var(--muted); font-size: .8rem; }
.trait-row { display: flex; align-items: center; gap: .5rem; font-size: .78rem; margin: .15rem 0; }
.trait-row .name { width: 130px; color: var(--muted); }
.trait-bar { flex: 1; height: 7px; background: var(--line); border-radius: 4px; overflow: hidden; }
.trait-bar i { display: block; height: 100%; background: var(--accent); }
pre { white-space: pre-wrap; font-size: .8rem; }
svg text { fill: var(--muted); font-size: 10px; }
.notice { padding: 2rem; text-align: center; color: var(--muted); }
</style>
</head>
<body>

<header class="topbar">
  <h1 id="title">IDD 에이전트 시뮬레이션</h1>
  <span class="en" id="subtitle">IDD Agent Simulation Dashboard</span>
  <div class="stats" id="topStats"></div>
</header>

<section class="stage" id="stage">
  <div class="mapcard">
    <div class="mapwrap" id="mapwrap">
      <img id="mapimg" alt="the Ville map">
      <canvas id="stageCanvas"></canvas>
    </div>
    <div class="hud">
      <button id="playBtn">⏸ 일시정지</button>
      <button id="speedBtn" class="secondary">1×</button>
      <div class="timeline">
        <div class="markers" id="markers"></div>
        <input type="range" id="scrubber" min="0" max="0" value="0" step="1"
               aria-label="타임라인">
      </div>
      <span class="stepnum" id="stepnum"></span>
    </div>
    <div class="caption" id="liveCaption"></div>
    <div class="chips" id="agentChips"></div>
  </div>
  <aside class="detail" id="agentDetail"></aside>
</section>

<nav class="tabs" id="tabs">
  <button data-tab="overview" class="on">개요 <span class="en">Overview · Cohort Comparison</span></button>
  <button data-tab="bottleneck">병목 진단 <span class="en">Bottleneck Pipeline</span></button>
  <button data-tab="agentlog">스텝 로그 <span class="en">Interpreter</span></button>
  <button data-tab="character">성격·인사이트 <span class="en">Character</span></button>
  <button data-tab="reports">검증·리포트 <span class="en">Validation</span></button>
</nav>

<div class="tabpane on" id="pane-overview">
  <div class="grid">
    <div class="panel wide">
      <h2>코호트 비교 <span class="en">Cohort Comparison — 인물별 성과와 병목을 한 줄씩</span></h2>
      <table id="cohortTable"></table>
    </div>
    <div class="panel">
      <h2>기능 프로파일 추적 <span class="en">선택한 인물의 스텝별 변화</span></h2>
      <div id="profileChart"></div>
      <div class="legend">
        <span style="color:#2563eb">적응 추정치</span>
        <span style="color:#dc2626">지원 필요 추정치</span>
        <span style="color:#d97706">감정 (0–7 스케일)</span>
        <span style="color:#059669">상태 압력</span>
      </div>
    </div>
    <div class="panel">
      <h2>병목 차원 <span class="en">선택한 인물이 어떤 기능에서 막히는지</span></h2>
      <div id="dimensionSummary"></div>
    </div>
  </div>
</div>

<div class="tabpane" id="pane-bottleneck">
  <div class="grid">
    <div class="panel wide">
      <h2>단계별 병목 파이프라인 <span class="en">Bottleneck Pipeline — 각 스텝이 루프의 어느 단계에서 막혔는지</span></h2>
      <table id="bottleneckTable"></table>
    </div>
  </div>
</div>

<div class="tabpane" id="pane-agentlog">
  <div class="grid">
    <div class="panel wide">
      <h2>스텝별 설명 <span class="en">Interpreter — 선택한 인물의 전체 행동 기록</span></h2>
      <label style="font-size:.83rem"><input type="checkbox" id="onlyBottlenecks"> 병목·지원·재계획만 보기</label>
      <table id="eventTable"></table>
    </div>
  </div>
</div>

<div class="tabpane" id="pane-character">
  <div class="grid">
    <div class="panel wide">
      <h2>성격 시스템 인사이트 <span class="en">선택한 인물의 시나리오별 요약과 성격 변화</span></h2>
      <div id="insights"></div>
    </div>
  </div>
</div>

<div class="tabpane" id="pane-reports">
  <div class="grid">
    <div class="panel">
      <h2>자동 검증 <span class="en">Validation Report</span></h2>
      <table id="validationTable"></table>
    </div>
    <div class="panel">
      <h2>보호자 리포트 <span class="en">Caregiver Report</span></h2>
      <pre id="caregiverReport"></pre>
    </div>
  </div>
</div>

<script>
const DATA = __DASHBOARD_DATA__;
const agents = [...new Set(DATA.events.map(e => e.agent_id))];
const colors = ['#2563eb', '#dc2626', '#d97706', '#059669', '#7c3aed', '#0891b2'];
const agentColor = Object.fromEntries(agents.map((a, i) => [a, colors[i % colors.length]]));
let selected = agents[0] || null;

document.getElementById('title').textContent =
  (DATA.summary ? DATA.summary.experiment : 'IDD agent simulation') + ' — 하루 리플레이';

function topStats() {
  const s = DATA.summary || {};
  const items = [
    [`이벤트 ${s.events ?? '-'}`, ''],
    [`과제 완수 ${s.task_goal_completion != null ? (s.task_goal_completion * 100).toFixed(0) + '%' : '-'}`,
      (s.task_goal_completion ?? 0) >= 0.99 ? 'good' : ''],
    [`병목 ${s.bottleneck_count ?? 0}`, (s.bottleneck_count ?? 0) > 0 ? 'bad' : 'good'],
    [`케어갭 ${s.care_gap_count ?? 0}`, (s.care_gap_count ?? 0) > 0 ? 'bad' : 'good'],
  ];
  document.getElementById('topStats').innerHTML =
    items.map(([t, c]) => `<span class="pill ${c}">${t}</span>`).join('');
}

/* ================= replay stage ================= */
const replay = DATA.replay_movement;
const layout = DATA.map_layout;
const mazeW = layout?.maze?.width || 140, mazeH = layout?.maze?.height || 100;
const frameKeys = replay ? Object.keys(replay).sort((a, b) => Number(a) - Number(b)) : [];
const maxFrame = Math.max(0, frameKeys.length - 1);
let frame = 0;        // float for tweening
let playing = true;
const speeds = [1, 2, 4];
let speedIdx = 0;
const BASE_SPS = 1.6; // frames per second at 1x

const mapimg = document.getElementById('mapimg');
if (DATA.map_image) mapimg.src = DATA.map_image; else mapimg.remove();

const canvas = document.getElementById('stageCanvas');
const ctx = canvas.getContext('2d');
function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
new ResizeObserver(resizeCanvas).observe(canvas);

function personsAt(k) { return replay[frameKeys[Math.max(0, Math.min(maxFrame, k))]] || {}; }

/* short action text: drop the prompt-condition tail (full text lives in the
   스텝 로그 tab) */
function shortAction(description) {
  return (description || '').split(' @ ')[0].split(' with prompts:')[0];
}

function tweenedPositions() {
  const k = Math.floor(frame), t = frame - k;
  const cur = personsAt(k), nxt = personsAt(k + 1);
  const out = {};
  for (const [name, info] of Object.entries(cur)) {
    const next = nxt[name];
    const x = next ? info.movement[0] + (next.movement[0] - info.movement[0]) * t : info.movement[0];
    const y = next ? info.movement[1] + (next.movement[1] - info.movement[1]) * t : info.movement[1];
    out[name] = { x, y, info };
  }
  return out;
}

function drawStage() {
  const rect = canvas.getBoundingClientRect();
  const sx = v => (v + 0.5) / mazeW * rect.width;
  const sy = v => (v + 0.5) / mazeH * rect.height;
  ctx.clearRect(0, 0, rect.width, rect.height);
  if (!replay) return;
  const pos = tweenedPositions();
  // spread personas sharing (almost) the same tile so dots never stack
  const entries = Object.entries(pos);
  const cellCount = {};
  entries.forEach(([, p]) => {
    const key = `${Math.round(p.x / 3)},${Math.round(p.y / 3)}`;
    cellCount[key] = (cellCount[key] || 0) + 1;
  });
  const cellSeen = {};
  for (const [name, p] of entries) {
    const isPartner = name.endsWith('(support)');
    const baseAgent = isPartner ? null : name;
    const color = isPartner ? '#e8b93c' : (agentColor[name] || '#888');
    const key = `${Math.round(p.x / 3)},${Math.round(p.y / 3)}`;
    const siblings = cellCount[key];
    const slot = (cellSeen[key] = (cellSeen[key] || 0) + 1) - 1;
    let x = sx(p.x), y = sy(p.y);
    if (siblings > 1) {
      const angle = slot / siblings * Math.PI * 2 - Math.PI / 2;
      x += Math.cos(angle) * 13;
      y += Math.sin(angle) * 13;
    }
    const r = isPartner ? 7 : 9;
    if (baseAgent === selected) {
      ctx.beginPath(); ctx.arc(x, y, r + 5, 0, Math.PI * 2);
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke();
    }
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = color; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff'; ctx.stroke();
    const emoji = p.info.pronunciatio || '';
    if (emoji) { ctx.font = '13px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(emoji, x, y - r - 5); }
    const label = isPartner ? name.replace(' (support)', ' 🫱') : name;
    ctx.font = '600 11px sans-serif';
    const w = ctx.measureText(label).width + 10;
    ctx.fillStyle = 'rgba(12,16,20,0.72)';
    ctx.beginPath(); ctx.roundRect(x - w / 2, y + r + 4, w, 16, 8); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(label, x, y + r + 16);
  }
}

function updateHudAndPanels() {
  const k = Math.floor(frame);
  document.getElementById('scrubber').value = k;
  document.getElementById('stepnum').textContent = `${k} / ${maxFrame} 스텝`;
  const cur = personsAt(k);
  const lines = agents
    .filter(a => cur[a])
    .map(a => {
      const d = shortAction(cur[a].description);
      return `<div><b style="color:${agentColor[a]}">●</b> <b>${a}</b> — ${d}</div>`;
    });
  document.getElementById('liveCaption').innerHTML = lines.join('') || '<div class="sub">리플레이 데이터가 없습니다.</div>';
  renderDetail();
}

/* setInterval (not requestAnimationFrame): rAF freezes entirely in
   occluded/background tabs, which made playback appear dead. A wall-clock
   interval keeps the day advancing anywhere. */
let lastTick = performance.now();
let lastWholeFrame = -1;
function tick() {
  const now = performance.now();
  if (playing && maxFrame > 0) {
    frame += (now - lastTick) / 1000 * BASE_SPS * speeds[speedIdx];
    if (frame > maxFrame) frame = 0;   // loop the day
  }
  lastTick = now;
  drawStage();
  const whole = Math.floor(frame);
  if (whole !== lastWholeFrame) { lastWholeFrame = whole; updateHudAndPanels(); }
}

document.getElementById('playBtn').onclick = () => {
  playing = !playing;
  document.getElementById('playBtn').textContent = playing ? '⏸ 일시정지' : '▶ 재생';
};
document.getElementById('speedBtn').onclick = () => {
  speedIdx = (speedIdx + 1) % speeds.length;
  document.getElementById('speedBtn').textContent = speeds[speedIdx] + '×';
};
const scrubber = document.getElementById('scrubber');
scrubber.max = maxFrame;
scrubber.addEventListener('input', () => { frame = Number(scrubber.value); playing = false;
  document.getElementById('playBtn').textContent = '▶ 재생'; updateHudAndPanels(); });

function buildMarkers() {
  const el = document.getElementById('markers');
  if (!replay || maxFrame === 0) return;
  const html = [];
  frameKeys.forEach((key, i) => {
    const persons = replay[key];
    const hasSupport = Object.keys(persons).some(n => n.endsWith('(support)'));
    const hasTrouble = Object.values(persons).some(p => /bottleneck|pausing|did not close/.test(p.description || ''));
    if (hasTrouble) html.push(`<i class="bad" style="left:${i / maxFrame * 100}%"></i>`);
    else if (hasSupport) html.push(`<i style="left:${i / maxFrame * 100}%"></i>`);
  });
  el.innerHTML = html.join('');
}

canvas.addEventListener('click', event => {
  const rect = canvas.getBoundingClientRect();
  const pos = tweenedPositions();
  let best = null, bestDist = 24;
  for (const [name, p] of Object.entries(pos)) {
    if (name.endsWith('(support)')) continue;
    const x = (p.x + 0.5) / mazeW * rect.width, y = (p.y + 0.5) / mazeH * rect.height;
    const d = Math.hypot(event.offsetX - x, event.offsetY - y);
    if (d < bestDist) { best = name; bestDist = d; }
  }
  if (best) selectAgent(best);
});

/* ================= agent selection ================= */
function selectAgent(agent) {
  selected = agent;
  document.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.agent === agent));
  renderDetail(); renderAgentPanels();
}

function buildChips() {
  document.getElementById('agentChips').innerHTML = agents.map(a =>
    `<button class="chip ${a === selected ? 'on' : ''}" data-agent="${a}">
       <span class="dot" style="background:${agentColor[a]}"></span>${a}</button>`).join('');
  document.querySelectorAll('.chip').forEach(c => c.onclick = () => selectAgent(c.dataset.agent));
}

function agentStats(agent) {
  const rows = DATA.events.filter(e => e.agent_id === agent);
  const dims = {};
  rows.forEach(r => (r.exceeded_dimensions || []).forEach(d => { dims[d] = (dims[d] || 0) + 1; }));
  const partners = {};
  rows.forEach(r => { if (r.support_partner) partners[r.support_partner] = (partners[r.support_partner] || 0) + 1; });
  return {
    rows,
    completed: rows.filter(r => r.completed).length,
    supported: rows.filter(r => r.support_partner).length,
    topDims: Object.entries(dims).sort((a, b) => b[1] - a[1]).slice(0, 2),
    mainPartner: Object.entries(partners).sort((a, b) => b[1] - a[1])[0] || null,
  };
}

function renderDetail() {
  const el = document.getElementById('agentDetail');
  if (!selected) { el.innerHTML = '<div class="sub">인물을 선택하세요.</div>'; return; }
  const k = Math.floor(frame);
  const cur = personsAt(k)[selected];
  const action = cur ? shortAction(cur.description) : '-';
  const place = cur ? ((cur.description || '').split(' @ ')[1] || '').split(':').slice(1).join(' · ') : '';
  const s = agentStats(selected);
  const insightsForAgent = DATA.insights.filter(i => i.agent_id === selected);
  const mood = insightsForAgent.length ? insightsForAgent[insightsForAgent.length - 1].mood : '';
  el.innerHTML = `
    <h2><span class="dot" style="background:${agentColor[selected]}"></span>${selected}</h2>
    <div class="now"><b>지금:</b> ${action}${cur?.pronunciatio ? ' ' + cur.pronunciatio : ''}
      <div class="loc">${place || ''}</div></div>
    <dl class="kv">
      <dt>완수</dt><dd>${s.rows.length ? Math.round(s.completed / s.rows.length * 100) : 0}% (${s.completed}/${s.rows.length} 스텝)</dd>
      <dt>지원 받음</dt><dd>${s.rows.length ? Math.round(s.supported / s.rows.length * 100) : 0}%</dd>
      <dt>주요 병목</dt><dd>${s.topDims.map(([d, c]) => `${d} (${c})`).join('<br>') || '없음'}</dd>
      <dt>주 지원자</dt><dd>${s.mainPartner ? `${s.mainPartner[0]} (${s.mainPartner[1]}회)` : '없음'}</dd>
      ${mood ? `<dt>기분</dt><dd>${mood}</dd>` : ''}
    </dl>
    <div class="sub" style="font-size:.78rem">지도에서 인물을 클릭해도 선택됩니다. 아래 탭은 이 인물 기준으로 갱신됩니다.</div>`;
}

/* ================= analytics panels (tabs) ================= */
function lineChart(rows) {
  const W = 460, H = 220, P = 28;
  const series = [
    ['#2563eb', rows.map(r => r.adaptive_estimate)],
    ['#dc2626', rows.map(r => r.support_need_estimate)],
    ['#d97706', rows.map(r => r.emotion_level / 7)],
    ['#059669', rows.map(r => r.state_pressure)],
  ];
  const x = i => rows.length < 2 ? W / 2 : P + i * (W - 2 * P) / (rows.length - 1);
  const y = v => H - P - v * (H - 2 * P);
  let svg = `<svg viewBox="0 0 ${W} ${H}" width="100%">`;
  for (const g of [0, 0.5, 1]) {
    svg += `<line x1="${P}" x2="${W - P}" y1="${y(g)}" y2="${y(g)}" stroke="var(--line)"/>`;
    svg += `<text x="2" y="${y(g) + 3}">${g}</text>`;
  }
  for (const [color, vals] of series) {
    const pts = vals.map((v, i) => `${x(i)},${y(Math.max(0, Math.min(1, v)))}`).join(' ');
    svg += `<polyline fill="none" stroke="${color}" stroke-width="2" points="${pts}"/>`;
  }
  rows.forEach((r, i) => {
    if (!r.completed) svg += `<circle cx="${x(i)}" cy="${H - 10}" r="3" fill="#b91c1c"/>`;
  });
  return svg + '</svg>';
}

function trait(name, v) {
  return `<div class="trait-row"><span class="name">${name}</span>
    <span class="trait-bar"><i style="width:${(v * 100).toFixed(0)}%"></i></span>
    <span>${v.toFixed(2)}</span></div>`;
}

function renderAgentPanels() {
  const rows = DATA.events.filter(e => e.agent_id === selected);
  document.getElementById('profileChart').innerHTML = lineChart(rows);

  const dimCounts = {};
  rows.forEach(r => (r.exceeded_dimensions || []).forEach(d => { dimCounts[d] = (dimCounts[d] || 0) + 1; }));
  const dimEntries = Object.entries(dimCounts).sort((a, b) => b[1] - a[1]);
  const maxCount = dimEntries.length ? dimEntries[0][1] : 1;
  document.getElementById('dimensionSummary').innerHTML = dimEntries.length
    ? dimEntries.map(([d, c]) => `<div class="trait-row"><span class="name">${d}</span>
        <span class="trait-bar"><i style="width:${(c / maxCount * 100).toFixed(0)}%"></i></span>
        <span>${c}스텝</span></div>`).join('')
      + '<div class="sub" style="margin-top:.4rem;font-size:.78rem">요구가 프로파일 능력을 초과한 스텝 수 (차원별)</div>'
    : '<div class="sub">차원 병목 없음 — 전 스텝을 능력 범위 안에서 수행했습니다.</div>';

  const notes = DATA.insights.filter(i => i.agent_id === selected);
  document.getElementById('insights').innerHTML = notes.length ? notes.map(n => `
    <div class="insight">
      <strong>${n.scenario_id}</strong> · 기분: ${n.mood || '-'} ·
      완수 ${(n.completion_rate * 100).toFixed(0)}% ·
      지원 ${(n.support_reliance * 100).toFixed(0)}%
      <div>${n.insight_summary}</div>
      ${Object.entries(n.traits || {}).map(([k, v]) => trait(k, v)).join('')}
      ${Object.entries(n.conflicts || {}).map(([k, v]) => trait('갈등: ' + k, v)).join('')}
      ${(n.growth_notes || []).map(g => `<div class="growth">↳ ${g}</div>`).join('')}
    </div>`).join('') : '<div class="sub">인사이트 기록이 없습니다.</div>';

  renderEventTable();
}

function renderEventTable() {
  const rows = DATA.events.filter(e => e.agent_id === selected);
  const only = document.getElementById('onlyBottlenecks').checked;
  const shown = rows.filter(r => !only || !r.completed || r.support_partner || r.replan_triggered || r.unmet_need > 0);
  document.getElementById('eventTable').innerHTML =
    '<tr><th>시나리오 / 스텝</th><th>행동</th><th>병목 차원</th><th>지원</th><th>설명</th><th>성찰</th><th>학습</th></tr>' +
    shown.map(r => `<tr class="${(!r.completed || r.unmet_need > 0) ? 'bottleneck' : ''}">
      <td>${r.scenario_id}<br><span class="sub">${r.step_id}</span></td>
      <td>${r.action_type}${r.replan_triggered ? ' · 재계획' : ''}</td>
      <td>${(r.exceeded_dimensions || []).map(d =>
            d === r.binding_dimension ? `<strong>${d}</strong>` : d).join('<br>') || '-'}</td>
      <td>${r.support_partner || '-'}${r.support_partner ? `<br><span class="sub">${r.support_level || ''}</span>` : ''}</td>
      <td>${r.explanation || ''}</td>
      <td>${r.reflection_summary || ''}</td>
      <td>${r.learning_signal || ''}<br><span class="sub">${r.profile_update_reason || ''}</span></td>
    </tr>`).join('');
}
document.getElementById('onlyBottlenecks').onchange = renderEventTable;

function cohort() {
  const el = document.getElementById('cohortTable');
  const bar = (v, color) =>
    `<span class="trait-bar" style="display:inline-block;width:90px;vertical-align:middle;margin-right:.4rem">
       <i style="width:${(v * 100).toFixed(0)}%;background:${color}"></i></span>${(v * 100).toFixed(0)}%`;
  el.innerHTML =
    '<tr><th>인물</th><th>완수</th><th>지원 받음</th><th>주요 병목 차원</th><th>주 지원자 · 수준</th><th>최종 적응 추정</th></tr>' +
    agents.map(agent => {
      const rows = DATA.events.filter(e => e.agent_id === agent);
      const completed = rows.filter(r => r.completed).length / rows.length;
      const supported = rows.filter(r => r.support_partner).length / rows.length;
      const dims = {};
      rows.forEach(r => (r.exceeded_dimensions || []).forEach(d => { dims[d] = (dims[d] || 0) + 1; }));
      const topDims = Object.entries(dims).sort((a, b) => b[1] - a[1]).slice(0, 2)
        .map(([d, c]) => `${d} (${c})`).join(', ') || '-';
      const partners = {}; const levels = {};
      rows.forEach(r => {
        if (!r.support_partner) return;
        partners[r.support_partner] = (partners[r.support_partner] || 0) + 1;
        levels[r.support_level] = (levels[r.support_level] || 0) + 1;
      });
      const mainPartner = Object.entries(partners).sort((a, b) => b[1] - a[1])[0];
      const mainLevel = Object.entries(levels).sort((a, b) => b[1] - a[1])[0];
      const lastAdaptive = rows.length ? rows[rows.length - 1].adaptive_estimate : 0;
      return `<tr style="cursor:pointer" onclick="selectAgent('${agent}')">
        <td><b style="color:${agentColor[agent]}">●</b> <strong>${agent}</strong></td>
        <td>${bar(completed, 'var(--good)')}</td>
        <td>${bar(supported, 'var(--warn)')}</td>
        <td>${topDims}</td>
        <td>${mainPartner ? `${mainPartner[0]} (${mainPartner[1]})` : '-'}${mainLevel ? `<br><span class="sub">${mainLevel[0]}</span>` : ''}</td>
        <td>${lastAdaptive.toFixed(2)}</td>
      </tr>`;
    }).join('');
}

function bottleneckPipeline() {
  const b = DATA.bottleneck;
  const el = document.getElementById('bottleneckTable');
  if (!b || !b.steps) { el.innerHTML = '<tr><td class="sub">병목 리포트가 없습니다.</td></tr>'; return; }
  const stages = b.stages || [];
  const stageKo = { perception: '지각', capacity: '능력', regulation: '조절', environment: '환경', support: '지원' };
  const stageCell = (step, stage) => {
    const n = step.stage_counts[stage] || 0;
    if (!n) return '<td class="sub" style="text-align:center">·</td>';
    const heat = Math.min(1, n / step.total_agents);
    return `<td style="background:color-mix(in srgb, var(--bad) ${Math.round(heat * 30)}%, transparent);text-align:center">${n}</td>`;
  };
  el.innerHTML =
    `<tr><th>시나리오 / 스텝</th>${stages.map(s => `<th>${stageKo[s] || s}</th>`).join('')}<th>해결</th><th>개입 지점</th></tr>` +
    b.steps.map(step => {
      const res = step.resolutions || {};
      const unresolved = res.unresolved || 0;
      const resText = [
        res.independent ? `독립 ${res.independent}` : '',
        res.resolved_by_support ? `지원으로 ${res.resolved_by_support}` : '',
        unresolved ? `<strong style="color:var(--bad)">미해결 ${unresolved}</strong>` : '',
      ].filter(Boolean).join('<br>');
      return `<tr class="${unresolved ? 'bottleneck' : ''}">
        <td>${step.scenario_id}<br><span class="sub">${step.step_id}</span></td>
        ${stages.map(s => stageCell(step, s)).join('')}
        <td>${resText || '-'}</td>
        <td>${(step.interventions || []).join('<br>') || '-'}
          ${step.dominant_dimension ? `<br><span class="sub">binding: ${step.dominant_dimension}</span>` : ''}</td>
      </tr>`;
    }).join('');
}

function validation() {
  const v = DATA.validation;
  const el = document.getElementById('validationTable');
  if (!v || !v.criteria) { el.innerHTML = '<tr><td class="sub">검증 리포트가 없습니다.</td></tr>'; return; }
  el.innerHTML = '<tr><th>기준</th><th>상태</th></tr>' + v.criteria.map(c =>
    `<tr><td>${c.title || c.criterion_id}</td><td><span class="badge ${c.status}">${c.status}</span></td></tr>`).join('');
}

/* ================= tabs ================= */
document.querySelectorAll('#tabs button').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('on', b === btn));
    document.querySelectorAll('.tabpane').forEach(p =>
      p.classList.toggle('on', p.id === 'pane-' + btn.dataset.tab));
  };
});

/* ================= boot ================= */
document.getElementById('caregiverReport').textContent = DATA.caregiver_report || '보호자 리포트가 없습니다.';
topStats(); buildChips(); buildMarkers(); cohort(); bottleneckPipeline(); validation();
renderAgentPanels(); updateHudAndPanels();
if (!replay) {
  document.querySelector('.mapcard').innerHTML =
    '<div class="notice">리플레이 데이터가 없는 실험입니다. 아래 탭에서 분석 결과를 확인하세요.</div>';
} else {
  setInterval(tick, 60);
}
</script>
</body>
</html>
"""
