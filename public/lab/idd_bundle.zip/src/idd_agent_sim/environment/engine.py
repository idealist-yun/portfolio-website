from typing import Any

from idd_agent_sim.environment.state import EnvironmentFeedback, EnvironmentState
from idd_agent_sim.testbed import ScenarioStep


class EnvironmentEngine:
    def check_prerequisites(
        self,
        step: ScenarioStep,
        state: EnvironmentState,
        support_partner: str | None = None,
    ) -> EnvironmentFeedback:
        required_people = set(step.required_people)
        if support_partner is not None:
            required_people.add(support_partner)

        missing_objects = tuple(
            obj for obj in step.required_objects if obj not in state.available_objects
        )
        missing_people = tuple(
            person for person in required_people if person not in state.available_people
        )
        occupied_objects = tuple(
            obj for obj in step.required_objects if obj in state.occupied_objects
        )

        success = not missing_objects and not missing_people and not occupied_objects
        return EnvironmentFeedback(
            success=success,
            missing_objects=missing_objects,
            missing_people=missing_people,
            occupied_objects=occupied_objects,
            explanation=(
                "Environment prerequisites are available."
                if success
                else "Environment prerequisites blocked the action."
            ),
        )

    def apply_action(
        self,
        step: ScenarioStep,
        decision: Any,
        state: EnvironmentState,
        support_partner: str | None = None,
    ) -> tuple[EnvironmentFeedback, EnvironmentState]:
        prerequisite_feedback = self.check_prerequisites(step, state, support_partner)
        if not prerequisite_feedback.success:
            return prerequisite_feedback, state
        if not decision.completed:
            return (
                EnvironmentFeedback(
                    success=False,
                    completed_step=None,
                    explanation="Agent action did not complete the step.",
                ),
                state,
            )

        next_state = state.complete_step(step.step_id)
        return (
            EnvironmentFeedback(
                success=True,
                completed_step=step.step_id,
                explanation="Environment accepted the completed action.",
            ),
            next_state,
        )
