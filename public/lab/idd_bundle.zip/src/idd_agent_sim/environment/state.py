from dataclasses import dataclass, field


@dataclass(frozen=True)
class EnvironmentState:
    available_objects: frozenset[str] = field(default_factory=frozenset)
    occupied_objects: frozenset[str] = field(default_factory=frozenset)
    available_people: frozenset[str] = field(default_factory=frozenset)
    locations: dict[str, str] = field(default_factory=dict)
    completed_steps: frozenset[str] = field(default_factory=frozenset)

    def affordances(self) -> frozenset[str]:
        values = set(self.available_objects)
        values.update(f"{person}_available" for person in self.available_people)
        if self.available_people:
            values.add("support_available")
        return frozenset(values)

    def complete_step(self, step_id: str) -> "EnvironmentState":
        return EnvironmentState(
            available_objects=self.available_objects,
            occupied_objects=self.occupied_objects,
            available_people=self.available_people,
            locations=dict(self.locations),
            completed_steps=frozenset(set(self.completed_steps) | {step_id}),
        )


@dataclass(frozen=True)
class EnvironmentFeedback:
    success: bool
    missing_objects: tuple[str, ...] = ()
    missing_people: tuple[str, ...] = ()
    occupied_objects: tuple[str, ...] = ()
    completed_step: str | None = None
    explanation: str = ""

    @property
    def blocked(self) -> bool:
        return not self.success
