"""Architecture validity harness.

Empirical checks that the constraint architecture behaves the way its
clinical-grounding claims require. This is the project's answer to the
parameter-identifiability (equifinality) critique: instead of asserting that
profile parameters represent clinical characteristics, the harness
demonstrates three necessary properties:

1. Monotonicity — lowering adaptive-behavior scores must not decrease
   support/bottleneck behavior in the same environment.
2. Distinguishability — profiles weak in different domains must produce
   different behavior signatures (different binding dimensions, support use).
3. Stability — long repeated runs must keep internal estimates bounded with
   no runaway feedback drift.

Passing these checks does not prove clinical fidelity; it establishes that
the architecture is a valid instrument to *test* fidelity with.
"""

import json
from dataclasses import dataclass, field
from pathlib import Path

from idd_agent_sim.simulation import Simulation


@dataclass(frozen=True)
class ValidityCheck:
    check_id: str
    title: str
    status: str  # "pass" | "fail"
    evidence: tuple[str, ...] = ()


@dataclass(frozen=True)
class ArchitectureValidityReport:
    checks: list[ValidityCheck] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(check.status == "pass" for check in self.checks)

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "checks": [
                {
                    "check_id": check.check_id,
                    "title": check.title,
                    "status": check.status,
                    "evidence": list(check.evidence),
                }
                for check in self.checks
            ],
        }

    def render_markdown(self) -> str:
        lines = [
            "# Architecture Validity Report",
            "",
            "Empirical checks of monotonicity, distinguishability, and",
            "stability. Passing establishes architectural validity, not",
            "clinical fidelity.",
            "",
            f"Overall: {'pass' if self.passed else 'FAIL'}",
            "",
        ]
        for check in self.checks:
            lines.append(f"## {check.title} — {check.status}")
            lines.append("")
            lines.extend(f"- {item}" for item in check.evidence)
            lines.append("")
        return "\n".join(lines)


VALIDITY_SCENARIOS = [
    {
        "id": "validity_self_care",
        "domain": "self_care",
        "description": "Self-care probe scenario",
        "steps": [
            {"id": "v_locate", "demand": {"sustained_attention": 0.45,
                                          "sequencing": 0.30},
             "required_skill": "locate_object"},
            {"id": "v_sequence", "demand": {"sequencing": 0.60, "motor": 0.40},
             "required_skill": "sequence_task"},
        ],
    },
    {
        "id": "validity_community",
        "domain": "community",
        "description": "Community probe scenario",
        "steps": [
            {"id": "v_navigate", "demand": {"sustained_attention": 0.45,
                                            "social": 0.40},
             "required_skill": "navigate_environment"},
            {"id": "v_verify", "demand": {"receptive_language": 0.65,
                                          "sustained_attention": 0.45},
             "required_skill": "verify_information"},
        ],
    },
]


def _profile_config(agent_id: str, vabs: dict[str, float],
                    self_sufficiency: float) -> dict:
    return {
        "id": agent_id,
        "self_sufficiency": self_sufficiency,
        "vabs": vabs,
        "support": {"caregiver": 0.8},
    }


def _run(agents: list[dict], scenarios: list[dict] | None = None) -> list:
    simulation = Simulation.from_config(
        {
            "agents": agents,
            "world": {"support_availability": 1.0},
            "scenarios": scenarios or VALIDITY_SCENARIOS,
        }
    )
    return simulation.run().events


def _needs_help_count(events: list, agent_id: str) -> int:
    return sum(
        1
        for event in events
        if event.agent_id == agent_id
        and (event.support_partner is not None or not event.completed)
    )


def check_monotonicity(levels: tuple[float, ...] = (0.8, 0.6, 0.4, 0.2)) -> ValidityCheck:
    """Lower adaptive scores must not reduce support/bottleneck behavior."""
    agents = [
        _profile_config(
            f"level_{int(level * 100)}",
            {
                "communication": level,
                "daily_living_skills": level,
                "socialization": level,
                "motor_skills": level,
                "maladaptive_behavior": 0.3,
            },
            self_sufficiency=level,
        )
        for level in levels
    ]
    events = _run(agents)
    counts = [
        _needs_help_count(events, f"level_{int(level * 100)}")
        for level in levels
    ]
    monotonic = all(counts[i] <= counts[i + 1] for i in range(len(counts) - 1))
    return ValidityCheck(
        check_id="monotonicity.support_vs_capability",
        title="Support/bottleneck events grow monotonically as scores drop",
        status="pass" if monotonic else "fail",
        evidence=tuple(
            f"score={level:.1f} -> support/bottleneck events={count}"
            for level, count in zip(levels, counts)
        ),
    )


def check_distinguishability() -> ValidityCheck:
    """Domain-contrasting profiles must produce distinct behavior signatures."""
    contrast = {
        "communication_weak": {"communication": 0.25, "daily_living_skills": 0.7,
                               "socialization": 0.7, "motor_skills": 0.7,
                               "maladaptive_behavior": 0.3},
        "daily_living_weak": {"communication": 0.7, "daily_living_skills": 0.25,
                              "socialization": 0.7, "motor_skills": 0.7,
                              "maladaptive_behavior": 0.3},
    }
    agents = [
        _profile_config(agent_id, vabs, self_sufficiency=0.55)
        for agent_id, vabs in contrast.items()
    ]
    events = _run(agents)

    def signature(agent_id: str) -> tuple:
        agent_events = [e for e in events if e.agent_id == agent_id]
        return (
            tuple(sorted(
                dim for e in agent_events for dim in e.exceeded_dimensions
            )),
            sum(1 for e in agent_events if e.support_partner),
            sum(e.plan_substeps for e in agent_events),
        )

    signatures = {agent_id: signature(agent_id) for agent_id in contrast}
    distinct = len(set(signatures.values())) == len(signatures)
    return ValidityCheck(
        check_id="distinguishability.profile_signatures",
        title="Domain-contrasting profiles produce distinct behavior signatures",
        status="pass" if distinct else "fail",
        evidence=tuple(
            f"{agent_id}: exceeded={sig[0]}, supported_steps={sig[1]}, "
            f"total_substeps={sig[2]}"
            for agent_id, sig in signatures.items()
        ),
    )


def check_stability(repeats: int = 30) -> ValidityCheck:
    """Long repeated runs keep estimates bounded without runaway drift."""
    scenario = VALIDITY_SCENARIOS[0]
    scenarios = [
        {**scenario, "id": f"{scenario['id']}_{index}"}
        for index in range(repeats)
    ]
    agents = [
        _profile_config(
            "stability_agent",
            {"communication": 0.45, "daily_living_skills": 0.4,
             "socialization": 0.5, "motor_skills": 0.6,
             "maladaptive_behavior": 0.35},
            self_sufficiency=0.45,
        )
    ]
    events = _run(agents, scenarios)
    in_bounds = all(
        0.0 <= event.adaptive_estimate <= 1.0
        and 0.0 <= event.support_need_estimate <= 1.0
        and 0.0 <= event.emotion_level <= 7.0
        for event in events
    )
    max_step_delta = max(
        (abs(event.adaptive_delta) + abs(event.support_need_delta))
        for event in events
    )
    bounded_updates = max_step_delta <= 0.5
    # runaway drift would push the support-need estimate to saturation while
    # unmet need keeps growing; require the last quarter to be settled
    tail = events[-max(1, len(events) // 4):]
    tail_delta = max(
        abs(event.adaptive_delta) + abs(event.support_need_delta)
        for event in tail
    )
    settled = tail_delta <= 0.25
    passed = in_bounds and bounded_updates and settled
    return ValidityCheck(
        check_id="stability.bounded_feedback",
        title="Repeated runs keep estimates bounded without runaway drift",
        status="pass" if passed else "fail",
        evidence=(
            f"events={len(events)}",
            f"all estimates in bounds={in_bounds}",
            f"max per-step update={max_step_delta:.3f} (limit 0.5)",
            f"final-quarter max update={tail_delta:.3f} (limit 0.25)",
        ),
    )


def run_architecture_validity() -> ArchitectureValidityReport:
    return ArchitectureValidityReport(
        checks=[
            check_monotonicity(),
            check_distinguishability(),
            check_stability(),
        ]
    )


def write_architecture_validity_report(
    output_dir: str | Path,
) -> tuple[Path, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    report = run_architecture_validity()
    json_path = output_dir / "architecture_validity_report.json"
    markdown_path = output_dir / "architecture_validity_report.md"
    json_path.write_text(
        json.dumps(report.to_dict(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    markdown_path.write_text(report.render_markdown(), encoding="utf-8")
    return json_path, markdown_path
