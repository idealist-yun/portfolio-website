"""Stage-by-stage bottleneck diagnosis.

Answers the question the raw event log leaves implicit: after a run, *where
in the agent loop* did each difficulty arise, and what kind of intervention
would address it? Every event is classified against the loop stages the
architecture actually records:

- perception  — task/skill cues were missed (observation bandwidth);
- capacity    — a demand dimension exceeded profile capacity;
- regulation  — an emotional shift forced replanning, or state pressure was
                high while the step struggled;
- environment — required objects/people were missing or occupied;
- support     — support was needed: either it closed the gap
                (dependency point) or it failed to (care gap).

Each step then gets a resolution (independent / resolved_by_support /
unresolved) and an intervention suggestion derived from the binding demand
dimension, active prompt conditions, and required support level. Suggestions
describe simulation evidence; they are not clinical prescriptions.
"""

from dataclasses import dataclass, field

from idd_agent_sim.simulation import SimulationEvent

STAGES = ("perception", "capacity", "regulation", "environment", "support")

STATE_PRESSURE_THRESHOLD = 0.5

# Intervention vocabulary keyed by binding demand dimension.
DIMENSION_INTERVENTIONS = {
    "receptive_language": "simplify instructions (single-step, visual cues)",
    "expressive_language": "offer supported choices or AAC for responses",
    "sequencing": "provide a step-by-step checklist or demonstration",
    "sustained_attention": "shorten the step and add completion cues",
    "motor": "adapt materials or provide partial physical assistance",
    "social": "pre-teach the social script and rehearse with a partner",
}


@dataclass(frozen=True)
class EventDiagnosis:
    agent_id: str
    scenario_id: str
    step_id: str
    stages: tuple[str, ...]
    resolution: str  # independent | resolved_by_support | unresolved
    binding_dimension: str
    support_level: str
    support_partner: str | None
    intervention: str


@dataclass(frozen=True)
class StepDiagnosis:
    scenario_id: str
    step_id: str
    total_agents: int
    stage_counts: dict[str, int]
    resolutions: dict[str, int]
    affected_agents: tuple[str, ...]
    dominant_stage: str
    dominant_dimension: str
    support_levels: tuple[str, ...]
    interventions: tuple[str, ...]


@dataclass(frozen=True)
class BottleneckStageReport:
    events: list[EventDiagnosis] = field(default_factory=list)
    steps: list[StepDiagnosis] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "stages": list(STAGES),
            "events": [
                {
                    "agent_id": item.agent_id,
                    "scenario_id": item.scenario_id,
                    "step_id": item.step_id,
                    "stages": list(item.stages),
                    "resolution": item.resolution,
                    "binding_dimension": item.binding_dimension,
                    "support_level": item.support_level,
                    "support_partner": item.support_partner,
                    "intervention": item.intervention,
                }
                for item in self.events
            ],
            "steps": [
                {
                    "scenario_id": step.scenario_id,
                    "step_id": step.step_id,
                    "total_agents": step.total_agents,
                    "stage_counts": step.stage_counts,
                    "resolutions": step.resolutions,
                    "affected_agents": list(step.affected_agents),
                    "dominant_stage": step.dominant_stage,
                    "dominant_dimension": step.dominant_dimension,
                    "support_levels": list(step.support_levels),
                    "interventions": list(step.interventions),
                }
                for step in self.steps
            ],
        }

    def render_markdown(self) -> str:
        lines = [
            "# Bottleneck Stage Report",
            "",
            "Loop-stage diagnosis of every difficulty in the run. Suggestions",
            "describe simulation evidence, not clinical prescriptions.",
            "",
        ]
        current_scenario = None
        for step in self.steps:
            if step.scenario_id != current_scenario:
                current_scenario = step.scenario_id
                lines.append(f"## {step.scenario_id}")
                lines.append("")
            struggling = step.total_agents - step.resolutions.get("independent", 0)
            lines.append(f"### {step.step_id}")
            lines.append("")
            if struggling == 0:
                lines.append("- all agents completed independently")
                lines.append("")
                continue
            stage_text = ", ".join(
                f"{stage}={count}"
                for stage, count in step.stage_counts.items()
                if count
            )
            lines.append(
                f"- {struggling}/{step.total_agents} agents needed support or "
                f"failed; stages: {stage_text or 'none recorded'}"
            )
            lines.append(
                f"- dominant stage: {step.dominant_stage or '-'}; "
                f"dominant dimension: {step.dominant_dimension or '-'}"
            )
            if step.support_levels:
                lines.append(
                    f"- support levels used: {', '.join(step.support_levels)}"
                )
            for suggestion in step.interventions:
                lines.append(f"- intervention point: {suggestion}")
            unresolved = step.resolutions.get("unresolved", 0)
            if unresolved:
                lines.append(
                    f"- CARE GAP: {unresolved} agent(s) had no support that "
                    "closed the gap"
                )
            lines.append("")
        return "\n".join(lines)


def diagnose_event(event: SimulationEvent) -> EventDiagnosis:
    stages: list[str] = []
    skill_cues_missed = [
        cue for cue in event.missed_cues if not cue.startswith(("object:", "person:"))
    ]
    if skill_cues_missed:
        stages.append("perception")
    if event.exceeded_dimensions or (
        event.unmet_need > 0 and not event.exceeded_dimensions
    ):
        stages.append("capacity")
    if event.replan_triggered or (
        event.state_pressure >= STATE_PRESSURE_THRESHOLD and event.unmet_need > 0
    ):
        stages.append("regulation")
    if (
        event.environment_missing_objects
        or event.environment_missing_people
        or event.environment_occupied_objects
    ):
        stages.append("environment")
    if event.support_partner is not None or event.action_type == "support_request_blocked":
        stages.append("support")

    if event.completed and event.support_partner is None and event.unmet_need == 0:
        resolution = "independent"
    elif event.completed:
        resolution = "resolved_by_support"
    else:
        resolution = "unresolved"

    return EventDiagnosis(
        agent_id=event.agent_id,
        scenario_id=event.scenario_id,
        step_id=event.step_id,
        stages=tuple(stages),
        resolution=resolution,
        binding_dimension=event.binding_dimension,
        support_level=event.support_level,
        support_partner=event.support_partner,
        intervention=_intervention_for(event, stages),
    )


def _intervention_for(event: SimulationEvent, stages: list[str]) -> str:
    if event.completed and event.support_partner is None and event.unmet_need == 0:
        return ""
    if "environment" in stages:
        missing = ", ".join(
            [*event.environment_missing_objects, *event.environment_missing_people]
        )
        occupied = ", ".join(event.environment_occupied_objects)
        detail = missing or occupied or "prerequisites"
        return f"prepare the environment first ({detail})"
    if event.binding_dimension in DIMENSION_INTERVENTIONS:
        return DIMENSION_INTERVENTIONS[event.binding_dimension]
    if "perception" in stages:
        return "make task cues explicit before the step starts"
    if "regulation" in stages:
        return "reduce step size and add regulation support"
    if event.active_prompt_conditions:
        return f"apply recorded prompt conditions: {', '.join(event.active_prompt_conditions)}"
    if "support" in stages:
        return "keep a support partner available at this step"
    return ""


def generate_bottleneck_report(events: list[SimulationEvent]) -> BottleneckStageReport:
    diagnoses = [diagnose_event(event) for event in events]

    step_order: list[tuple[str, str]] = []
    by_step: dict[tuple[str, str], list[EventDiagnosis]] = {}
    for diagnosis in diagnoses:
        key = (diagnosis.scenario_id, diagnosis.step_id)
        if key not in by_step:
            by_step[key] = []
            step_order.append(key)
        by_step[key].append(diagnosis)

    steps: list[StepDiagnosis] = []
    for scenario_id, step_id in step_order:
        items = by_step[(scenario_id, step_id)]
        stage_counts = {
            stage: sum(1 for item in items if stage in item.stages)
            for stage in STAGES
        }
        resolutions: dict[str, int] = {}
        for item in items:
            resolutions[item.resolution] = resolutions.get(item.resolution, 0) + 1
        affected = tuple(
            item.agent_id for item in items if item.resolution != "independent"
        )
        dimension_counts: dict[str, int] = {}
        for item in items:
            if item.binding_dimension:
                dimension_counts[item.binding_dimension] = (
                    dimension_counts.get(item.binding_dimension, 0) + 1
                )
        active_stages = {
            stage: count for stage, count in stage_counts.items() if count
        }
        steps.append(
            StepDiagnosis(
                scenario_id=scenario_id,
                step_id=step_id,
                total_agents=len(items),
                stage_counts=stage_counts,
                resolutions=resolutions,
                affected_agents=affected,
                dominant_stage=(
                    max(active_stages, key=active_stages.get)
                    if active_stages
                    else ""
                ),
                dominant_dimension=(
                    max(dimension_counts, key=dimension_counts.get)
                    if dimension_counts
                    else ""
                ),
                support_levels=tuple(
                    dict.fromkeys(
                        item.support_level
                        for item in items
                        if item.support_partner is not None
                    )
                ),
                interventions=tuple(
                    dict.fromkeys(
                        item.intervention for item in items if item.intervention
                    )
                ),
            )
        )

    return BottleneckStageReport(events=diagnoses, steps=steps)
