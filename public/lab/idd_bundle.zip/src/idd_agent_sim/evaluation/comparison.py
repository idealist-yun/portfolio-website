from __future__ import annotations

from dataclasses import dataclass, field

from idd_agent_sim.simulation import SimulationEvent


@dataclass(frozen=True)
class AgentComparisonSummary:
    agent_id: str
    total_events: int
    completed_events: int
    support_events: int
    replan_events: int
    vineland_gap_events: int
    mean_plan_substeps: float
    active_prompt_conditions: tuple[str, ...] = ()
    action_counts: dict[str, int] = field(default_factory=dict)

    @property
    def completion_rate(self) -> float:
        if self.total_events == 0:
            return 0.0
        return self.completed_events / self.total_events

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "total_events": self.total_events,
            "completed_events": self.completed_events,
            "completion_rate": self.completion_rate,
            "support_events": self.support_events,
            "replan_events": self.replan_events,
            "vineland_gap_events": self.vineland_gap_events,
            "mean_plan_substeps": self.mean_plan_substeps,
            "active_prompt_conditions": list(self.active_prompt_conditions),
            "action_counts": dict(self.action_counts),
        }


@dataclass(frozen=True)
class ScenarioComparisonSummary:
    scenario_id: str
    total_events: int
    completed_events: int
    agents_with_vineland_gaps: tuple[str, ...]
    max_plan_substeps: int

    def to_dict(self) -> dict:
        return {
            "scenario_id": self.scenario_id,
            "total_events": self.total_events,
            "completed_events": self.completed_events,
            "agents_with_vineland_gaps": list(self.agents_with_vineland_gaps),
            "max_plan_substeps": self.max_plan_substeps,
        }


@dataclass(frozen=True)
class ComparisonReport:
    agent_summaries: tuple[AgentComparisonSummary, ...]
    scenario_summaries: tuple[ScenarioComparisonSummary, ...]

    def to_dict(self) -> dict:
        return {
            "agents": [summary.to_dict() for summary in self.agent_summaries],
            "scenarios": [summary.to_dict() for summary in self.scenario_summaries],
        }


def generate_comparison_report(events: list[SimulationEvent]) -> ComparisonReport:
    agent_ids = tuple(dict.fromkeys(event.agent_id for event in events))
    scenario_ids = tuple(dict.fromkeys(event.scenario_id for event in events))
    return ComparisonReport(
        agent_summaries=tuple(
            _agent_summary(agent_id, [event for event in events if event.agent_id == agent_id])
            for agent_id in agent_ids
        ),
        scenario_summaries=tuple(
            _scenario_summary(
                scenario_id,
                [event for event in events if event.scenario_id == scenario_id],
            )
            for scenario_id in scenario_ids
        ),
    )


def render_comparison_markdown(
    report: ComparisonReport,
    *,
    replay_path: str | None = None,
) -> str:
    lines = ["# Vineland Profile Comparison Report", ""]
    if replay_path is not None:
        lines.extend(["## Sandbox Replay", "", f"- Replay artifact: `{replay_path}`", ""])

    lines.extend(
        [
            "## Agent Summary",
            "",
            "| Agent | Completion | Support events | Replans | Vineland gap events | Mean substeps | Active prompts |",
            "| --- | ---: | ---: | ---: | ---: | ---: | --- |",
        ]
    )
    for summary in report.agent_summaries:
        prompts = ", ".join(summary.active_prompt_conditions) or "-"
        lines.append(
            "| "
            f"{summary.agent_id} | "
            f"{summary.completed_events}/{summary.total_events} | "
            f"{summary.support_events} | "
            f"{summary.replan_events} | "
            f"{summary.vineland_gap_events} | "
            f"{summary.mean_plan_substeps:.2f} | "
            f"{prompts} |"
        )

    lines.extend(
        [
            "",
            "## Scenario Summary",
            "",
            "| Scenario | Completion | Agents with Vineland gaps | Max substeps |",
            "| --- | ---: | --- | ---: |",
        ]
    )
    for summary in report.scenario_summaries:
        agents = ", ".join(summary.agents_with_vineland_gaps) or "-"
        lines.append(
            "| "
            f"{summary.scenario_id} | "
            f"{summary.completed_events}/{summary.total_events} | "
            f"{agents} | "
            f"{summary.max_plan_substeps} |"
        )

    return "\n".join(lines) + "\n"


def _agent_summary(agent_id: str, events: list[SimulationEvent]) -> AgentComparisonSummary:
    action_counts: dict[str, int] = {}
    prompts: list[str] = []
    for event in events:
        action_counts[event.action_type] = action_counts.get(event.action_type, 0) + 1
        prompts.extend(event.active_prompt_conditions)

    total_events = len(events)
    mean_plan_substeps = (
        sum(event.plan_substeps for event in events) / total_events
        if total_events
        else 0.0
    )
    return AgentComparisonSummary(
        agent_id=agent_id,
        total_events=total_events,
        completed_events=sum(1 for event in events if event.completed),
        support_events=sum(1 for event in events if event.support_partner),
        replan_events=sum(1 for event in events if event.replan_triggered),
        vineland_gap_events=sum(
            1 for event in events if event.vineland_prerequisite_gap_count > 0
        ),
        mean_plan_substeps=mean_plan_substeps,
        active_prompt_conditions=tuple(dict.fromkeys(prompts)),
        action_counts=action_counts,
    )


def _scenario_summary(
    scenario_id: str,
    events: list[SimulationEvent],
) -> ScenarioComparisonSummary:
    return ScenarioComparisonSummary(
        scenario_id=scenario_id,
        total_events=len(events),
        completed_events=sum(1 for event in events if event.completed),
        agents_with_vineland_gaps=tuple(
            dict.fromkeys(
                event.agent_id
                for event in events
                if event.vineland_prerequisite_gap_count > 0
            )
        ),
        max_plan_substeps=max((event.plan_substeps for event in events), default=0),
    )
