from dataclasses import dataclass

from idd_agent_sim.simulation import SimulationEvent


@dataclass(frozen=True)
class EvaluationSummary:
    task_goal_completion: float
    scenario_goal_completion: float
    bottleneck_count: int


def summarize_events(events: list[SimulationEvent]) -> EvaluationSummary:
    if not events:
        return EvaluationSummary(0.0, 0.0, 0)

    completed = sum(1 for event in events if event.completed)
    bottlenecks = sum(1 for event in events if not event.completed)
    task_goal_completion = completed / len(events)
    scenario_goal_completion = 1.0 if bottlenecks == 0 else 0.0

    return EvaluationSummary(
        task_goal_completion=task_goal_completion,
        scenario_goal_completion=scenario_goal_completion,
        bottleneck_count=bottlenecks,
    )

