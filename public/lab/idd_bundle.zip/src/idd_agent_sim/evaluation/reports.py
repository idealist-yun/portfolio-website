from dataclasses import dataclass, field

from idd_agent_sim.simulation import SimulationEvent


@dataclass(frozen=True)
class BottleneckReport:
    scenario_id: str
    step_id: str
    reason: str
    evidence: list[str]
    suggested_support: str


@dataclass(frozen=True)
class CareGapReport:
    scenario_id: str
    step_id: str
    unmet_need: float
    interpretation: str
    suggested_follow_up: str


@dataclass(frozen=True)
class SupportEffectivenessReport:
    partner: str
    attempted: int
    successful: int
    blocked: int

    @property
    def effectiveness_rate(self) -> float:
        if self.attempted == 0:
            return 0.0
        return self.successful / self.attempted


@dataclass(frozen=True)
class CaregiverReport:
    agent_id: str
    total_events: int
    completed_events: int
    bottlenecks: list[BottleneckReport] = field(default_factory=list)
    care_gaps: list[CareGapReport] = field(default_factory=list)
    support_effectiveness: list[SupportEffectivenessReport] = field(default_factory=list)
    summary_lines: list[str] = field(default_factory=list)

    def render_text(self) -> str:
        lines = [f"Caregiver report for {self.agent_id or 'unknown agent'}"]
        lines.extend(self.summary_lines)

        if self.bottlenecks:
            lines.append("Bottlenecks:")
            for report in self.bottlenecks:
                lines.append(
                    f"- {report.scenario_id}/{report.step_id}: "
                    f"{report.reason} Suggested support: {report.suggested_support}"
                )

        if self.care_gaps:
            lines.append("Care gaps:")
            for report in self.care_gaps:
                lines.append(
                    f"- {report.scenario_id}/{report.step_id}: "
                    f"{report.interpretation} Follow-up: {report.suggested_follow_up}"
                )

        if self.support_effectiveness:
            lines.append("Support effectiveness:")
            for report in self.support_effectiveness:
                lines.append(
                    f"- {report.partner}: {report.successful}/{report.attempted} "
                    f"successful, {report.blocked} blocked"
                )

        return "\n".join(lines)


def generate_caregiver_report(events: list[SimulationEvent]) -> CaregiverReport:
    if not events:
        return CaregiverReport(
            agent_id="",
            total_events=0,
            completed_events=0,
            summary_lines=["No simulation events were available."],
        )

    completed_events = sum(1 for event in events if event.completed)
    bottlenecks = [
        _bottleneck_report(event)
        for event in events
        if _is_bottleneck(event)
    ]
    care_gaps = [
        _care_gap_report(event)
        for event in events
        if _is_care_gap(event)
    ]
    support_effectiveness = _support_effectiveness(events)

    return CaregiverReport(
        agent_id=events[0].agent_id,
        total_events=len(events),
        completed_events=completed_events,
        bottlenecks=bottlenecks,
        care_gaps=care_gaps,
        support_effectiveness=support_effectiveness,
        summary_lines=[
            f"Completed {completed_events} of {len(events)} simulated step(s).",
            f"Identified {len(bottlenecks)} bottleneck(s) and {len(care_gaps)} care gap(s).",
        ],
    )


def _is_bottleneck(event: SimulationEvent) -> bool:
    return (
        not event.completed
        or event.unmet_need > 0
        or bool(event.missed_cues)
        or event.replan_triggered
    )


def _is_care_gap(event: SimulationEvent) -> bool:
    return event.unmet_need > 0 and event.action_type != "supported_completion"


def _bottleneck_report(event: SimulationEvent) -> BottleneckReport:
    evidence = [
        f"unmet_need={event.unmet_need:.3f}",
        f"state_pressure={event.state_pressure:.3f}",
        f"emotion_level={event.emotion_level:.3f}",
    ]
    if event.missed_cues:
        evidence.append(f"missed_cues={', '.join(event.missed_cues)}")
    if event.support_partner:
        evidence.append(f"support_partner={event.support_partner}")
    if event.replan_triggered:
        evidence.append(f"replan_count={event.replan_count}")
    if event.vineland_evidence_count:
        evidence.append(f"vineland_evidence={event.vineland_evidence_count}")
    if event.vineland_prerequisite_gap_count:
        evidence.append(f"vineland_prerequisite_gaps={event.vineland_prerequisite_gap_count}")
    if event.active_prompt_conditions:
        evidence.append(f"active_prompts={', '.join(event.active_prompt_conditions)}")

    return BottleneckReport(
        scenario_id=event.scenario_id,
        step_id=event.step_id,
        reason=_reason_for(event),
        evidence=evidence,
        suggested_support=_suggested_support_for(event),
    )


def _care_gap_report(event: SimulationEvent) -> CareGapReport:
    support_text = (
        f"{event.support_partner} was selected but did not close the gap"
        if event.support_partner
        else "no support partner was available in the event"
    )
    return CareGapReport(
        scenario_id=event.scenario_id,
        step_id=event.step_id,
        unmet_need=event.unmet_need,
        interpretation=(
            f"The step left unmet need ({event.unmet_need:.3f}); {support_text}."
        ),
        suggested_follow_up=_suggested_support_for(event),
    )


def _support_effectiveness(events: list[SimulationEvent]) -> list[SupportEffectivenessReport]:
    partners = sorted({event.support_partner for event in events if event.support_partner})
    reports: list[SupportEffectivenessReport] = []
    for partner in partners:
        partner_events = [event for event in events if event.support_partner == partner]
        successful = sum(
            1
            for event in partner_events
            if event.action_type == "supported_completion" and event.completed
        )
        blocked = len(partner_events) - successful
        reports.append(
            SupportEffectivenessReport(
                partner=partner,
                attempted=len(partner_events),
                successful=successful,
                blocked=blocked,
            )
        )
    return reports


def _reason_for(event: SimulationEvent) -> str:
    if event.action_type == "support_request_blocked":
        return "Support was requested, but available support did not close the execution gap."
    if event.action_type == "execution_bottleneck":
        return "Task demand exceeded the agent's current independent execution capacity."
    if event.missed_cues:
        return "The agent missed one or more task cues during execution."
    if event.replan_triggered:
        return "Emotional shift crossed the replanning threshold."
    if event.vineland_prerequisite_gap_count:
        return "Vineland-derived skill evidence suggested extra support for prerequisite adaptive behavior."
    if event.unmet_need > 0:
        return "The step required more support than the agent could independently supply."
    return "The event should be reviewed because it was marked as a bottleneck."


def _suggested_support_for(event: SimulationEvent) -> str:
    if event.action_type == "support_request_blocked":
        return "increase support availability or provide the prompt earlier in the routine"
    if event.missed_cues:
        return "make the cue more visible, concrete, or repeated before the action demand rises"
    if event.replan_triggered:
        return "break the step into smaller substeps and allow regulation time before retrying"
    if event.active_prompt_conditions:
        return f"use active prompts: {', '.join(event.active_prompt_conditions)}"
    if event.unmet_need > 0:
        return "reduce task demand or add structured support for this step"
    return "monitor this step in future runs"
