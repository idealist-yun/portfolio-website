from __future__ import annotations

from dataclasses import dataclass

from idd_agent_sim.simulation import SimulationEvent


@dataclass(frozen=True)
class ValidationCriterion:
    criterion_id: str
    category: str
    title: str
    status: str
    review_mode: str
    evidence: tuple[str, ...] = ()

    def to_dict(self) -> dict:
        return {
            "criterion_id": self.criterion_id,
            "category": self.category,
            "title": self.title,
            "status": self.status,
            "review_mode": self.review_mode,
            "evidence": list(self.evidence),
        }


@dataclass(frozen=True)
class ValidationRubricReport:
    criteria: tuple[ValidationCriterion, ...]

    @property
    def automated_pass_count(self) -> int:
        return sum(
            1
            for criterion in self.criteria
            if criterion.review_mode == "automated" and criterion.status == "pass"
        )

    @property
    def automated_fail_count(self) -> int:
        return sum(
            1
            for criterion in self.criteria
            if criterion.review_mode == "automated" and criterion.status == "fail"
        )

    def to_dict(self) -> dict:
        return {
            "automated_pass_count": self.automated_pass_count,
            "automated_fail_count": self.automated_fail_count,
            "criteria": [criterion.to_dict() for criterion in self.criteria],
        }


def generate_validation_report(
    events: list[SimulationEvent],
    artifacts: dict[str, bool],
) -> ValidationRubricReport:
    return ValidationRubricReport(
        criteria=(
            _architecture_loop_criterion(events),
            _profile_constraint_criterion(events),
            _skill_retrieval_criterion(events),
            _vineland_evidence_criterion(events),
            _behavior_difference_criterion(events),
            _caregiver_report_criterion(artifacts),
            _output_artifact_criterion(artifacts),
            _sandbox_replay_criterion(artifacts),
            _synthetic_generation_criterion(artifacts),
            _manual_clinical_review_criterion(),
        )
    )


def render_validation_markdown(report: ValidationRubricReport) -> str:
    lines = [
        "# IDD Agent Fidelity Validation Report",
        "",
        f"- Automated pass: {report.automated_pass_count}",
        f"- Automated fail: {report.automated_fail_count}",
        "",
        "| Category | Criterion | Status | Review | Evidence |",
        "| --- | --- | --- | --- | --- |",
    ]
    for criterion in report.criteria:
        evidence = "<br>".join(criterion.evidence) if criterion.evidence else "-"
        lines.append(
            "| "
            f"{criterion.category} | "
            f"{criterion.title} | "
            f"{criterion.status} | "
            f"{criterion.review_mode} | "
            f"{evidence} |"
        )
    return "\n".join(lines) + "\n"


def _architecture_loop_criterion(events: list[SimulationEvent]) -> ValidationCriterion:
    required = {"long_plan", "perceive", "retrieve", "plan", "act", "environment", "reflect", "update"}
    passing = bool(events) and all(required.issubset(set(event.loop_stages)) for event in events)
    return ValidationCriterion(
        criterion_id="architecture.loop_stages",
        category="architecture",
        title="Generative-agent-style loop stages are recorded",
        status="pass" if passing else "fail",
        review_mode="automated",
        evidence=(f"events={len(events)}", f"required_stages={', '.join(sorted(required))}"),
    )


def _profile_constraint_criterion(events: list[SimulationEvent]) -> ValidationCriterion:
    passing = bool(events) and all(event.plan_substeps >= 1 for event in events)
    constraint_sources = tuple(dict.fromkeys(event.constraint_source for event in events))
    return ValidationCriterion(
        criterion_id="architecture.profile_native_constraints",
        category="architecture",
        title="Profile-native constraints reach planning/action events",
        status="pass" if passing else "fail",
        review_mode="automated",
        evidence=(
            f"constraint_sources={', '.join(constraint_sources) if constraint_sources else '-'}",
            f"max_plan_substeps={max((event.plan_substeps for event in events), default=0)}",
        ),
    )


def _skill_retrieval_criterion(events: list[SimulationEvent]) -> ValidationCriterion:
    retrieved = sum(1 for event in events if event.retrieved_skills)
    return ValidationCriterion(
        criterion_id="architecture.skill_retrieval",
        category="architecture",
        title="Skill retrieval contributes to the agent loop",
        status="pass" if retrieved else "fail",
        review_mode="automated",
        evidence=(f"events_with_retrieved_skills={retrieved}",),
    )


def _vineland_evidence_criterion(events: list[SimulationEvent]) -> ValidationCriterion:
    matched = sum(1 for event in events if event.vineland_evidence_count > 0)
    if not matched:
        status = "not_applicable"
    else:
        status = "pass"
    return ValidationCriterion(
        criterion_id="clinical.vineland_evidence_to_constraints",
        category="clinical_data",
        title="K-Vineland evidence is represented as behavior constraints when present",
        status=status,
        review_mode="automated",
        evidence=(
            f"events_with_vineland_evidence={matched}",
            "dependency rules are treated as generation priors, not response-validity alerts",
        ),
    )


def _behavior_difference_criterion(events: list[SimulationEvent]) -> ValidationCriterion:
    agent_ids = tuple(dict.fromkeys(event.agent_id for event in events))
    if len(agent_ids) < 2:
        return ValidationCriterion(
            criterion_id="behavior.profile_differentiation",
            category="behavior",
            title="Different profiles produce distinguishable behavior in the same environment",
            status="not_applicable",
            review_mode="automated",
            evidence=(f"agent_count={len(agent_ids)}",),
        )

    signatures = {
        event.agent_id: (
            sum(item.plan_substeps for item in events if item.agent_id == event.agent_id),
            sum(1 for item in events if item.agent_id == event.agent_id and item.support_partner),
            sum(1 for item in events if item.agent_id == event.agent_id and item.replan_triggered),
            tuple(
                sorted(
                    {
                        prompt
                        for item in events
                        if item.agent_id == event.agent_id
                        for prompt in item.active_prompt_conditions
                    }
                )
            ),
        )
        for event in events
    }
    distinct = len(set(signatures.values()))
    return ValidationCriterion(
        criterion_id="behavior.profile_differentiation",
        category="behavior",
        title="Different profiles produce distinguishable behavior in the same environment",
        status="pass" if distinct > 1 else "fail",
        review_mode="automated",
        evidence=(f"agent_count={len(agent_ids)}", f"distinct_behavior_signatures={distinct}"),
    )


def _caregiver_report_criterion(artifacts: dict[str, bool]) -> ValidationCriterion:
    return ValidationCriterion(
        criterion_id="outputs.caregiver_report_boundary",
        category="outputs",
        title="Caregiver report is generated as interpretation, not diagnosis",
        status="pass" if artifacts.get("caregiver_report") else "fail",
        review_mode="automated",
        evidence=("caregiver_report.txt exists" if artifacts.get("caregiver_report") else "missing caregiver_report.txt",),
    )


def _output_artifact_criterion(artifacts: dict[str, bool]) -> ValidationCriterion:
    required = (
        "events",
        "insights",
        "summary",
        "caregiver_report",
        "comparison_report",
        "comparison_markdown",
    )
    missing = tuple(name for name in required if not artifacts.get(name))
    return ValidationCriterion(
        criterion_id="outputs.required_artifacts",
        category="outputs",
        title="Required experiment artifacts are written",
        status="pass" if not missing else "fail",
        review_mode="automated",
        evidence=(f"missing={', '.join(missing) if missing else 'none'}",),
    )


def _sandbox_replay_criterion(artifacts: dict[str, bool]) -> ValidationCriterion:
    passing = artifacts.get("sandbox_meta") and artifacts.get("sandbox_master_movement")
    return ValidationCriterion(
        criterion_id="outputs.sandbox_replay",
        category="outputs",
        title="2D sandbox replay payload is available",
        status="pass" if passing else "fail",
        review_mode="automated",
        evidence=(
            f"meta={bool(artifacts.get('sandbox_meta'))}",
            f"master_movement={bool(artifacts.get('sandbox_master_movement'))}",
        ),
    )


def _synthetic_generation_criterion(artifacts: dict[str, bool]) -> ValidationCriterion:
    if not artifacts.get("synthetic_profile_pipeline"):
        status = "not_applicable"
    else:
        status = "pass" if artifacts.get("generated_profiles") else "fail"
    return ValidationCriterion(
        criterion_id="clinical.synthetic_generation",
        category="clinical_data",
        title="Synthetic profile generation writes inspectable YAML profiles",
        status=status,
        review_mode="automated",
        evidence=(
            f"synthetic_profile_pipeline={bool(artifacts.get('synthetic_profile_pipeline'))}",
            f"generated_profiles={bool(artifacts.get('generated_profiles'))}",
        ),
    )


def _manual_clinical_review_criterion() -> ValidationCriterion:
    return ValidationCriterion(
        criterion_id="manual.clinical_and_caregiver_review",
        category="manual_review",
        title="Clinician/caregiver review is still required before claiming clinical fidelity",
        status="manual",
        review_mode="manual",
        evidence=(
            "Review whether generated behavior is plausible for the intended IDD profile.",
            "Review whether report language avoids diagnosis or normed scoring claims.",
        ),
    )
