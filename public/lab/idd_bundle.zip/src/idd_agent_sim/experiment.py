import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import yaml

from idd_agent_sim.clinical import generate_synthetic_vineland_profile_batch
from idd_agent_sim.clinical import load_vineland_response_items
from idd_agent_sim.config import load_yaml
from idd_agent_sim.dashboard import build_dashboard
from idd_agent_sim.evaluation.bottleneck_analysis import generate_bottleneck_report
from idd_agent_sim.evaluation import (
    generate_caregiver_report,
    generate_comparison_report,
    generate_validation_report,
    render_comparison_markdown,
    render_validation_markdown,
    summarize_events,
)
from idd_agent_sim.sandbox.generative_agents import (
    movements_from_simulation_events_by_agent,
    ville_movements_from_events,
    write_compressed_replay,
)
from idd_agent_sim.sandbox.ville import VilleMap
from idd_agent_sim.simulation import Simulation, SimulationResult


@dataclass(frozen=True)
class ExperimentRunResult:
    name: str
    simulation: SimulationResult
    output_dir: Path
    events_path: Path
    summary_path: Path
    caregiver_report_path: Path
    comparison_report_path: Path
    comparison_markdown_path: Path
    validation_report_path: Path
    validation_markdown_path: Path
    sandbox_replay_dir: Path
    insights_path: Path | None = None
    bottleneck_report_path: Path | None = None
    dashboard_path: Path | None = None
    generated_profile_dir: Path | None = None


class ExperimentRunner:
    def __init__(self, config_path: str | Path, output_dir: str | Path | None = None) -> None:
        self.config_path = Path(config_path)
        self.generated_profiles: list[dict[str, Any]] = []
        self.config = self._load_config(self.config_path)
        self.name = str(self.config.get("simulation", {}).get("name", self.config_path.stem))
        configured_output = self.config.get("outputs", {}).get("dir")
        self.output_dir = Path(output_dir or configured_output or Path("outputs") / self.name)

    def run(self) -> ExperimentRunResult:
        simulation = Simulation.from_config(self.config)
        result = simulation.run()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        events_path = self.output_dir / "events.jsonl"
        insights_path = self.output_dir / "insights.jsonl"
        summary_path = self.output_dir / "summary.json"
        caregiver_report_path = self.output_dir / "caregiver_report.txt"
        comparison_report_path = self.output_dir / "comparison_report.json"
        comparison_markdown_path = self.output_dir / "comparison_report.md"
        validation_report_path = self.output_dir / "validation_report.json"
        validation_markdown_path = self.output_dir / "validation_report.md"

        self._write_events(events_path, result)
        self._write_insights(insights_path, result)
        self._write_summary(summary_path, result)
        bottleneck_report_path = self.output_dir / "bottleneck_report.json"
        bottleneck_markdown_path = self.output_dir / "bottleneck_report.md"
        bottleneck_report = generate_bottleneck_report(result.events)
        bottleneck_report_path.write_text(
            json.dumps(bottleneck_report.to_dict(), indent=2, sort_keys=True),
            encoding="utf-8",
        )
        bottleneck_markdown_path.write_text(
            bottleneck_report.render_markdown(),
            encoding="utf-8",
        )
        caregiver_report_path.write_text(
            generate_caregiver_report(result.events).render_text(),
            encoding="utf-8",
        )
        sandbox_replay_dir = self._write_sandbox_replay(result)
        self._write_comparison_reports(
            comparison_report_path,
            comparison_markdown_path,
            result,
            sandbox_replay_dir,
        )
        generated_profile_dir = self._write_generated_profiles()
        self._write_validation_reports(
            validation_report_path,
            validation_markdown_path,
            result,
            {
                "events": events_path.exists(),
                "insights": insights_path.exists(),
                "summary": summary_path.exists(),
                "caregiver_report": caregiver_report_path.exists(),
                "comparison_report": comparison_report_path.exists(),
                "comparison_markdown": comparison_markdown_path.exists(),
                "sandbox_meta": (sandbox_replay_dir / "meta.json").exists(),
                "sandbox_master_movement": (
                    sandbox_replay_dir / "master_movement.json"
                ).exists(),
                "synthetic_profile_pipeline": bool(self.generated_profiles),
                "generated_profiles": bool(
                    generated_profile_dir and generated_profile_dir.exists()
                ),
            },
        )

        dashboard_path = build_dashboard(self.output_dir)

        return ExperimentRunResult(
            name=self.name,
            simulation=result,
            output_dir=self.output_dir,
            events_path=events_path,
            summary_path=summary_path,
            caregiver_report_path=caregiver_report_path,
            comparison_report_path=comparison_report_path,
            comparison_markdown_path=comparison_markdown_path,
            validation_report_path=validation_report_path,
            validation_markdown_path=validation_markdown_path,
            sandbox_replay_dir=sandbox_replay_dir,
            insights_path=insights_path,
            bottleneck_report_path=bottleneck_report_path,
            dashboard_path=dashboard_path,
            generated_profile_dir=generated_profile_dir,
        )

    def _load_config(self, path: Path) -> dict[str, Any]:
        config = load_yaml(path)
        base_dir = path.parent

        agents: list[dict[str, Any]] = []
        if "profile_path" in config:
            agents.append(
                self._load_profile(
                    base_dir,
                    config["profile_path"],
                    config.get("vineland_response_path"),
                )
            )
        if "profile_paths" in config:
            agents.extend(
                self._load_profile(base_dir, profile_path)
                for profile_path in config["profile_paths"]
            )
        if "synthetic_profiles" in config:
            self.generated_profiles = generate_synthetic_vineland_profile_batch(
                config["synthetic_profiles"]
            )
            agents.extend(self.generated_profiles)
        if agents:
            config["agents"] = agents
        if "scenario_path" in config:
            scenario_config = load_yaml(base_dir / config["scenario_path"])
            config["scenarios"] = scenario_config.get("scenarios", [])

        return config

    def _load_profile(
        self,
        base_dir: Path,
        profile_path: str,
        vineland_response_path: str | None = None,
    ) -> dict[str, Any]:
        profile = load_yaml(base_dir / profile_path)
        if vineland_response_path is not None:
            items = load_vineland_response_items(base_dir / vineland_response_path)
            vineland = dict(profile.get("vineland", {}))
            vineland["items"] = items
            vineland.setdefault("source", "k_vineland_ii_response_csv")
            profile["vineland"] = vineland
        return profile

    def _write_events(self, path: Path, result: SimulationResult) -> None:
        with path.open("w", encoding="utf-8") as file:
            for event in result.events:
                file.write(json.dumps(asdict(event), sort_keys=True) + "\n")

    def _write_insights(self, path: Path, result: SimulationResult) -> None:
        with path.open("w", encoding="utf-8") as file:
            for insight in result.insights:
                file.write(json.dumps(asdict(insight), sort_keys=True) + "\n")

    def _write_summary(self, path: Path, result: SimulationResult) -> None:
        summary = summarize_events(result.events)
        caregiver_report = generate_caregiver_report(result.events)
        payload = {
            "experiment": self.name,
            "events": len(result.events),
            "simulation_summary": result.summary(),
            "task_goal_completion": summary.task_goal_completion,
            "scenario_goal_completion": summary.scenario_goal_completion,
            "bottleneck_count": summary.bottleneck_count,
            "care_gap_count": len(caregiver_report.care_gaps),
        }
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    def _write_comparison_reports(
        self,
        json_path: Path,
        markdown_path: Path,
        result: SimulationResult,
        replay_dir: Path,
    ) -> None:
        report = generate_comparison_report(result.events)
        payload = report.to_dict()
        payload["artifacts"] = {
            "sandbox_replay_dir": str(replay_dir.relative_to(self.output_dir)),
            "sandbox_master_movement": str(
                (replay_dir / "master_movement.json").relative_to(self.output_dir)
            ),
        }
        json_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        markdown_path.write_text(
            render_comparison_markdown(
                report,
                replay_path=str(replay_dir.relative_to(self.output_dir)),
            ),
            encoding="utf-8",
        )

    def _write_sandbox_replay(self, result: SimulationResult) -> Path:
        persona_names = list(dict.fromkeys(event.agent_id for event in result.events))
        layout = None
        if VilleMap.is_available():
            ville = VilleMap.load()
            movements, visited = ville_movements_from_events(result.events, ville)
            layout = ville.layout_payload(visited)
        else:
            movements = movements_from_simulation_events_by_agent(result.events)
        persona_names = list(
            dict.fromkeys(
                [*persona_names, *(movement.persona_name for movement in movements)]
            )
        )
        replay_dir = write_compressed_replay(
            self.output_dir / "sandbox_replay",
            self.name,
            persona_names,
            movements,
        )
        if layout is not None:
            (replay_dir / "map_layout.json").write_text(
                json.dumps(layout, indent=2, sort_keys=True),
                encoding="utf-8",
            )
        return replay_dir

    def _write_generated_profiles(self) -> Path | None:
        if not self.generated_profiles:
            return None
        target = self.output_dir / "generated_profiles"
        target.mkdir(parents=True, exist_ok=True)
        for profile in self.generated_profiles:
            profile_path = target / f"{profile['id']}.yaml"
            profile_path.write_text(
                yaml.safe_dump(profile, allow_unicode=True, sort_keys=False),
                encoding="utf-8",
            )
        return target

    def _write_validation_reports(
        self,
        json_path: Path,
        markdown_path: Path,
        result: SimulationResult,
        artifacts: dict[str, bool],
    ) -> None:
        report = generate_validation_report(result.events, artifacts)
        json_path.write_text(
            json.dumps(report.to_dict(), indent=2, sort_keys=True),
            encoding="utf-8",
        )
        markdown_path.write_text(render_validation_markdown(report), encoding="utf-8")


def run_experiment(
    config_path: str | Path = "pipelines/baseline.yaml",
    output_dir: str | Path | None = None,
) -> ExperimentRunResult:
    return ExperimentRunner(config_path, output_dir).run()
