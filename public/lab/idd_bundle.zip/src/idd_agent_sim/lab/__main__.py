"""Run the experiment lab: PYTHONPATH=src python -m idd_agent_sim.lab"""

import argparse
import os
from pathlib import Path

from idd_agent_sim.lab.server import prepare_data_root, serve


def _repository_root() -> Path:
    cwd = Path.cwd()
    if (cwd / "data" / "profiles").exists():
        return cwd
    return Path(__file__).resolve().parents[3]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8130")))
    source_root = _repository_root()
    parser.add_argument(
        "--root",
        default=os.getenv("IDD_AGENT_LAB_ROOT", str(source_root)),
        help="Writable data root (defaults to this checkout)",
    )
    args = parser.parse_args()
    root = prepare_data_root(source_root, args.root)
    serve(root, args.port, host=args.host)


if __name__ == "__main__":
    main()
