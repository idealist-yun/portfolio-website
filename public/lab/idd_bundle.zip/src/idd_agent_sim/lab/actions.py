"""Backend actions for the experiment lab.

Pure functions over the repository layout, kept separate from the HTTP
server so they are directly testable. All writes stay inside the repo:

- agents  -> data/profiles/lab/<id>.yaml   (synthetic virtual persons)
- scenarios -> data/scenarios/lab_<id>.yaml
- runs    -> outputs/lab_runs/<run_id>/    (standard ExperimentRunner output)
"""

from __future__ import annotations

import datetime as _dt
import json
import re
from pathlib import Path
from typing import Any

import yaml

from idd_agent_sim.clinical.vineland import KVINELAND_SURVEY_STRUCTURE
from idd_agent_sim.clinical.virtual_person import (
    TEMPLATES,
    build_virtual_person,
    write_virtual_person,
)
from idd_agent_sim.config import load_yaml
from idd_agent_sim.dashboard import collect_dashboard_data
from idd_agent_sim.evaluation.bottleneck_analysis import generate_bottleneck_report
from idd_agent_sim.experiment import ExperimentRunner
from idd_agent_sim.testbed import Scenario
from idd_agent_sim.testbed.demand import DEMAND_DIMENSIONS

SUBDOMAINS = tuple(KVINELAND_SURVEY_STRUCTURE)  # english keys
_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,40}$")
_RUN_MANIFEST = "lab_run.json"


def _profile_dirs(root: Path) -> list[Path]:
    return [
        root / "data" / "profiles" / "lab",
        root / "data" / "profiles" / "generated",
        root / "data" / "profiles",
    ]


def _agent_files(root: Path) -> list[Path]:
    seen: dict[str, Path] = {}
    for directory in _profile_dirs(root):
        if not directory.exists():
            continue
        for path in sorted(directory.glob("*.yaml")):
            config = load_yaml(path)
            agent_id = str(config.get("id", path.stem))
            seen.setdefault(agent_id, path)
    return list(seen.values())


def _scenario_files(root: Path) -> list[Path]:
    directory = root / "data" / "scenarios"
    return sorted(directory.glob("*.yaml")) if directory.exists() else []


def _validate_id(value: str, kind: str) -> str:
    value = str(value).strip()
    if not _ID_RE.match(value):
        raise ValueError(
            f"{kind} name must use lowercase letters, digits and underscores (e.g. mina_2). Got: {value!r}"
        )
    return value


def lab_state(root: str | Path) -> dict[str, Any]:
    root = Path(root)
    agents = []
    for path in _agent_files(root):
        config = load_yaml(path)
        agents.append(
            {
                "id": str(config.get("id", path.stem)),
                "file": str(path.relative_to(root)),
                "source": (
                    "template:" + str(config.get("template"))
                    if config.get("template")
                    else ("manual" if "vineland" in config else "example")
                ),
                "description": str(config.get("template_description", "")),
                "support_partners": sorted(config.get("support", {})),
            }
        )
    scenarios = []
    for path in _scenario_files(root):
        config = load_yaml(path)
        entries = config.get("scenarios", [])
        scenario_details = []
        for entry in entries:
            scenario = Scenario.from_config(entry)
            tick = 0
            steps = []
            for step in scenario.steps:
                actions = []
                for action in step.actions:
                    start_tick = tick
                    tick += action.duration_ticks
                    actions.append(
                        {
                            "id": action.action_id,
                            "type": action.action_type,
                            "label": action.label,
                            "target": action.target,
                            "location": action.location,
                            "start_tick": start_tick,
                            "end_tick": tick,
                            "duration_ticks": action.duration_ticks,
                        }
                    )
                steps.append(
                    {
                        "id": step.step_id,
                        "label": step.label,
                        "location": step.location,
                        "required_skill": step.required_skill,
                        "actions": actions,
                    }
                )
            scenario_details.append(
                {
                    "id": scenario.scenario_id,
                    "domain": scenario.domain,
                    "description": scenario.description,
                    "steps": steps,
                    "total_ticks": tick,
                    "action_count": sum(len(step["actions"]) for step in steps),
                }
            )
        scenarios.append(
            {
                "file": str(path.relative_to(root)),
                "name": str(config.get("name", path.stem)),
                "scenario_count": len(entries),
                "step_count": sum(len(s.get("steps", [])) for s in entries),
                "action_count": sum(
                    scenario["action_count"] for scenario in scenario_details
                ),
                "domains": sorted({str(s.get("domain", "")) for s in entries}),
                "scenarios": scenario_details,
            }
        )
    return {
        "agents": agents,
        "scenarios": scenarios,
        "templates": [
            {"name": name, "description": spec["description"]}
            for name, spec in sorted(TEMPLATES.items())
        ],
        "subdomains": list(SUBDOMAINS),
        "demand_dimensions": list(DEMAND_DIMENSIONS),
        "runs": lab_run_history(root),
    }


def lab_run_history(root: str | Path, limit: int = 12) -> list[dict[str, Any]]:
    """Return recent reproducible lab runs, newest first.

    A run only appears after its manifest has been written successfully. This
    keeps interrupted or legacy output directories from breaking the lab UI.
    """
    root = Path(root)
    run_root = root / "outputs" / "lab_runs"
    if not run_root.exists():
        return []
    runs = []
    for manifest_path in run_root.glob(f"*/{_RUN_MANIFEST}"):
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        runs.append(
            {
                "run_id": str(manifest.get("run_id", manifest_path.parent.name)),
                "created_at": str(manifest.get("created_at", "")),
                "agent_ids": list(manifest.get("agent_ids", [])),
                "scenario_files": list(manifest.get("scenario_files", [])),
                "summary": dict(manifest.get("summary", {})),
            }
        )
    runs.sort(key=lambda item: (item["created_at"], item["run_id"]), reverse=True)
    return runs[: max(0, int(limit))]


def load_lab_run(root: str | Path, run_id: str) -> dict[str, Any]:
    """Load a saved result grid and dashboard payload for replay in the lab."""
    root = Path(root)
    run_id = _validate_id(run_id, "run")
    run_dir = root / "outputs" / "lab_runs" / run_id
    manifest_path = run_dir / _RUN_MANIFEST
    if not manifest_path.exists():
        raise ValueError(f"Saved run not found: {run_id}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise ValueError(f"Run record is corrupted: {run_id}") from error
    grid = _upgrade_legacy_grid(dict(manifest.get("grid", {})))
    return {
        "run_id": run_id,
        "output_dir": str(run_dir.relative_to(root)),
        "grid": grid,
        "dashboard": collect_dashboard_data(run_dir),
        "manifest": manifest,
    }


def _upgrade_legacy_grid(grid: dict[str, Any]) -> dict[str, Any]:
    """Adapt pre-timeline run manifests without rewriting research artifacts."""

    columns = list(grid.get("columns", []))
    if not columns or all(column.get("action") for column in columns):
        return grid
    upgraded_columns = []
    tick_by_scenario: dict[str, int] = {}
    key_map: dict[str, str] = {}
    for column in columns:
        scenario = str(column.get("scenario", ""))
        step = str(column.get("step", ""))
        action = f"{step}_perform"
        tick = tick_by_scenario.get(scenario, 0)
        upgraded_columns.append(
            {
                **column,
                "step_label": step,
                "action": action,
                "action_type": "interact",
                "label": step,
                "location": "",
                "start_tick": tick,
                "end_tick": tick + 1,
                "duration_ticks": 1,
            }
        )
        tick_by_scenario[scenario] = tick + 1
        for agent in grid.get("agents", []):
            old_key = f"{agent}|{scenario}|{step}"
            key_map[old_key] = f"{old_key}|{action}"
    cells = {
        key_map.get(key, key): value for key, value in dict(grid.get("cells", {})).items()
    }
    return {**grid, "columns": upgraded_columns, "cells": cells}


def create_agent(root: str | Path, payload: dict[str, Any]) -> dict[str, Any]:
    root = Path(root)
    agent_id = _validate_id(payload.get("agent_id", ""), "Agent")
    target = root / "data" / "profiles" / "lab" / f"{agent_id}.yaml"
    if any(load_yaml(p).get("id") == agent_id for p in _agent_files(root)):
        raise ValueError(f"An agent named '{agent_id}' already exists.")

    mode = payload.get("mode", "manual")
    if mode == "template":
        template = str(payload.get("template", ""))
        profile = build_virtual_person(template, agent_id)
        write_virtual_person(profile, target)
    elif mode == "manual":
        subdomains = {}
        for key, value in dict(payload.get("subdomains", {})).items():
            if key not in SUBDOMAINS:
                raise ValueError(f"Unknown subdomain: {key}")
            subdomains[key] = max(0.0, min(1.0, float(value)))
        if not subdomains:
            raise ValueError("Enter at least one subdomain score.")
        support = {
            str(name).strip(): max(0.0, min(1.0, float(weight)))
            for name, weight in dict(payload.get("support", {})).items()
            if str(name).strip()
        } or {"caregiver": 0.7}
        items = _parse_item_rows(payload.get("items_csv", ""))
        config: dict[str, Any] = {
            "id": agent_id,
            "self_sufficiency": max(
                0.0, min(1.0, float(payload.get("self_sufficiency", 0.5)))
            ),
            "support": support,
            "vineland": {
                "source": "lab_manual_entry",
                "subdomains": subdomains,
                **({"items": items} if items else {}),
            },
        }
        target.parent.mkdir(parents=True, exist_ok=True)
        header = (
            "# Lab-entered virtual person profile (K-Vineland structural\n"
            "# scaffold values). Not a real assessment.\n"
        )
        target.write_text(
            header + yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
    else:
        raise ValueError(f"Unknown creation mode: {mode}")

    return {"id": agent_id, "file": str(target.relative_to(root))}


def _parse_item_rows(raw: str) -> list[dict[str, Any]]:
    """Rows like `Receptive,9,Following Instructions,1` (subdomain,sequence,category,score)."""
    items = []
    for line_number, line in enumerate(str(raw or "").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split(",")]
        if len(parts) < 4:
            raise ValueError(
                f"Row {line_number}: 4 values needed: 'subdomain,sequence,category,score'."
            )
        items.append(
            {
                "subdomain": parts[0],
                "sequence": int(parts[1]),
                "content_category": parts[2],
                "score": parts[3],
            }
        )
    return items


def create_scenario(root: str | Path, payload: dict[str, Any]) -> dict[str, Any]:
    root = Path(root)
    file_id = _validate_id(payload.get("file_id", ""), "scenario")
    target = root / "data" / "scenarios" / f"lab_{file_id}.yaml"
    if target.exists():
        raise ValueError(f"File '{target.name}' already exists.")

    scenario_id = _validate_id(payload.get("scenario_id", file_id), "scenario")
    steps_in = list(payload.get("steps", []))
    if not steps_in:
        raise ValueError("Add at least one step.")
    steps = []
    for index, step in enumerate(steps_in, start=1):
        demand = {
            dim: max(0.0, min(1.0, float(value)))
            for dim, value in dict(step.get("demand", {})).items()
            if dim in DEMAND_DIMENSIONS and float(value) > 0
        }
        if not demand:
            raise ValueError(f"Step {index}: enter at least one demand dimension.")
        entry: dict[str, Any] = {
            "id": _validate_id(step.get("id", f"step_{index}"), "step"),
            "label": str(step.get("label", step.get("id", f"step {index}"))),
            "demand": demand,
        }
        if step.get("required_skill"):
            entry["required_skill"] = str(step["required_skill"])
        for key in ("required_objects", "required_people"):
            values = [str(v).strip() for v in step.get(key, []) if str(v).strip()]
            if values:
                entry[key] = values
        if step.get("location"):
            entry["location"] = str(step["location"])
        if step.get("actions"):
            entry["actions"] = list(step["actions"])
        steps.append(entry)

    config = {
        "id": f"lab_{file_id}",
        "name": str(payload.get("name", file_id)),
        "scenarios": [
            {
                "id": scenario_id,
                "domain": str(payload.get("domain", "self_care")),
                "description": str(payload.get("description", "")),
                "steps": steps,
            }
        ],
    }
    # Validate the complete executable timeline before persisting the file.
    Scenario.from_config(config["scenarios"][0])
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        yaml.safe_dump(config, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return {"file": str(target.relative_to(root)), "scenario_id": scenario_id}


def run_lab_experiment(root: str | Path, payload: dict[str, Any]) -> dict[str, Any]:
    root = Path(root)
    agent_ids = [str(a) for a in payload.get("agent_ids", [])]
    scenario_files = [str(s) for s in payload.get("scenario_files", [])]
    if not agent_ids:
        raise ValueError("Select at least one agent to run.")
    if not scenario_files:
        raise ValueError("Select at least one scenario to run.")

    by_id = {load_yaml(p).get("id", p.stem): p for p in _agent_files(root)}
    profile_paths = []
    for agent_id in agent_ids:
        if agent_id not in by_id:
            raise ValueError(f"Agent not found: {agent_id}")
        profile_paths.append(str(by_id[agent_id]))

    merged_scenarios: list[dict[str, Any]] = []
    required_objects: set[str] = set()
    required_people: set[str] = set()
    for rel in scenario_files:
        path = (root / rel).resolve()
        if not str(path).startswith(str((root / "data" / "scenarios").resolve())):
            raise ValueError(f"Invalid scenario path: {rel}")
        config = load_yaml(path)
        for scenario in config.get("scenarios", []):
            merged_scenarios.append(scenario)
            for step in scenario.get("steps", []):
                required_objects.update(step.get("required_objects", []))
                required_people.update(step.get("required_people", []))
    if not merged_scenarios:
        raise ValueError("The selected file contains no scenarios.")
    for profile_path in profile_paths:
        required_people.update(load_yaml(Path(profile_path)).get("support", {}))

    now = _dt.datetime.now().astimezone()
    run_id = now.strftime("run_%Y%m%d_%H%M%S_%f")
    run_dir = root / "outputs" / "lab_runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    scenario_file = run_dir / "_scenarios.yaml"
    scenario_file.write_text(
        yaml.safe_dump({"scenarios": merged_scenarios}, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    pipeline = {
        "simulation": {"name": run_id, "purpose": "lab run"},
        "profile_paths": profile_paths,
        "scenario_path": str(scenario_file),
        "world": {
            "support_availability": float(payload.get("support_availability", 0.8)),
            "environment": {
                "available_objects": sorted(required_objects),
                "available_people": sorted(required_people),
            },
        },
    }
    pipeline_file = run_dir / "_pipeline.yaml"
    pipeline_file.write_text(
        yaml.safe_dump(pipeline, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    result = ExperimentRunner(pipeline_file, output_dir=run_dir).run()
    grid = _result_grid(result)
    statuses = {"pass": 0, "supported": 0, "fail": 0}
    for cell in grid["cells"].values():
        statuses[cell["status"]] += 1
    manifest = {
        "schema_version": 1,
        "run_id": run_id,
        "created_at": now.isoformat(),
        "agent_ids": agent_ids,
        "scenario_files": scenario_files,
        "support_availability": pipeline["world"]["support_availability"],
        "output_dir": str(run_dir.relative_to(root)),
        "summary": {
            "agent_count": len(agent_ids),
            "scenario_file_count": len(scenario_files),
            "step_count": len(
                {(column["scenario"], column["step"]) for column in grid["columns"]}
            ),
            "action_count": len(grid["columns"]),
            "status_counts": statuses,
        },
        "grid": grid,
    }
    (run_dir / _RUN_MANIFEST).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    return {
        "run_id": run_id,
        "output_dir": str(run_dir.relative_to(root)),
        "grid": grid,
        "dashboard": collect_dashboard_data(run_dir),
        "manifest": manifest,
    }


def _result_grid(result) -> dict[str, Any]:
    """Agents x atomic scenario actions on a shared CJM-style time axis."""
    events = result.simulation.events
    report = generate_bottleneck_report(events)
    diagnosis_by_key = {
        (d.agent_id, d.scenario_id, d.step_id): d for d in report.events
    }
    agent_ids = list(dict.fromkeys(e.agent_id for e in events))
    columns: list[dict[str, Any]] = []
    seen = set()
    ticks: dict[str, int] = {}
    for event in events:
        key = (event.scenario_id, event.step_id)
        if key not in seen:
            seen.add(key)
            timeline = event.timeline_actions or [
                {
                    "id": f"{event.step_id}_perform",
                    "type": "interact",
                    "label": event.step_label or event.step_id,
                    "duration_ticks": 1,
                    "location": event.location or None,
                }
            ]
            tick = ticks.get(event.scenario_id, 0)
            for action in timeline:
                duration = max(1, int(action.get("duration_ticks", 1)))
                columns.append(
                    {
                        "scenario": event.scenario_id,
                        "step": event.step_id,
                        "step_label": event.step_label or event.step_id,
                        "action": str(action.get("id", f"{event.step_id}_perform")),
                        "action_type": str(action.get("type", "interact")),
                        "label": str(action.get("label", event.step_label or event.step_id)),
                        "location": action.get("location") or event.location,
                        "start_tick": tick,
                        "end_tick": tick + duration,
                        "duration_ticks": duration,
                    }
                )
                tick += duration
            ticks[event.scenario_id] = tick

    cells: dict[str, dict[str, Any]] = {}
    for event in events:
        diagnosis = diagnosis_by_key.get(
            (event.agent_id, event.scenario_id, event.step_id)
        )
        if event.completed and not event.support_partner:
            status, text = "pass", "Completed independently."
        elif event.completed:
            level = event.support_level or ""
            text = (
                f"Completed with support from {event.support_partner} ({level})."
            )
            status = "supported"
        else:
            status, text = "fail", "Could not complete."
        details = []
        if event.exceeded_dimensions:
            details.append(
                "Difficult parts: " + ", ".join(event.exceeded_dimensions)
            )
        if diagnosis and diagnosis.intervention:
            details.append("Helpful intervention: " + diagnosis.intervention)
        event_columns = [
            column
            for column in columns
            if column["scenario"] == event.scenario_id
            and column["step"] == event.step_id
        ]
        for column in event_columns:
            action_status, action_text = _atomic_action_result(
                event, column["action_type"], status, text
            )
            cell_key = (
                f"{event.agent_id}|{event.scenario_id}|{event.step_id}|"
                f"{column['action']}"
            )
            cells[cell_key] = {
                "status": action_status,
                "text": " ".join([action_text, *details]),
                "action_type": column["action_type"],
            }
    return {"agents": agent_ids, "columns": columns, "cells": cells}


def _atomic_action_result(event, action_type: str, final_status: str, final_text: str):
    if action_type == "move_to":
        return "pass", f"Walked the tile path to {event.location or 'the destination'}."
    if action_type == "observe":
        if event.missed_cues:
            status = "supported" if event.support_partner else "fail"
            return status, "Missed cues: " + ", ".join(event.missed_cues)
        return "pass", "Checked the needed cues and targets."
    if action_type == "communicate" and event.support_partner:
        return "supported", f"Interacted with {event.support_partner}."
    return final_status, final_text
