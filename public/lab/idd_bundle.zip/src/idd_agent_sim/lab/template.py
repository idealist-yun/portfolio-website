"""Experiment-lab SPA template.

Three hash-routed views:
- #/            main lab: intro, live Ville stage with action buttons,
                agent roster (game-character cards), scenario picker,
                agents x steps result grid with caregiver-language tooltips
- #/agents/new  Vineland entry form + template generator
- #/scenarios/new  scenario directory + creation form

Server injects __LAB_BOOT__ (map image, avatar sprites, initial state).
"""

TEMPLATE = r"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IDD Agent Lab</title>
<style>
:root {
  color-scheme: light dark;
  --bg: #f2f4f1; --panel: #ffffff; --text: #1d2822; --muted: #5e6b62;
  --line: #d7ded7; --accent: #2b6e5e; --warn: #b45309; --bad: #b91c1c;
  --good: #15803d; --chipbg: #e8efe9;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #0f1512; --panel: #171f1a; --text: #e7ede9; --muted: #97a69d;
    --line: #2a352d; --accent: #5cb89f; --warn: #f59e0b; --bad: #f87171;
    --good: #4ade80; --chipbg: #202b24;
  }
}
:root[data-theme="dark"] {
  --bg: #0f1512; --panel: #171f1a; --text: #e7ede9; --muted: #97a69d;
  --line: #2a352d; --accent: #5cb89f; --warn: #f59e0b; --bad: #f87171;
  --good: #4ade80; --chipbg: #202b24;
}
:root[data-theme="light"] {
  --bg: #f2f4f1; --panel: #ffffff; --text: #1d2822; --muted: #5e6b62;
  --line: #d7ded7; --accent: #2b6e5e; --warn: #b45309; --bad: #b91c1c;
  --good: #15803d; --chipbg: #e8efe9;
}
* { box-sizing: border-box; }
body {
  margin: 0; background: var(--bg); color: var(--text);
  font: 14px/1.55 -apple-system, "Segoe UI", "Apple SD Gothic Neo", Roboto, sans-serif;
}
.mono { font-family: ui-monospace, "SF Mono", Menlo, monospace; }
h1 { font-size: 1.15rem; margin: 0; }
h2 { font-size: 1rem; margin: 0 0 .6rem; }
h3 { font-size: .9rem; margin: 0 0 .4rem; }
.sub { color: var(--muted); }
a { color: var(--accent); }
button {
  font: inherit; border-radius: 9px; border: 1px solid var(--line);
  background: var(--panel); color: var(--text); padding: .45rem .9rem; cursor: pointer;
}
button.primary { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 700; }
button.big { padding: .6rem 1.2rem; font-size: .95rem; }
button:disabled { opacity: .45; cursor: not-allowed; }
input, select, textarea {
  font: inherit; background: var(--panel); color: var(--text);
  border: 1px solid var(--line); border-radius: 8px; padding: .4rem .6rem;
}
input[type=range] { accent-color: var(--accent); padding: 0; }
.wrap { max-width: 1180px; margin: 0 auto; padding: 1rem 1.2rem 4rem; }
.card { background: var(--panel); border: 1px solid var(--line); border-radius: 12px; padding: 1rem 1.1rem; }
.row { display: flex; gap: .6rem; flex-wrap: wrap; align-items: center; }
.toast {
  position: fixed; left: 50%; bottom: 1.2rem; transform: translateX(-50%);
  background: var(--text); color: var(--bg); padding: .5rem 1rem; border-radius: 999px;
  font-size: .85rem; opacity: 0; transition: opacity .25s; pointer-events: none; z-index: 50;
}
.toast.on { opacity: .95; }

/* intro */
.intro { display: flex; gap: 1rem 2rem; flex-wrap: wrap; align-items: baseline; margin-bottom: 1rem; }
.intro p { margin: .3rem 0 0; max-width: 68ch; color: var(--muted); }
.intro .mono { color: var(--accent); font-size: .74rem; letter-spacing: .1em; text-transform: uppercase; }

/* stage */
.stagegrid { display: grid; grid-template-columns: minmax(0,1fr); gap: 1rem; }
.stagecard { position: relative; background: #0f1a12; border-radius: 14px; overflow: hidden; border: 1px solid var(--line); }
.mapwrap {
  position: relative; aspect-ratio: 7 / 5; background: #6ec24a;
  max-height: min(62vh, 600px);
  width: min(100%, calc(min(62vh, 600px) * 1.4));
  margin-inline: auto;
}
.mapwrap img { position: absolute; inset: 0; width: 100%; height: 100%; display: block; }
.mapwrap canvas { position: absolute; inset: 0; width: 100%; height: 100%; }
.stagebtns {
  position: absolute; top: .7rem; right: .7rem; display: flex; flex-direction: column;
  gap: .45rem; z-index: 5; align-items: stretch;
}
.stagebtns button { box-shadow: 0 2px 10px rgba(0,0,0,.25); }
.maptools { display: flex; gap: .35rem; margin-left: auto; }
.maptools button { width: 34px; height: 32px; padding: 0; font-size: 1rem; }
.hud { display: flex; align-items: center; gap: .7rem; padding: .55rem .8rem;
  background: color-mix(in srgb, var(--panel) 94%, transparent); border-top: 1px solid var(--line); flex-wrap: wrap; }
.timeline { flex: 1; min-width: 160px; position: relative; padding-top: 8px; }
.timeline input { width: 100%; margin: 0; }
.markers { position: absolute; left: 0; right: 0; top: 0; height: 6px; }
.markers i { position: absolute; width: 5px; height: 5px; border-radius: 50%; background: var(--warn); transform: translateX(-50%); }
.markers i.bad { background: var(--bad); }
.caption { padding: .5rem .9rem .7rem; font-size: .84rem; color: var(--muted);
  background: color-mix(in srgb, var(--panel) 94%, transparent); display: grid; gap: .15rem; }
.caption b { color: var(--text); }
.stagenote { position: absolute; inset: 0; display: grid; place-items: center; color: #cfe3cf;
  background: rgba(10,16,12,.55); z-index: 4; text-align: center; padding: 1rem; }

/* roster */
.roster { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: .8rem; margin-top: .8rem; }
.agentcard {
  border: 2px solid var(--line); border-radius: 12px; padding: .7rem .8rem;
  background: var(--panel); cursor: pointer; display: flex; gap: .7rem; align-items: center;
}
.agentcard.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent); }
.agentcard .sprite {
  width: 52px; height: 52px; image-rendering: pixelated; background: var(--chipbg);
  border-radius: 10px; padding: 5px;
}
.agentcard .meta { min-width: 0; }
.agentcard .meta b { display: block; }
.agentcard .meta span { font-size: .74rem; color: var(--muted); display: block;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.scenchips { display: flex; flex-wrap: wrap; gap: .5rem; margin-top: .6rem; }
.scen {
  border: 2px solid var(--line); border-radius: 10px; padding: .45rem .7rem;
  cursor: pointer; background: var(--panel); font-size: .84rem;
}
.scen.on { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent); }
.scen .sub { font-size: .74rem; }
.scenario-inspector { margin-top: .9rem; border-top: 1px solid var(--line); padding-top: .8rem; }
.scenario-block + .scenario-block { margin-top: 1rem; }
.scenario-head { display: flex; justify-content: space-between; gap: 1rem; align-items: baseline; }
.journey { display: flex; overflow-x: auto; padding: .65rem 0 .35rem; gap: 0; }
.journey-step { display: flex; min-width: max-content; position: relative; padding-top: 1.35rem; }
.journey-step::before { content: attr(data-step); position: absolute; top: 0; left: .25rem;
  font-size: .68rem; color: var(--muted); }
.action-node { width: 118px; min-height: 64px; border-left: 2px solid var(--accent);
  background: var(--chipbg); padding: .4rem .5rem; font-size: .74rem; }
.action-node b { display: block; font-size: .76rem; }
.action-node .mono { display: block; color: var(--accent); font-size: .66rem; }

/* result grid */
.gridwrap { overflow-x: auto; margin-top: .6rem; }
table.results { border-collapse: separate; border-spacing: 3px; font-size: .78rem; min-width: max-content; }
table.results th { font-weight: 600; color: var(--muted); padding: .2rem .4rem; text-align: left; }
table.results th.scen { text-align: center; border-bottom: 1px solid var(--line); }
table.results th.stephead { text-align: center; background: var(--chipbg); }
table.results th.actionhead { width: 72px; max-width: 92px; vertical-align: bottom; text-align: center; }
table.results th.actionhead span { display: block; font-size: .68rem; line-height: 1.2; white-space: normal; }
table.results td.cell {
  width: 72px; height: 34px; border-radius: 6px; text-align: center; background: var(--chipbg); padding: 0;
}
td.cell.pass { background: color-mix(in srgb, var(--good) 55%, var(--panel)); }
td.cell.supported { background: color-mix(in srgb, var(--warn) 55%, var(--panel)); }
td.cell.fail { background: color-mix(in srgb, var(--bad) 60%, var(--panel)); }
.cellbtn { width: 100%; height: 34px; padding: 0; border: 0; border-radius: 6px;
  background: transparent; color: inherit; font-weight: 700; }
.result-detail { margin-top: .65rem; padding: .7rem .8rem; background: var(--chipbg);
  border-left: 3px solid var(--accent); min-height: 44px; }
.gridlegend { display: flex; gap: 1rem; margin-top: .5rem; font-size: .78rem; color: var(--muted); }
.gridlegend i { display: inline-block; width: 12px; height: 12px; border-radius: 4px; vertical-align: -1px; margin-right: .3rem; }

/* run history */
.runhistory { display: grid; gap: .55rem; margin-top: .7rem; }
.runitem {
  display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: .8rem;
  align-items: center; border-top: 1px solid var(--line); padding-top: .6rem;
}
.runitem:first-child { border-top: 0; padding-top: 0; }
.runmeta { min-width: 0; }
.runmeta b, .runmeta span { display: block; overflow: hidden; text-overflow: ellipsis; }
.runmeta .mono { font-size: .75rem; color: var(--accent); }
.runstats { display: flex; gap: .7rem; color: var(--muted); font-size: .78rem; margin-top: .2rem; }
.runstats .passn { color: var(--good); }
.runstats .supportn { color: var(--warn); }
.runstats .failn { color: var(--bad); }

/* forms */
.formgrid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1rem; }
.field { display: grid; gap: .25rem; margin-bottom: .7rem; }
.field label { font-size: .82rem; color: var(--muted); }
.slider { display: grid; grid-template-columns: 130px 1fr 44px; gap: .6rem; align-items: center; font-size: .84rem; }
.slider output { font-variant-numeric: tabular-nums; text-align: right; }
.steps { display: grid; gap: .8rem; }
.stepbox { border: 1px dashed var(--line); border-radius: 10px; padding: .7rem .8rem; }
.dims { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: .2rem .9rem; }
.filelist { display: grid; gap: .4rem; }
.filelist .f { display: flex; gap: .7rem; align-items: baseline; padding: .45rem .6rem;
  border: 1px solid var(--line); border-radius: 9px; font-size: .85rem; }
.filelist .f .mono { color: var(--accent); font-size: .76rem; }
.hidden { display: none !important; }
.backbar { margin-bottom: 1rem; }
@media (max-width: 600px) {
  .wrap { padding-inline: .7rem; }
  .stagebtns { position: static; flex-direction: row; padding: .55rem; background: var(--panel); }
  .stagebtns button { flex: 1; padding-inline: .35rem; font-size: .8rem; }
  .mapwrap { width: 100%; }
  .scenario-head { align-items: flex-start; }
  .action-node { width: 112px; }
}
</style>
</head>
<body>
<div class="toast" id="toast"></div>

<!-- ===================== MAIN VIEW ===================== -->
<div class="wrap" id="view-main">
  <div class="intro">
    <div>
      <div class="mono">idd-agent-sim // experiment lab</div>
      <h1>IDD AI Agent Lab</h1>
      <p>
        Create synthetic people with a clinical profile (K-Vineland structure), run them through daily-life
        scenarios in a virtual town, and see <b>which step breaks down and why</b>
        in caregiver language. Use the top-right buttons to add people and scenarios,
        then select and run them below.
      </p>
    </div>
  </div>

  <div class="stagegrid">
    <div class="stagecard">
      <div class="stagebtns">
        <button onclick="location.hash='#/agents/new'">➕ Add agent</button>
        <button onclick="location.hash='#/scenarios/new'">🗺️ Add scenario</button>
        <button class="primary" id="runBtn" onclick="runExperiment()">▶ Run scenario</button>
      </div>
      <div class="mapwrap" id="mapwrap">
        <img id="mapimg" alt="the Ville">
        <canvas id="stageCanvas"></canvas>
        <div class="stagenote" id="stagenote">
          <div>
            No replay yet.<br>
            Below, <b>select people and a scenario</b>, then press <b>▶ Run scenario</b>.
          </div>
        </div>
      </div>
      <div class="hud">
        <button id="playBtn">⏸ Pause</button>
        <button id="speedBtn">1×</button>
        <div class="timeline">
          <div class="markers" id="markers"></div>
          <input type="range" id="scrubber" min="0" max="0" value="0" step="1" aria-label="Timeline">
        </div>
        <span class="sub mono" id="stepnum"></span>
        <div class="maptools">
          <button id="zoomOutBtn" title="Zoom out" aria-label="Zoom out">−</button>
          <button id="cameraBtn" title="Toggle full map / follow agent" aria-label="Toggle camera">◎</button>
          <button id="zoomInBtn" title="Zoom in" aria-label="Zoom in">＋</button>
        </div>
      </div>
      <div class="caption" id="liveCaption"></div>
    </div>

    <div class="card">
      <div class="row" style="justify-content:space-between">
        <h2 style="margin:0">Agent roster <span class="sub" style="font-weight:400;font-size:.8rem">Click cards to add people to the experiment</span></h2>
        <span class="sub" id="selCount"></span>
      </div>
      <div class="roster" id="roster"></div>
      <h3 style="margin-top:1rem">Choose scenarios</h3>
      <div class="scenchips" id="scenchips"></div>
      <div class="scenario-inspector" id="scenarioPreview">
        <div class="sub">Select a scenario to preview its action timeline here.</div>
      </div>
    </div>

    <div class="card">
      <h2>Reading the results <span class="sub" style="font-weight:400;font-size:.8rem">Compare actions along the timeline, click a cell to see why</span></h2>
      <div class="gridwrap" id="resultGrid"><div class="sub">No results yet.</div></div>
      <div class="result-detail sub" id="resultDetail">Select a result cell to see why the agent did or did not complete that action.</div>
      <div class="gridlegend">
        <span><i style="background:color-mix(in srgb, var(--good) 55%, var(--panel))"></i>Completed independently</span>
        <span><i style="background:color-mix(in srgb, var(--warn) 55%, var(--panel))"></i>Completed with support</span>
        <span><i style="background:color-mix(in srgb, var(--bad) 60%, var(--panel))"></i>Not completed (bottleneck)</span>
      </div>
    </div>

    <div class="card">
      <h2>Recent runs <span class="sub" style="font-weight:400;font-size:.8rem">Reopen a run to reproduce its results and replay</span></h2>
      <div class="runhistory" id="runHistory"></div>
    </div>
  </div>
</div>

<!-- ===================== AGENT VIEW ===================== -->
<div class="wrap hidden" id="view-agent">
  <div class="backbar"><button onclick="location.hash='#/'">← Back to the lab</button></div>
  <h1>Create a new agent</h1>
  <p class="sub">Enter K-Vineland results directly, or generate a synthetic profile from template rules. Every profile is stored as a synthetic person.</p>
  <div class="formgrid" style="margin-top:1rem">
    <div class="card">
      <h2>① Enter results directly</h2>
      <div class="field"><label>Agent name (lowercase letters)</label>
        <input id="agName" placeholder="e.g. hana"></div>
      <h3>Subdomain scores (0 = major difficulty · 1 = independent)</h3>
      <div id="agSliders"></div>
      <div class="field" style="margin-top:.6rem"><label>Self-sufficiency (overall level of independent performance)</label>
        <div class="slider"><span>self_sufficiency</span>
          <input type="range" id="agSelf" min="0" max="1" step="0.05" value="0.5"
                 oninput="this.nextElementSibling.value=this.value">
          <output>0.5</output></div></div>
      <div class="field"><label>Support partners and dependency weights (comma-separated: name=weight)</label>
        <input id="agSupport" value="caregiver=0.7, teacher=0.4"></div>
      <div class="field"><label>Paste item responses (optional · one per line: "subdomain,sequence,category,score")</label>
        <textarea id="agItems" rows="3" placeholder="Receptive,9,Following Instructions,1&#10;Community,43,Getting Around,0"></textarea></div>
      <button class="primary big" onclick="createAgentManual()">Create agent from these results</button>
    </div>
    <div class="card">
      <h2>② Rule-based synthetic profile</h2>
      <p class="sub">Builds a consistent synthetic person from preset template rules (subdomain level → Vineland items + SIS ratings + personality).</p>
      <div class="field"><label>Agent name</label><input id="agTplName" placeholder="e.g. mina_2"></div>
      <div class="field"><label>Template</label><select id="agTemplate"></select></div>
      <p class="sub" id="tplDesc"></p>
      <button class="primary big" onclick="createAgentTemplate()">Generate synthetic Vineland profile</button>
    </div>
  </div>
</div>

<!-- ===================== SCENARIO VIEW ===================== -->
<div class="wrap hidden" id="view-scenario">
  <div class="backbar"><button onclick="location.hash='#/'">← Back to the lab</button></div>
  <h1>Scenarios</h1>
  <div class="formgrid" style="margin-top:1rem">
    <div class="card">
      <h2>Existing scenario files <span class="sub mono" style="font-size:.75rem">data/scenarios/</span></h2>
      <div class="filelist" id="scenFiles"></div>
    </div>
    <div class="card">
      <h2>Create a new scenario</h2>
      <div class="field"><label>File name (lowercase letters)</label><input id="scFile" placeholder="e.g. cafe_visit"></div>
      <div class="field"><label>Scenario title</label><input id="scName" placeholder="e.g. Order a drink at the cafe"></div>
      <div class="row">
        <div class="field" style="flex:1"><label>Domain</label>
          <select id="scDomain">
            <option value="self_care">self_care (self-care)</option>
            <option value="meal">meal (meals & medication)</option>
            <option value="mobility">mobility (getting around)</option>
            <option value="community">community</option>
            <option value="activity">activity (activities & shopping)</option>
            <option value="household_tasks">household_tasks (housework)</option>
          </select></div>
      </div>
      <h3 style="margin-top:.6rem">Steps</h3>
      <p class="sub">Each step automatically expands into move, observe, act and verify actions. If you enter an action timeline below, that order is used as-is.</p>
      <div class="steps" id="scSteps"></div>
      <div class="row" style="margin-top:.6rem">
        <button onclick="addStepBox()">＋ Add step</button>
        <button class="primary big" onclick="createScenario()">Create scenario</button>
      </div>
    </div>
  </div>
</div>

<script>
const BOOT = __LAB_BOOT__;
let STATE = BOOT.state;
const AVATARS = BOOT.avatars || [];
const avatarImgs = AVATARS.map(src => { const im = new Image(); im.src = src; return im; });
const selectedAgents = new Set();
const selectedScenarios = new Set();
let RUN = null;   // {grid, dashboard}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  })[ch]);
}

function toast(msg, isError) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.style.background = isError ? 'var(--bad)' : 'var(--text)';
  el.classList.add('on'); setTimeout(() => el.classList.remove('on'), 2600);
}
async function api(path, body) {
  const res = await fetch(path, body ? {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)
  } : undefined);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}
function avatarFor(id) {
  if (!AVATARS.length) return null;
  let h = 0; for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return h % AVATARS.length;
}
const agentColors = ['#2563eb', '#dc2626', '#d97706', '#059669', '#7c3aed', '#0891b2'];
function colorFor(id) {
  const idx = STATE.agents.findIndex(a => a.id === id);
  return agentColors[(idx >= 0 ? idx : 0) % agentColors.length];
}

/* ---------- router ---------- */
function route() {
  const hash = location.hash || '#/';
  document.getElementById('view-main').classList.toggle('hidden', hash !== '#/');
  document.getElementById('view-agent').classList.toggle('hidden', hash !== '#/agents/new');
  document.getElementById('view-scenario').classList.toggle('hidden', hash !== '#/scenarios/new');
}
window.addEventListener('hashchange', route);

/* ---------- roster & scenario picker ---------- */
function renderRoster() {
  const roster = document.getElementById('roster');
  roster.innerHTML = STATE.agents.map(agent => {
    const av = avatarFor(agent.id);
    const on = selectedAgents.has(agent.id);
    return `<div class="agentcard ${on ? 'on' : ''}" onclick="toggleAgent('${agent.id}')">
      ${av == null ? '' : `<img class="sprite" src="${AVATARS[av]}" alt="">`}
      <div class="meta"><b style="color:${colorFor(agent.id)}">${agent.id}</b>
        <span>${agent.source}</span>
        <span>${agent.description || 'Support: ' + agent.support_partners.join(', ')}</span>
      </div></div>`;
  }).join('') || '<div class="sub">No agents yet. Create one with "Add agent".</div>';
  document.getElementById('selCount').textContent =
    `Selected: ${selectedAgents.size} people · ${selectedScenarios.size} scenarios`;
  document.getElementById('runBtn').disabled = !(selectedAgents.size && selectedScenarios.size);
}
function toggleAgent(id) {
  selectedAgents.has(id) ? selectedAgents.delete(id) : selectedAgents.add(id);
  renderRoster();
}
function renderScenChips() {
  document.getElementById('scenchips').innerHTML = STATE.scenarios.map(s => `
    <div class="scen ${selectedScenarios.has(s.file) ? 'on' : ''}" onclick="toggleScen('${s.file}')">
      <b>${esc(s.name)}</b>
      <span class="sub">${s.scenario_count} scenarios · ${s.step_count} steps · ${s.action_count || 0} actions · ${s.domains.map(esc).join('/')}</span>
    </div>`).join('');
  renderScenarioPreview();
}
function toggleScen(file) {
  selectedScenarios.has(file) ? selectedScenarios.delete(file) : selectedScenarios.add(file);
  renderScenChips(); renderRoster();
}
function renderScenarioPreview() {
  const selected = STATE.scenarios.filter(s => selectedScenarios.has(s.file));
  const target = document.getElementById('scenarioPreview');
  if (!selected.length) {
    target.innerHTML = '<div class="sub">Select a scenario to preview its action timeline here.</div>';
    return;
  }
  target.innerHTML = selected.flatMap(file => file.scenarios.map(scenario => `
    <section class="scenario-block">
      <div class="scenario-head">
        <div><b>${esc(scenario.id)}</b> <span class="sub">${esc(scenario.description)}</span></div>
        <span class="mono sub">${scenario.total_ticks} tick</span>
      </div>
      <div class="journey" aria-label="${esc(scenario.id)} action timeline">
        ${scenario.steps.map(step => `<div class="journey-step" data-step="${esc(step.label)}">
          ${step.actions.map(action => `<div class="action-node">
            <span class="mono">${action.start_tick}–${action.end_tick} · ${esc(action.type)}</span>
            <b>${esc(action.label)}</b>
            <span class="sub">${esc(action.location || step.location || '')}</span>
          </div>`).join('')}
        </div>`).join('')}
      </div>
    </section>`)).join('');
}

/* ---------- run ---------- */
async function runExperiment() {
  const btn = document.getElementById('runBtn');
  btn.disabled = true; btn.textContent = '⏳ Running…';
  try {
    RUN = await api('/api/run', {
      agent_ids: [...selectedAgents], scenario_files: [...selectedScenarios],
    });
    toast(`Run complete — ${RUN.run_id}`);
    document.getElementById('stagenote').classList.add('hidden');
    loadReplay(RUN.dashboard);
    renderResultGrid(RUN.grid);
    STATE.runs = await api('/api/state').then(state => state.runs || []);
    renderRunHistory();
  } catch (err) { toast(err.message, true); }
  btn.disabled = false; btn.textContent = '▶ Run scenario';
  renderRoster();
}

function runDate(value) {
  if (!value) return '';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString('ko-KR', {
    month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}
function renderRunHistory() {
  const runs = STATE.runs || [];
  document.getElementById('runHistory').innerHTML = runs.map(run => {
    const counts = run.summary?.status_counts || {};
    return `<div class="runitem">
      <div class="runmeta">
        <span class="mono">${run.run_id} · ${runDate(run.created_at)}</span>
        <b>${run.agent_ids.join(', ') || 'No agent info'}</b>
        <span class="sub">${run.scenario_files.map(file => file.split('/').pop()).join(', ')}</span>
        <div class="runstats">
          <span class="passn">Independent ${counts.pass || 0}</span>
          <span class="supportn">Supported ${counts.supported || 0}</span>
          <span class="failn">Failed ${counts.fail || 0}</span>
        </div>
      </div>
      <button onclick="loadSavedRun('${run.run_id}', this)">Load</button>
    </div>`;
  }).join('') || '<div class="sub">No saved runs yet.</div>';
}
async function loadSavedRun(runId, button) {
  button.disabled = true; button.textContent = 'Loading…';
  try {
    RUN = await api('/api/runs/' + encodeURIComponent(runId));
    selectedAgents.clear(); selectedScenarios.clear();
    (RUN.manifest?.agent_ids || []).forEach(id => selectedAgents.add(id));
    (RUN.manifest?.scenario_files || []).forEach(file => selectedScenarios.add(file));
    renderRoster(); renderScenChips();
    document.getElementById('stagenote').classList.add('hidden');
    loadReplay(RUN.dashboard); renderResultGrid(RUN.grid);
    toast(`Run loaded — ${runId}`);
    document.getElementById('mapwrap').scrollIntoView({behavior: 'smooth', block: 'center'});
  } catch (err) {
    toast(err.message, true); button.disabled = false; button.textContent = 'Load';
  }
}

function renderResultGrid(grid) {
  if (!grid || !grid.columns.length) return;
  const scenSpans = [];
  const stepSpans = [];
  grid.columns.forEach(col => {
    const last = scenSpans[scenSpans.length - 1];
    if (last && last.scenario === col.scenario) last.span += 1;
    else scenSpans.push({scenario: col.scenario, span: 1});
    const stepKey = `${col.scenario}|${col.step}`;
    const lastStep = stepSpans[stepSpans.length - 1];
    if (lastStep && lastStep.key === stepKey) lastStep.span += 1;
    else stepSpans.push({key: stepKey, label: col.step_label || col.step, span: 1});
  });
  let html = '<table class="results"><tr><th></th>' +
    scenSpans.map(s => `<th class="scen" colspan="${s.span}">${esc(s.scenario)}</th>`).join('') + '</tr>';
  html += '<tr><th class="mono">time →</th>' + stepSpans.map(s =>
    `<th class="stephead" colspan="${s.span}">${esc(s.label)}</th>`).join('') + '</tr>';
  html += '<tr><th></th>' + grid.columns.map(c =>
    `<th class="actionhead"><span class="mono">${c.start_tick}–${c.end_tick}</span>` +
    `<span>${esc(c.label)}</span><span class="sub">${esc(c.action_type)}</span></th>`).join('') + '</tr>';
  for (const agent of grid.agents) {
    html += `<tr><th><b style="color:${colorFor(agent)}">●</b> ${esc(agent)}</th>`;
    for (const col of grid.columns) {
      const cellKey = `${agent}|${col.scenario}|${col.step}|${col.action}`;
      const cell = grid.cells[cellKey];
      if (!cell) { html += '<td class="cell"></td>'; continue; }
      const mark = cell.status === 'pass' ? '✓' : cell.status === 'supported' ? '◐' : '✕';
      html += `<td class="cell ${cell.status}"><button class="cellbtn" data-cell-key="${esc(cellKey)}"` +
        ` onclick="openResultDetail(this.dataset.cellKey)" aria-label="${esc(agent)} ${esc(col.label)} result">${mark}</button></td>`;
    }
    html += '</tr>';
  }
  html += '</table>';
  document.getElementById('resultGrid').innerHTML = html;
  document.getElementById('resultDetail').textContent = 'Select a result cell to see why the agent did or did not complete that action.';
}
function openResultDetail(cellKey) {
  if (!RUN?.grid) return;
  const cell = RUN.grid.cells[cellKey];
  const parts = cellKey.split('|');
  const column = RUN.grid.columns.find(c => c.scenario === parts[1] && c.step === parts[2] && c.action === parts[3]);
  const detail = document.getElementById('resultDetail');
  detail.innerHTML = `<b>${esc(parts[0])} · ${esc(column?.label || parts[3])}</b>` +
    `<span class="sub"> · tick ${column?.start_tick ?? '?'}–${column?.end_tick ?? '?'}</span><br>${esc(cell?.text || '')}`;
}

/* ---------- replay stage (shared logic with dashboard) ---------- */
let replay = null, layout = null, frameKeys = [], maxFrame = 0;
let frame = 0, playing = true, speedIdx = 0;
let cameraFollow = true, cameraZoom = 2.5;
const speeds = [1, 2, 4, 8], BASE_SPS = 6;
const canvas = document.getElementById('stageCanvas');
const ctx = canvas.getContext('2d');
const mapimg = document.getElementById('mapimg');
new ResizeObserver(() => {
  const rect = canvas.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1;
  canvas.width = rect.width * dpr; canvas.height = rect.height * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}).observe(canvas);
if (BOOT.map_image) mapimg.src = BOOT.map_image;

function loadReplay(dash) {
  replay = dash.replay_movement; layout = dash.map_layout;
  frameKeys = replay ? Object.keys(replay).sort((a, b) => Number(a) - Number(b)) : [];
  maxFrame = Math.max(0, frameKeys.length - 1);
  frame = 0; playing = true;
  mapimg.style.visibility = replay ? 'hidden' : 'visible';
  document.getElementById('playBtn').textContent = '⏸ Pause';
  document.getElementById('scrubber').max = maxFrame;
  buildMarkers();
}
function personsAt(k) { return replay ? (replay[frameKeys[Math.max(0, Math.min(maxFrame, k))]] || {}) : {}; }
function shortAction(d) { return (d || '').split(' @ ')[0].split(' with prompts:')[0]; }
function tweened() {
  const k = Math.floor(frame), t = frame - k;
  const cur = personsAt(k), nxt = personsAt(k + 1), out = {};
  for (const [name, info] of Object.entries(cur)) {
    const nx = nxt[name];
    out[name] = {
      x: nx ? info.movement[0] + (nx.movement[0] - info.movement[0]) * t : info.movement[0],
      y: nx ? info.movement[1] + (nx.movement[1] - info.movement[1]) * t : info.movement[1],
      info,
    };
  }
  return out;
}
function drawStage() {
  const rect = canvas.getBoundingClientRect();
  ctx.clearRect(0, 0, rect.width, rect.height);
  if (!replay) return;
  const mazeW = layout?.maze?.width || 140, mazeH = layout?.maze?.height || 100;
  const entries = Object.entries(tweened());
  const focusName = [...selectedAgents].find(name => entries.some(([n]) => n === name)) ||
    entries.find(([name]) => !name.endsWith('(support)'))?.[0];
  const focus = entries.find(([name]) => name === focusName)?.[1];
  const zoom = cameraFollow && focus ? cameraZoom : 1;
  const viewW = mazeW / zoom, viewH = mazeH / zoom;
  const cameraX = focus ? Math.max(0, Math.min(mazeW - viewW, focus.x - viewW / 2)) : 0;
  const cameraY = focus ? Math.max(0, Math.min(mazeH - viewH, focus.y - viewH / 2)) : 0;
  const sx = v => (v + 0.5 - cameraX) / viewW * rect.width;
  const sy = v => (v + 0.5 - cameraY) / viewH * rect.height;
  if (mapimg.complete && mapimg.naturalWidth) {
    ctx.drawImage(
      mapimg,
      cameraX / mazeW * mapimg.naturalWidth,
      cameraY / mazeH * mapimg.naturalHeight,
      viewW / mazeW * mapimg.naturalWidth,
      viewH / mazeH * mapimg.naturalHeight,
      0, 0, rect.width, rect.height
    );
  }
  const tilePx = Math.min(rect.width / viewW, rect.height / viewH);
  const cellCount = {}, cellSeen = {};
  entries.forEach(([, p]) => {
    const key = `${Math.round(p.x)},${Math.round(p.y)}`;
    cellCount[key] = (cellCount[key] || 0) + 1;
  });
  for (const [name, p] of entries) {
    const isPartner = name.endsWith('(support)');
    const key = `${Math.round(p.x)},${Math.round(p.y)}`;
    const slot = (cellSeen[key] = (cellSeen[key] || 0) + 1) - 1;
    let x = sx(p.x), y = sy(p.y);
    if (cellCount[key] > 1) {
      const angle = slot / cellCount[key] * Math.PI * 2 - Math.PI / 2;
      x += Math.cos(angle) * tilePx * .32; y += Math.sin(angle) * tilePx * .32;
    }
    const av = isPartner ? null : avatarFor(name);
    const spriteSize = Math.max(7, Math.min(20, tilePx * 1.2));
    const radius = isPartner ? Math.max(2, spriteSize * .28) : Math.max(3, spriteSize * .36);
    if (av != null && avatarImgs[av]?.complete) {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(avatarImgs[av], x - spriteSize / 2, y - spriteSize * .72, spriteSize, spriteSize);
      ctx.imageSmoothingEnabled = true;
    } else {
      ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = isPartner ? '#e8b93c' : colorFor(name); ctx.fill();
      ctx.lineWidth = Math.max(1, tilePx * .08); ctx.strokeStyle = '#fff'; ctx.stroke();
    }
    const emoji = p.info.pronunciatio || '';
    if (emoji && zoom > 1) { ctx.font = `${Math.max(9, Math.min(13, tilePx))}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText(emoji, x + spriteSize, y - spriteSize / 2); }
    const label = isPartner ? name.replace(' (support)', ' 🫱') : name;
    if (zoom < 1.5 && name !== focusName) continue;
    ctx.font = '600 10px sans-serif';
    const w = ctx.measureText(label).width + 10;
    ctx.fillStyle = 'rgba(12,16,20,0.72)';
    ctx.beginPath(); ctx.roundRect(x - w / 2, y + radius + 3, w, 15, 5); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.fillText(label, x, y + radius + 14);
  }
}
let lastWhole = -1, lastTick = performance.now();
setInterval(() => {
  const now = performance.now();
  if (playing && maxFrame > 0) {
    frame += (now - lastTick) / 1000 * BASE_SPS * speeds[speedIdx];
    if (frame > maxFrame) frame = 0;
  }
  lastTick = now; drawStage();
  const whole = Math.floor(frame);
  if (whole !== lastWhole) { lastWhole = whole; updateHud(); }
}, 60);
function updateHud() {
  document.getElementById('scrubber').value = Math.floor(frame);
  document.getElementById('stepnum').textContent = replay ? `${Math.floor(frame)} / ${maxFrame}` : '';
  const cur = personsAt(Math.floor(frame));
  document.getElementById('liveCaption').innerHTML = Object.entries(cur)
    .filter(([n]) => !n.endsWith('(support)'))
    .map(([n, i]) => `<div><b style="color:${colorFor(n)}">●</b> <b>${n}</b> — ${shortAction(i.description)}</div>`)
    .join('');
}
function buildMarkers() {
  const el = document.getElementById('markers'); el.innerHTML = '';
  if (!replay || maxFrame === 0) return;
  const html = [];
  frameKeys.forEach((key, i) => {
    const persons = replay[key];
    const trouble = Object.values(persons).some(p => /bottleneck|pausing|did not close/.test(p.description || ''));
    const support = Object.keys(persons).some(n => n.endsWith('(support)'));
    if (trouble) html.push(`<i class="bad" style="left:${i / maxFrame * 100}%"></i>`);
    else if (support) html.push(`<i style="left:${i / maxFrame * 100}%"></i>`);
  });
  el.innerHTML = html.join('');
}
document.getElementById('playBtn').onclick = () => {
  playing = !playing;
  document.getElementById('playBtn').textContent = playing ? '⏸ Pause' : '▶ Play';
};
document.getElementById('speedBtn').onclick = () => {
  speedIdx = (speedIdx + 1) % speeds.length;
  document.getElementById('speedBtn').textContent = speeds[speedIdx] + '×';
};
document.getElementById('scrubber').addEventListener('input', event => {
  frame = Number(event.target.value); playing = false;
  document.getElementById('playBtn').textContent = '▶ Play'; updateHud();
});
document.getElementById('zoomOutBtn').onclick = () => {
  cameraZoom = Math.max(1.25, cameraZoom - .5); cameraFollow = true; drawStage();
};
document.getElementById('zoomInBtn').onclick = () => {
  cameraZoom = Math.min(5, cameraZoom + .5); cameraFollow = true; drawStage();
};
document.getElementById('cameraBtn').onclick = () => {
  cameraFollow = !cameraFollow;
  document.getElementById('cameraBtn').textContent = cameraFollow ? '◎' : '▦';
  drawStage();
};

/* ---------- agent form ---------- */
function renderAgentForm() {
  document.getElementById('agSliders').innerHTML = STATE.subdomains.map(sd => `
    <div class="slider"><span>${sd}</span>
      <input type="range" min="0" max="1" step="0.05" value="0.5" data-subdomain="${sd}"
             oninput="this.nextElementSibling.value=this.value">
      <output>0.5</output></div>`).join('');
  const select = document.getElementById('agTemplate');
  select.innerHTML = STATE.templates.map(t => `<option value="${t.name}">${t.name}</option>`).join('');
  const desc = () => {
    const t = STATE.templates.find(t => t.name === select.value);
    document.getElementById('tplDesc').textContent = t ? t.description : '';
  };
  select.onchange = desc; desc();
}
async function refreshState() {
  STATE = await api('/api/state');
  renderRoster(); renderScenChips(); renderAgentForm(); renderScenFiles();
}
async function createAgentManual() {
  const subdomains = {};
  document.querySelectorAll('#agSliders input').forEach(input => {
    subdomains[input.dataset.subdomain] = Number(input.value);
  });
  const support = {};
  document.getElementById('agSupport').value.split(',').forEach(pair => {
    const [name, weight] = pair.split('=');
    if (name && weight) support[name.trim()] = Number(weight);
  });
  try {
    const created = await api('/api/agents', {
      mode: 'manual',
      agent_id: document.getElementById('agName').value,
      subdomains, support,
      self_sufficiency: Number(document.getElementById('agSelf').value),
      items_csv: document.getElementById('agItems').value,
    });
    toast(`Agent created: ${created.id}`);
    await refreshState(); location.hash = '#/';
  } catch (err) { toast(err.message, true); }
}
async function createAgentTemplate() {
  try {
    const created = await api('/api/agents', {
      mode: 'template',
      agent_id: document.getElementById('agTplName').value,
      template: document.getElementById('agTemplate').value,
    });
    toast(`Synthetic profile created: ${created.id}`);
    await refreshState(); location.hash = '#/';
  } catch (err) { toast(err.message, true); }
}

/* ---------- scenario form ---------- */
function renderScenFiles() {
  document.getElementById('scenFiles').innerHTML = STATE.scenarios.map(s => `
    <div class="f"><span class="mono">${s.file.split('/').pop()}</span>
      <b>${esc(s.name)}</b>
      <span class="sub">${s.step_count} steps · ${s.action_count || 0} actions · ${s.domains.map(esc).join('/')}</span></div>`).join('');
}
let stepCounter = 0;
function addStepBox() {
  stepCounter += 1;
  const box = document.createElement('div');
  box.className = 'stepbox';
  box.innerHTML = `
    <div class="row">
      <div class="field" style="flex:1"><label>Step id</label><input class="st-id" placeholder="e.g. order_drink"></div>
      <div class="field" style="flex:2"><label>Description (label)</label><input class="st-label" placeholder="e.g. Order a drink"></div>
    </div>
    <label class="sub" style="font-size:.78rem">Demand dimensions (0 = unused)</label>
    <div class="dims">
      ${STATE.demand_dimensions.map(d => `
        <div class="slider"><span>${d}</span>
          <input type="range" min="0" max="1" step="0.05" value="0" data-dim="${d}"
                 oninput="this.nextElementSibling.value=this.value">
          <output>0</output></div>`).join('')}
    </div>
    <div class="row" style="margin-top:.4rem">
      <div class="field" style="flex:1"><label>Required skill (optional)</label>
        <select class="st-skill"><option value="">None</option>
          ${['locate_object','sequence_task','sustain_task','navigate_environment','verify_information','request_support']
            .map(s => `<option>${s}</option>`).join('')}</select></div>
      <div class="field" style="flex:1"><label>Location (optional)</label><input class="st-loc" placeholder="e.g. cafe"></div>
      <div class="field" style="flex:1"><label>Required objects (comma-separated)</label><input class="st-obj" placeholder="menu, cup"></div>
      <div class="field" style="flex:1"><label>Required people (comma-separated)</label><input class="st-ppl" placeholder="caregiver"></div>
    </div>
    <div class="field"><label>Atomic action timeline (optional · one per line: type | description | tick | target)</label>
      <textarea class="st-actions" rows="4" placeholder="move_to | Go to the cafe counter | 1 | counter&#10;observe | Check the menu | 1 | menu&#10;communicate | Order a drink | 2 | staff&#10;verify | Confirm the order | 1 | order"></textarea>
    </div>`;
  document.getElementById('scSteps').appendChild(box);
}
async function createScenario() {
  const steps = [...document.querySelectorAll('#scSteps .stepbox')].map(box => {
    const demand = {};
    box.querySelectorAll('input[data-dim]').forEach(input => {
      if (Number(input.value) > 0) demand[input.dataset.dim] = Number(input.value);
    });
    const actions = box.querySelector('.st-actions').value.split('\n').map((line, index) => {
      const [type, label, ticks, target] = line.split('|').map(value => value?.trim());
      return type ? {
        id: `${box.querySelector('.st-id').value || 'step'}_action_${index + 1}`,
        type, label: label || type, duration_ticks: Number(ticks) || 1,
        target: target || null,
        location: box.querySelector('.st-loc').value || null,
      } : null;
    }).filter(Boolean);
    return {
      id: box.querySelector('.st-id').value,
      label: box.querySelector('.st-label').value,
      demand,
      required_skill: box.querySelector('.st-skill').value || null,
      location: box.querySelector('.st-loc').value || null,
      required_objects: box.querySelector('.st-obj').value.split(',').map(s => s.trim()).filter(Boolean),
      required_people: box.querySelector('.st-ppl').value.split(',').map(s => s.trim()).filter(Boolean),
      actions,
    };
  });
  try {
    const created = await api('/api/scenarios', {
      file_id: document.getElementById('scFile').value,
      scenario_id: document.getElementById('scFile').value,
      name: document.getElementById('scName').value,
      domain: document.getElementById('scDomain').value,
      steps,
    });
    toast(`Scenario created: ${created.file}`);
    await refreshState(); location.hash = '#/';
  } catch (err) { toast(err.message, true); }
}

/* ---------- boot ---------- */
renderRoster(); renderScenChips(); renderAgentForm(); renderScenFiles(); renderRunHistory();
addStepBox(); route(); updateHud();
</script>
</body>
</html>
"""
