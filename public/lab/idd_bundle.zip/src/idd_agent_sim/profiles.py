from dataclasses import dataclass, field
from typing import Any

from idd_agent_sim.clinical import SISProfile, VinelandProfile
from idd_agent_sim.skills.domains import skill_domains_for


VABS_DOMAINS = (
    "communication",
    "daily_living_skills",
    "socialization",
    "motor_skills",
    "maladaptive_behavior",
)

DEFAULT_VABS = {
    "communication": 0.5,
    "daily_living_skills": 0.5,
    "socialization": 0.5,
    "motor_skills": 0.5,
    "maladaptive_behavior": 0.2,
}


def clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True)
class SkillAccess:
    skill_name: str
    domain: str
    access_level: str = "independent"

    def is_accessible(self, support_available: bool, state_pressure: float) -> bool:
        if self.access_level == "independent":
            return True
        if self.access_level == "supported":
            return support_available
        if self.access_level == "state_dependent":
            return state_pressure < 0.65
        return False


@dataclass(frozen=True)
class SkillRepertoire:
    skills: tuple[SkillAccess, ...] = ()

    @classmethod
    def from_functional_scores(
        cls,
        vabs: dict[str, float],
        has_support: bool,
    ) -> "SkillRepertoire":
        daily = vabs["daily_living_skills"]
        communication = vabs["communication"]
        social = vabs["socialization"]
        motor = vabs["motor_skills"]

        skills = [
            SkillAccess("check_prerequisites", "general", "independent"),
            SkillAccess("replan_after_block", "general", "state_dependent"),
        ]
        if has_support and communication >= 0.25:
            skills.append(SkillAccess("request_support", "general", "supported"))

        self_care_access = "independent" if daily >= 0.55 else "supported"
        skills.extend(
            [
                SkillAccess("locate_object", "self_care", self_care_access),
                SkillAccess("sequence_task", "self_care", self_care_access),
                SkillAccess("sustain_task", "self_care", "state_dependent"),
            ]
        )

        activity_access = "independent" if (communication + social) / 2 >= 0.55 else "supported"
        if motor >= 0.35:
            skills.append(SkillAccess("navigate_environment", "activity", activity_access))
        skills.append(SkillAccess("verify_information", "activity", activity_access))

        return cls(skills=tuple(skills))

    @classmethod
    def from_vineland(
        cls,
        vineland: VinelandProfile,
        has_support: bool,
    ) -> "SkillRepertoire":
        return cls(
            skills=tuple(
                SkillAccess(
                    skill_name=spec.skill_name,
                    domain=spec.domain,
                    access_level=spec.access_level,
                )
                for spec in vineland.skill_access_specs(has_support)
            )
        )

    @classmethod
    def from_config(cls, config: list[dict[str, Any]]) -> "SkillRepertoire":
        return cls(
            skills=tuple(
                SkillAccess(
                    skill_name=str(item["skill"]),
                    domain=str(item.get("domain", "general")),
                    access_level=str(item.get("access_level", "independent")),
                )
                for item in config
            )
        )

    def accessible_skill_names(
        self,
        domain: str,
        *,
        support_available: bool,
        state_pressure: float,
    ) -> frozenset[str]:
        applicable_domains = skill_domains_for(domain)
        return frozenset(
            skill.skill_name
            for skill in self.skills
            if skill.domain in applicable_domains
            and skill.is_accessible(support_available, state_pressure)
        )


@dataclass(frozen=True)
class SupportNeedProfile:
    partner_weights: dict[str, float] = field(default_factory=dict)
    domain_intensity: dict[str, float] = field(default_factory=dict)
    calibration_source: str = "hand_specified"

    @classmethod
    def from_profile_values(
        cls,
        support: dict[str, float],
        vabs: dict[str, float],
    ) -> "SupportNeedProfile":
        domain_intensity = {
            "self_care": clamp(1.0 - vabs["daily_living_skills"]),
            "activity": clamp(1.0 - ((vabs["communication"] + vabs["socialization"]) / 2)),
            "community": clamp(1.0 - ((vabs["communication"] + vabs["socialization"]) / 2)),
            "meal": clamp(1.0 - ((vabs["daily_living_skills"] + vabs["motor_skills"]) / 2)),
            "household_tasks": clamp(1.0 - ((vabs["daily_living_skills"] + vabs["motor_skills"]) / 2)),
            "mobility": clamp(1.0 - ((vabs["communication"] + vabs["motor_skills"]) / 2)),
        }
        return cls(
            partner_weights=support,
            domain_intensity=domain_intensity,
            calibration_source="vabs_profile_values",
        )

    @classmethod
    def from_vineland(
        cls,
        support: dict[str, float],
        vineland: VinelandProfile,
    ) -> "SupportNeedProfile":
        return cls(
            partner_weights=support,
            domain_intensity=vineland.support_intensities(),
            calibration_source="vineland_scaffold",
        )

    @classmethod
    def from_sis(
        cls,
        support: dict[str, float],
        sis: SISProfile,
        fallback_domain_intensity: dict[str, float] | None = None,
    ) -> "SupportNeedProfile":
        """Calibrate support needs from a SIS-A-inspired rating scaffold.

        Partner dependency weights come from rated activity-area intensities
        when partner-area mappings exist; domains without SIS coverage keep
        their fallback intensity. This is a scaffold calibration, not normed
        SIS-A scoring.
        """
        domain_intensity = dict(fallback_domain_intensity or {})
        domain_intensity.update(sis.domain_intensities())
        return cls(
            partner_weights=sis.partner_dependency_weights(support),
            domain_intensity=domain_intensity,
            calibration_source=f"sis_a_scaffold:{sis.source}",
        )


@dataclass(frozen=True)
class AdaptiveFunctioningProfile:
    domain_capacity: dict[str, float] = field(default_factory=dict)

    @classmethod
    def from_profile_values(
        cls,
        vabs: dict[str, float],
        self_sufficiency: float,
    ) -> "AdaptiveFunctioningProfile":
        return cls(
            domain_capacity={
                "self_care": vabs["daily_living_skills"],
                "meal": (vabs["daily_living_skills"] + vabs["motor_skills"]) / 2,
                "household_tasks": (vabs["daily_living_skills"] + vabs["motor_skills"]) / 2,
                "mobility": (vabs["communication"] + vabs["socialization"]) / 2,
                "community": (vabs["communication"] + vabs["socialization"]) / 2,
                "activity": (vabs["communication"] + vabs["socialization"]) / 2,
                "default": self_sufficiency,
            }
        )

    def capacity_for(self, domain: str) -> float:
        return self.domain_capacity.get(domain, self.domain_capacity.get("default", 0.5))

    @classmethod
    def from_vineland(
        cls,
        vineland: VinelandProfile,
        self_sufficiency: float,
    ) -> "AdaptiveFunctioningProfile":
        return cls(domain_capacity=vineland.adaptive_capacities(self_sufficiency))


@dataclass(frozen=True)
class ProfileConstraintTraits:
    domain: str
    independent_capacity: float
    observation_bandwidth: float
    planning_granularity: int
    sequencing_tolerance: float
    support_trigger: float
    emotional_reactivity: float
    replan_trigger: float


@dataclass(frozen=True)
class DimensionalGap:
    """One demand dimension compared against the profile's capacity."""

    dimension: str
    demand: float
    capacity: float

    @property
    def gap(self) -> float:
        return self.demand - self.capacity

    @property
    def exceeded(self) -> bool:
        return self.gap > 0


@dataclass(frozen=True)
class VinelandConstraintSignal:
    evidence_count: int = 0
    prerequisite_gap_count: int = 0
    prerequisite_uncertainty_count: int = 0
    active_prompt_conditions: tuple[str, ...] = ()
    related_functional_skill_codes: tuple[str, ...] = ()
    constraint_intensity: float = 0.0
    source: str = "profile_baseline"


@dataclass(frozen=True)
class FunctionalProfile:
    vabs: dict[str, float]
    self_sufficiency: float
    support: dict[str, float] = field(default_factory=dict)
    character: dict[str, Any] = field(default_factory=dict)
    vineland: VinelandProfile | None = None
    sis: SISProfile | None = None
    skill_repertoire: SkillRepertoire | None = None
    support_needs: SupportNeedProfile | None = None
    adaptive_functioning: AdaptiveFunctioningProfile | None = None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "FunctionalProfile":
        vineland = (
            VinelandProfile.from_config(config["vineland"])
            if "vineland" in config
            else None
        )
        sis = SISProfile.from_config(config["sis"]) if "sis" in config else None
        raw_vabs = config.get("vabs", {})
        fallback_vabs = {
            domain: float(raw_vabs.get(domain, DEFAULT_VABS[domain]))
            for domain in VABS_DOMAINS
        }
        if vineland is not None:
            derived_vabs = vineland.domain_scores(fallback_vabs)
            vabs = {domain: float(derived_vabs.get(domain, 0.0)) for domain in VABS_DOMAINS}
        else:
            vabs = fallback_vabs
        support = {name: float(weight) for name, weight in config.get("support", {}).items()}
        if sis is not None:
            support = sis.partner_dependency_weights(support)
        if "self_sufficiency" in config:
            self_sufficiency = float(config["self_sufficiency"])
        elif sis is not None:
            self_sufficiency = sis.self_sufficiency_index()
        else:
            raise KeyError(
                "Profile config requires 'self_sufficiency' unless a 'sis' "
                "section provides a scaffold self-sufficiency index."
            )
        skill_repertoire = (
            SkillRepertoire.from_config(config["skill_repertoire"])
            if "skill_repertoire" in config
            else SkillRepertoire.from_vineland(vineland, bool(support))
            if vineland is not None
            else SkillRepertoire.from_functional_scores(vabs, bool(support))
        )
        fallback_support_needs = (
            SupportNeedProfile.from_vineland(support, vineland)
            if vineland is not None
            else SupportNeedProfile.from_profile_values(support, vabs)
        )
        support_needs = (
            SupportNeedProfile.from_sis(
                support,
                sis,
                fallback_domain_intensity=fallback_support_needs.domain_intensity,
            )
            if sis is not None
            else fallback_support_needs
        )
        adaptive_functioning = (
            AdaptiveFunctioningProfile.from_vineland(
                vineland,
                self_sufficiency,
            )
            if vineland is not None
            else AdaptiveFunctioningProfile.from_profile_values(
                vabs,
                self_sufficiency,
            )
        )
        return cls(
            vabs=vabs,
            self_sufficiency=self_sufficiency,
            support=support,
            character=dict(config.get("character", {})),
            vineland=vineland,
            sis=sis,
            skill_repertoire=skill_repertoire,
            support_needs=support_needs,
            adaptive_functioning=adaptive_functioning,
        )

    def functional_capacity(self, domain: str) -> float:
        return self.adaptive_profile().capacity_for(domain)

    def best_support_partner(self) -> str | None:
        if not self.support:
            return None
        return max(self.support, key=self.support.get)

    def adaptive_profile(self) -> AdaptiveFunctioningProfile:
        return self.adaptive_functioning or AdaptiveFunctioningProfile.from_profile_values(
            self.vabs,
            self.self_sufficiency,
        )

    def support_need_profile(self) -> SupportNeedProfile:
        return self.support_needs or SupportNeedProfile.from_profile_values(
            self.support,
            self.vabs,
        )

    def repertoire(self) -> SkillRepertoire:
        return self.skill_repertoire or SkillRepertoire.from_functional_scores(
            self.vabs,
            bool(self.support),
        )

    def prompt_conditions(self) -> tuple[str, ...]:
        if self.vineland is None:
            return ()
        return self.vineland.prompt_conditions()

    def vineland_skill_evidence(self) -> tuple:
        if self.vineland is None:
            return ()
        return self.vineland.skill_evidence()

    def vineland_generation_priors(self) -> tuple:
        if self.vineland is None:
            return ()
        return self.vineland.generation_priors()

    def vineland_constraint_signal(
        self,
        domain: str,
        required_skill: str | None,
    ) -> VinelandConstraintSignal:
        if self.vineland is None or required_skill is None:
            return VinelandConstraintSignal()

        evidence = self.vineland.skill_evidence()
        related = tuple(
            item
            for item in evidence
            if required_skill in item.simulation_skills
            or required_skill == item.functional_skill_code
        )
        if not related:
            return VinelandConstraintSignal(source="vineland_no_step_match")

        best_by_functional_skill = self._best_vineland_evidence_by_skill(evidence)
        prerequisite_gaps: set[str] = set()
        prerequisite_uncertainties: set[str] = set()
        prompts: list[str] = []

        for item in related:
            if item.access_level != "independent":
                prompts.extend(item.support_conditions)
            for prerequisite in item.prerequisite_skill_codes:
                prerequisite_item = best_by_functional_skill.get(prerequisite)
                if prerequisite_item is None:
                    prerequisite_uncertainties.add(prerequisite)
                    continue
                if prerequisite_item.access_level != "independent":
                    prerequisite_gaps.add(prerequisite)
                    prompts.extend(prerequisite_item.support_conditions)

        if prerequisite_gaps or prerequisite_uncertainties:
            for item in related:
                prompts.extend(item.support_conditions)

        average_score = sum(item.score for item in related) / len(related)
        skill_constraint = max(0.0, 0.55 - average_score) / 0.55
        prerequisite_constraint = min(0.35, len(prerequisite_gaps) * 0.12)
        uncertainty_constraint = min(0.15, len(prerequisite_uncertainties) * 0.04)
        intensity = clamp(skill_constraint + prerequisite_constraint + uncertainty_constraint)

        return VinelandConstraintSignal(
            evidence_count=len(related),
            prerequisite_gap_count=len(prerequisite_gaps),
            prerequisite_uncertainty_count=len(prerequisite_uncertainties),
            active_prompt_conditions=tuple(dict.fromkeys(prompts)),
            related_functional_skill_codes=tuple(
                dict.fromkeys(item.functional_skill_code for item in related)
            ),
            constraint_intensity=intensity,
            source=f"vineland:{self.vineland.source}",
        )

    def _best_vineland_evidence_by_skill(self, evidence: tuple) -> dict[str, Any]:
        best: dict[str, Any] = {}
        for item in evidence:
            current = best.get(item.functional_skill_code)
            if current is None or item.score > current.score:
                best[item.functional_skill_code] = item
        return best

    def accessible_skill_names(
        self,
        domain: str,
        *,
        support_available: bool,
        state_pressure: float,
    ) -> frozenset[str]:
        return self.repertoire().accessible_skill_names(
            domain,
            support_available=support_available,
            state_pressure=state_pressure,
        )

    def dimension_capacity(self, dimension: str) -> float:
        """Capacity on one demand dimension, from K-Vineland subdomains when
        available, otherwise from broad VABS domain scores."""
        if self.vineland is not None:
            v = self.vineland
            by_subdomain = {
                "receptive_language": v.score_for("receptive"),
                "expressive_language": v.score_for("expressive"),
                "sequencing": (v.score_for("personal") + v.score_for("coping_skills")) / 2,
                "sustained_attention": (
                    v.score_for("coping_skills") + v.score_for("personal")
                ) / 2,
                "social": v.score_for("interpersonal_relationships"),
            }
            if dimension in by_subdomain:
                return clamp(by_subdomain[dimension])
        by_domain = {
            "receptive_language": self.vabs["communication"],
            "expressive_language": self.vabs["communication"],
            "sequencing": self.vabs["daily_living_skills"],
            "sustained_attention": clamp(
                self.vabs["daily_living_skills"] * 0.6
                + (1.0 - self.vabs["maladaptive_behavior"]) * 0.4
            ),
            "motor": self.vabs["motor_skills"],
            "social": self.vabs["socialization"],
        }
        return clamp(by_domain.get(dimension, 0.5))

    def dimensional_gaps(
        self,
        demand_dimensions: dict[str, float],
    ) -> tuple[DimensionalGap, ...]:
        """Compare each demanded dimension against profile capacity."""
        return tuple(
            DimensionalGap(
                dimension=dimension,
                demand=float(demand),
                capacity=self.dimension_capacity(dimension),
            )
            for dimension, demand in sorted(demand_dimensions.items())
        )

    def constraint_traits(self, domain: str) -> ProfileConstraintTraits:
        communication = self.vabs["communication"]
        daily = self.vabs["daily_living_skills"]
        social = self.vabs["socialization"]
        maladaptive = self.vabs["maladaptive_behavior"]

        independent_capacity = min(self.self_sufficiency, self.functional_capacity(domain))
        observation_bandwidth = clamp((communication + social) / 2)
        planning_granularity = max(1, round(1 + (1 - daily) * 4))
        sequencing_tolerance = clamp((daily + communication) / 2)
        emotional_reactivity = clamp(0.35 + maladaptive * 0.65)
        domain_support_need = self.support_need_profile().domain_intensity.get(
            domain,
            clamp(1.0 - independent_capacity),
        )
        support_trigger = max(0.0, independent_capacity - (0.1 * domain_support_need))

        return ProfileConstraintTraits(
            domain=domain,
            independent_capacity=independent_capacity,
            observation_bandwidth=observation_bandwidth,
            planning_granularity=planning_granularity,
            sequencing_tolerance=sequencing_tolerance,
            support_trigger=support_trigger,
            emotional_reactivity=emotional_reactivity,
            replan_trigger=max(0.6, 1.4 - emotional_reactivity),
        )
