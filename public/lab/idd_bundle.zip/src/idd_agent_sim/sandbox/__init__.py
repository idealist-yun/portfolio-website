"""Adapters for external sandbox environments."""

