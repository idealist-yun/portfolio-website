from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from idd_agent_sim.simulation import SimulationEvent
from idd_agent_sim.sandbox.ville import VilleMap, VillePlace


@dataclass(frozen=True)
class GenerativeAgentMovement:
    step: int
    persona_name: str
    x: int
    y: int
    emoji: str
    action: str
    address: str
    chat: list[list[str]] | None = None

    def to_payload(self) -> dict:
        return {
            "movement": [self.x, self.y],
            "pronunciatio": self.emoji,
            "description": f"{self.action} @ {self.address}",
            "chat": self.chat,
        }


def write_compressed_replay(
    output_dir: str | Path,
    sim_code: str,
    persona_names: list[str],
    movements: list[GenerativeAgentMovement],
    *,
    start_date: str = "February 13, 2023",
    sec_per_step: int = 10,
    maze_name: str = "the_ville",
) -> Path:
    target = Path(output_dir) / sim_code
    target.mkdir(parents=True, exist_ok=True)

    max_step = max((movement.step for movement in movements), default=0)
    master_movement: dict[str, dict] = {str(step): {} for step in range(max_step + 1)}
    for movement in movements:
        master_movement[str(movement.step)][movement.persona_name] = movement.to_payload()

    meta = {
        "fork_sim_code": "idd_agent_sim_local",
        "start_date": start_date,
        "curr_time": f"{start_date}, 00:00:00",
        "sec_per_step": sec_per_step,
        "maze_name": maze_name,
        "persona_names": persona_names,
        "step": max_step,
    }

    (target / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    (target / "master_movement.json").write_text(
        json.dumps(master_movement, indent=2),
        encoding="utf-8",
    )
    return target


def baseline_idd_movements(persona_name: str = "Isabella Rodriguez") -> list[GenerativeAgentMovement]:
    address = "the Ville:Isabella Rodriguez's apartment:bathroom:shower"
    return [
        GenerativeAgentMovement(
            step=0,
            persona_name=persona_name,
            x=73,
            y=14,
            emoji="😴",
            action="sleeping before the ADL routine",
            address="the Ville:Isabella Rodriguez's apartment:main room:bed",
        ),
        GenerativeAgentMovement(
            step=30,
            persona_name=persona_name,
            x=72,
            y=14,
            emoji="🛏️",
            action="waking up and orienting to the morning routine",
            address="the Ville:Isabella Rodriguez's apartment:main room:bed",
        ),
        GenerativeAgentMovement(
            step=60,
            persona_name=persona_name,
            x=73,
            y=14,
            emoji="🪥",
            action="starting toothbrushing with visual routine support",
            address=address,
        ),
        GenerativeAgentMovement(
            step=90,
            persona_name=persona_name,
            x=74,
            y=14,
            emoji="❓",
            action="pausing after difficulty sequencing toothpaste and brushing",
            address=address,
        ),
        GenerativeAgentMovement(
            step=120,
            persona_name=persona_name,
            x=75,
            y=14,
            emoji="🤝",
            action="receiving caregiver prompt after support need is detected",
            address=address,
            chat=[["Caregiver", "Try the next picture on your checklist."]],
        ),
        GenerativeAgentMovement(
            step=150,
            persona_name=persona_name,
            x=76,
            y=14,
            emoji="✅",
            action="completing toothbrushing after structured support",
            address=address,
        ),
    ]


ACTION_EMOJI = {
    "independent_completion": "✅",
    "supported_completion": "🤝",
    "support_request_blocked": "⚠️",
    "execution_bottleneck": "❓",
}


DEFAULT_ROUTE = [
    (73, 14),
    (74, 14),
    (75, 14),
    (76, 14),
    (77, 14),
    (78, 14),
]


def movements_from_simulation_events(
    events: list[SimulationEvent],
    persona_name: str = "Isabella Rodriguez",
    *,
    start_step: int = 0,
    step_interval: int = 30,
    route: list[tuple[int, int]] | None = None,
    address: str = "the Ville:Isabella Rodriguez's apartment:bathroom:shower",
) -> list[GenerativeAgentMovement]:
    """Convert architecture-derived simulation events into replay movements."""

    route = route or DEFAULT_ROUTE
    movements: list[GenerativeAgentMovement] = [
        GenerativeAgentMovement(
            step=start_step,
            persona_name=persona_name,
            x=route[0][0],
            y=route[0][1],
            emoji="🧭",
            action="orienting to the ADL scenario",
            address=address,
        )
    ]

    for index, event in enumerate(events, start=1):
        x, y = route[min(index, len(route) - 1)]
        movements.append(
            GenerativeAgentMovement(
                step=start_step + index * step_interval,
                persona_name=persona_name,
                x=x,
                y=y,
                emoji=_emoji_for_event(event),
                action=_action_text_for_event(event),
                address=address,
                chat=_chat_for_event(event),
            )
        )

    return movements


def movements_from_simulation_events_by_agent(
    events: list[SimulationEvent],
    *,
    start_step: int = 0,
    step_interval: int = 30,
) -> list[GenerativeAgentMovement]:
    persona_names = list(dict.fromkeys(event.agent_id for event in events))
    agent_offsets = {agent_id: index * 2 for index, agent_id in enumerate(persona_names)}
    agent_counts = {agent_id: 0 for agent_id in persona_names}
    movements: list[GenerativeAgentMovement] = []

    for index, agent_id in enumerate(persona_names):
        x, y = DEFAULT_ROUTE[0]
        movements.append(
            GenerativeAgentMovement(
                step=start_step,
                persona_name=agent_id,
                x=x,
                y=y + agent_offsets[agent_id],
                emoji="🧭",
                action="orienting to the shared comparison environment",
                address=_address_for_scenario("orientation"),
            )
        )

    for event in events:
        agent_counts[event.agent_id] += 1
        event_index = agent_counts[event.agent_id]
        x, y = DEFAULT_ROUTE[min(event_index, len(DEFAULT_ROUTE) - 1)]
        movements.append(
            GenerativeAgentMovement(
                step=start_step + event_index * step_interval,
                persona_name=event.agent_id,
                x=x,
                y=y + agent_offsets[event.agent_id],
                emoji=_emoji_for_event(event),
                action=_action_text_for_event(event),
                address=_address_for_scenario(event.scenario_id),
                chat=_chat_for_event(event),
            )
        )

    return sorted(movements, key=lambda movement: (movement.step, movement.persona_name))


def ville_movements_from_events(
    events: list[SimulationEvent],
    ville: VilleMap,
) -> tuple[list[GenerativeAgentMovement], list[str]]:
    """Ground event trajectories in real Ville tiles.

    Each movement frame advances one adjacent walkable tile on a collision-aware
    path. After arrival, the step's atomic actions occupy their declared number
    of ticks. Every agent is emitted at every frame, holding position while
    others act, so the replay never has gaps.
    """
    persona_names = list(dict.fromkeys(event.agent_id for event in events))
    offsets = {
        agent_id: ((index % 3) - 1, (index // 3) % 3 - 1)
        for index, agent_id in enumerate(persona_names)
    }
    events_by_agent = {
        agent_id: [event for event in events if event.agent_id == agent_id]
        for agent_id in persona_names
    }

    home = ville.resolve_location(None)
    visited: dict[str, VillePlace] = {}
    # per-persona frame sequences: (x, y, emoji, action, address, chat)
    tracks: dict[str, list[tuple]] = {}
    # support partners appear beside the agent on supported frames:
    # partner persona -> {frame_index: (x, y, action, address)}
    partner_appearances: dict[str, dict[int, tuple]] = {}
    for agent_id in persona_names:
        dx, dy = offsets[agent_id]
        home_tile = ville.interaction_tile(home)
        proposed_home = (home_tile[0] + dx, home_tile[1] + dy)
        position = proposed_home if ville.is_walkable(proposed_home) else home_tile
        frames: list[tuple] = [
            (
                *position,
                "🧭",
                "orienting at home before the daily scenarios",
                home.address,
                None,
            )
        ]
        for event in events_by_agent[agent_id]:
            place = ville.resolve_location(event.location or None)
            visited[place.address] = place
            target = ville.interaction_tile(place, position)
            proposed_target = (target[0] + dx, target[1] + dy)
            if ville.is_walkable(proposed_target):
                target = proposed_target
            if target != position:
                path = ville.shortest_path(position, target)
                for tile in path[1:]:
                    frames.append(
                        (
                            *tile,
                            "🚶",
                            f"walking to {place.arena} for {event.step_id}",
                            place.address,
                            None,
                        )
                    )
                position = path[-1]
            timeline = event.timeline_actions or [
                {
                    "id": f"{event.step_id}_perform",
                    "type": "interact",
                    "label": event.step_label or event.step_id,
                    "duration_ticks": 1,
                }
            ]
            non_move_actions = [
                action for action in timeline if action.get("type") != "move_to"
            ]
            for action_index, action in enumerate(non_move_actions):
                duration = max(1, int(action.get("duration_ticks", 1)))
                for action_tick in range(duration):
                    is_outcome = action_index == len(non_move_actions) - 1
                    frames.append(
                        (
                            *position,
                            _emoji_for_event(event)
                            if is_outcome
                            else _emoji_for_atomic_action(str(action.get("type", "interact"))),
                            (
                                _action_text_for_event(event)
                                if is_outcome
                                else str(action.get("label", action.get("id", event.step_id)))
                            ),
                            place.address,
                            _chat_for_event(event) if is_outcome else None,
                        )
                    )
            if event.support_partner:
                partner = f"{event.support_partner} (support)"
                partner_appearances.setdefault(partner, {})[len(frames) - 1] = (
                    position[0] + 1,
                    position[1] + 1,
                    f"providing {event.support_level} support to {agent_id} "
                    f"at {event.step_id}",
                    place.address,
                )
        tracks[agent_id] = frames

    total_frames = max(len(frames) for frames in tracks.values())
    movements: list[GenerativeAgentMovement] = []
    for agent_id, frames in tracks.items():
        for step in range(total_frames):
            x, y, emoji, action, address, chat = frames[min(step, len(frames) - 1)]
            movements.append(
                GenerativeAgentMovement(
                    step=step,
                    persona_name=agent_id,
                    x=x,
                    y=y,
                    emoji=emoji,
                    action=action,
                    address=address,
                    chat=chat,
                )
            )
    for partner, appearances in partner_appearances.items():
        for step, (x, y, action, address) in appearances.items():
            movements.append(
                GenerativeAgentMovement(
                    step=step,
                    persona_name=partner,
                    x=x,
                    y=y,
                    emoji="🫱",
                    action=action,
                    address=address,
                )
            )
    movements.sort(key=lambda movement: (movement.step, movement.persona_name))
    return movements, sorted(place.arena for place in visited.values())


def _emoji_for_atomic_action(action_type: str) -> str:
    return {
        "observe": "👀",
        "interact": "✋",
        "communicate": "💬",
        "verify": "🔎",
        "wait": "⏳",
    }.get(action_type, "•")


def _emoji_for_event(event: SimulationEvent) -> str:
    if event.replan_triggered:
        return "🔁"
    return ACTION_EMOJI.get(event.action_type, "•")


def _action_text_for_event(event: SimulationEvent) -> str:
    cue_text = ", ".join(event.observed_cues) if event.observed_cues else event.step_id
    prompt_text = (
        f" with prompts: {', '.join(event.active_prompt_conditions)}"
        if event.active_prompt_conditions
        else ""
    )
    if event.completed and event.support_partner:
        return f"completing {event.step_id} with {event.support_partner} support{prompt_text}"
    if event.completed:
        return f"completing {event.step_id} independently{prompt_text}"
    if event.support_partner:
        return (
            f"requesting {event.support_partner} support after bottleneck "
            f"in {event.step_id}{prompt_text}"
        )
    if event.missed_cues:
        return f"pausing at {event.step_id} after missing cues: {', '.join(event.missed_cues)}"
    return f"attempting {cue_text} but encountering an execution bottleneck{prompt_text}"


def _chat_for_event(event: SimulationEvent) -> list[list[str]] | None:
    if event.support_partner and event.completed:
        return [[event.support_partner.title(), "Let's use the next cue and finish this step."]]
    if event.support_partner and not event.completed:
        return [[event.agent_id, f"I need help with {event.step_id}."]]
    if event.replan_triggered:
        return [[event.agent_id, "I need to stop and try this another way."]]
    return None


def _address_for_scenario(scenario_id: str) -> str:
    if "community" in scenario_id or "pharmacy" in scenario_id:
        return "the Ville:pharmacy:front area:counter"
    if "self_care" in scenario_id or "washing" in scenario_id or "tooth" in scenario_id:
        return "the Ville:shared apartment:bathroom:sink"
    return "the Ville:shared environment:main area:task zone"
