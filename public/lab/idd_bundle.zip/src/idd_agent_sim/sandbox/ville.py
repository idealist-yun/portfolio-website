"""Loader for the Generative Agents "the Ville" map.

Reads the sector/arena tile matrices from the cloned reference repository
(`external/generative_agents`) and exposes named places with real tile
coordinates, so scenario `location` fields can be grounded in the actual
sandbox map instead of an abstract route.

Some ADL/IADL locations have no literal counterpart in the Ville (there is
no laundry room, street, or bus). Those map to documented visual proxies:
outdoor mobility renders in Johnson Park, laundry in a house common room,
and market/pharmacy in the Willows store. The proxy is a replay
visualization choice only; simulation logic never depends on it.
"""

from __future__ import annotations

import csv
import heapq
import json
from dataclasses import dataclass
from pathlib import Path

DEFAULT_MATRIX_DIR = Path(__file__).parent / "assets" / "ville_matrix"

# ADL/IADL location vocabulary -> Ville arena vocabulary.
LOCATION_SYNONYMS = {
    "laundry room": "common room",
    "street": "park",
    "bus stop": "park",
    "bus": "park",
    "market": "store",
    "pharmacy": "store",
    "school": "classroom",
}

# Queries that should resolve inside the agent's home sector when possible.
HOME_ARENA_QUERIES = {"kitchen", "bathroom", "bedroom", "common room", "main room"}

# Preferred sector per non-home arena, matching the Ville's landmarks.
PREFERRED_SECTORS = {
    "store": "The Willows Market and Pharmacy",
    "classroom": "Oak Hill College",
    "library": "Oak Hill College",
    "park": "Johnson Park",
    "cafe": "Hobbs Cafe",
    "pub": "The Rose and Crown Pub",
}


@dataclass(frozen=True)
class VillePlace:
    sector: str
    arena: str
    bbox: tuple[int, int, int, int]  # x0, y0, x1, y1 (inclusive tiles)
    center: tuple[int, int]

    @property
    def address(self) -> str:
        return f"the Ville:{self.sector}:{self.arena}"


class VilleMap:
    def __init__(
        self,
        width: int,
        height: int,
        places: list[VillePlace],
        sector_bboxes: dict[str, tuple[int, int, int, int]],
        home_sector: str,
        collision_maze: tuple[tuple[bool, ...], ...] = (),
        place_tiles: dict[str, tuple[tuple[int, int], ...]] | None = None,
    ) -> None:
        self.width = width
        self.height = height
        self.places = places
        self.sector_bboxes = sector_bboxes
        self.home_sector = home_sector
        self.collision_maze = collision_maze
        self.place_tiles = place_tiles or {}

    # -- loading -----------------------------------------------------------

    @classmethod
    def is_available(cls, matrix_dir: str | Path | None = None) -> bool:
        matrix_dir = Path(matrix_dir or DEFAULT_MATRIX_DIR)
        return (matrix_dir / "maze_meta_info.json").exists()

    @classmethod
    def load(cls, matrix_dir: str | Path | None = None) -> "VilleMap":
        matrix_dir = Path(matrix_dir or DEFAULT_MATRIX_DIR)
        meta = json.loads(
            (matrix_dir / "maze_meta_info.json").read_text(encoding="utf-8")
        )
        width, height = int(meta["maze_width"]), int(meta["maze_height"])

        arena_legend = _read_legend(
            matrix_dir / "special_blocks" / "arena_blocks.csv", parts=2
        )
        arena_tiles = _tiles_by_block(
            matrix_dir / "maze" / "arena_maze.csv", width
        )
        places = []
        for block_id, (sector, arena) in arena_legend.items():
            tiles = arena_tiles.get(block_id)
            if not tiles:
                continue
            places.append(
                VillePlace(
                    sector=sector,
                    arena=arena,
                    bbox=_bbox(tiles),
                    center=_center(tiles),
                )
            )

        sector_legend = _read_legend(
            matrix_dir / "special_blocks" / "sector_blocks.csv", parts=1
        )
        sector_tiles = _tiles_by_block(
            matrix_dir / "maze" / "sector_maze.csv", width
        )
        sector_bboxes = {
            legend[0]: _bbox(sector_tiles[block_id])
            for block_id, legend in sector_legend.items()
            if sector_tiles.get(block_id)
        }

        collision_values = _read_matrix(matrix_dir / "maze" / "collision_maze.csv")
        collision_maze = tuple(
            tuple(value != 0 for value in collision_values[row * width : (row + 1) * width])
            for row in range(height)
        )
        place_tiles = {
            place.address: tuple(arena_tiles.get(block_id, ()))
            for block_id, place in zip(
                [block_id for block_id in arena_legend if arena_tiles.get(block_id)],
                places,
            )
        }
        home_sector = _pick_home_sector(places)
        return cls(
            width,
            height,
            places,
            sector_bboxes,
            home_sector,
            collision_maze,
            place_tiles,
        )

    # -- resolution --------------------------------------------------------

    def resolve_location(self, query: str | None) -> VillePlace:
        """Resolve a scenario location name to a Ville place."""
        normalized = (query or "").strip().lower().replace("_", " ")
        normalized = LOCATION_SYNONYMS.get(normalized, normalized)
        if not normalized:
            return self._home_default()

        candidates = [
            place
            for place in self.places
            if normalized in place.arena.lower()
            or place.arena.lower() in normalized
        ]
        if not candidates:
            sector_matches = [
                place
                for place in self.places
                if normalized in place.sector.lower()
            ]
            candidates = sector_matches
        if not candidates:
            return self._home_default()

        if normalized in HOME_ARENA_QUERIES:
            home = [p for p in candidates if p.sector == self.home_sector]
            if home:
                return home[0]
        preferred_sector = PREFERRED_SECTORS.get(normalized)
        if preferred_sector:
            preferred = [p for p in candidates if p.sector == preferred_sector]
            if preferred:
                return preferred[0]
        # deterministic: shortest arena name first (plain "bathroom" beats
        # "Latoya Williams's bathroom"), then alphabetical sector
        return sorted(
            candidates,
            key=lambda p: (len(p.arena), p.sector, p.arena),
        )[0]

    def _home_default(self) -> VillePlace:
        home = [p for p in self.places if p.sector == self.home_sector]
        if home:
            main = [p for p in home if "main room" in p.arena.lower()]
            return main[0] if main else home[0]
        return self.places[0]

    # -- tile navigation -----------------------------------------------------

    def is_walkable(self, tile: tuple[int, int]) -> bool:
        x, y = tile
        return (
            0 <= x < self.width
            and 0 <= y < self.height
            and bool(self.collision_maze)
            and not self.collision_maze[y][x]
        )

    def interaction_tile(
        self,
        place: VillePlace,
        start: tuple[int, int] | None = None,
    ) -> tuple[int, int]:
        candidates = [
            tile for tile in self.place_tiles.get(place.address, ()) if self.is_walkable(tile)
        ]
        if not candidates:
            candidates = [
                (x, y)
                for y in range(place.bbox[1], place.bbox[3] + 1)
                for x in range(place.bbox[0], place.bbox[2] + 1)
                if self.is_walkable((x, y))
            ]
        origin = start or place.center
        return min(
            candidates or [origin],
            key=lambda tile: (
                abs(tile[0] - origin[0]) + abs(tile[1] - origin[1]),
                abs(tile[0] - place.center[0]) + abs(tile[1] - place.center[1]),
                tile,
            ),
        )

    def shortest_path(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
    ) -> list[tuple[int, int]]:
        """Return a deterministic four-neighbour collision-aware tile path."""

        if start == goal:
            return [start]
        if not self.is_walkable(start) or not self.is_walkable(goal):
            return [start]
        frontier: list[tuple[int, int, tuple[int, int]]] = []
        heapq.heappush(frontier, (0, 0, start))
        came_from: dict[tuple[int, int], tuple[int, int] | None] = {start: None}
        cost = {start: 0}
        while frontier:
            _, current_cost, current = heapq.heappop(frontier)
            if current == goal:
                break
            x, y = current
            for neighbor in ((x, y - 1), (x - 1, y), (x + 1, y), (x, y + 1)):
                if not self.is_walkable(neighbor):
                    continue
                next_cost = current_cost + 1
                if next_cost >= cost.get(neighbor, self.width * self.height + 1):
                    continue
                cost[neighbor] = next_cost
                came_from[neighbor] = current
                heuristic = abs(neighbor[0] - goal[0]) + abs(neighbor[1] - goal[1])
                heapq.heappush(frontier, (next_cost + heuristic, next_cost, neighbor))
        if goal not in came_from:
            return [start]
        path = []
        current: tuple[int, int] | None = goal
        while current is not None:
            path.append(current)
            current = came_from[current]
        return list(reversed(path))

    # -- dashboard payload ---------------------------------------------------

    def layout_payload(self, visited: list[str] | None = None) -> dict:
        return {
            "maze": {"width": self.width, "height": self.height},
            "navigation": "collision_aware_four_neighbor",
            "home_sector": self.home_sector,
            "sectors": [
                {"name": name, "bbox": list(bbox)}
                for name, bbox in sorted(self.sector_bboxes.items())
            ],
            "arenas": [
                {
                    "name": place.arena,
                    "sector": place.sector,
                    "bbox": list(place.bbox),
                    "center": list(place.center),
                }
                for place in self.places
            ],
            "visited": visited or [],
        }


def _read_legend(path: Path, parts: int) -> dict[int, tuple[str, ...]]:
    legend: dict[int, tuple[str, ...]] = {}
    with path.open(encoding="utf-8") as file:
        for row in csv.reader(file):
            if not row or not row[0].strip():
                continue
            block_id = int(row[0].strip())
            fields = tuple(field.strip() for field in row[2 : 2 + parts])
            if len(fields) == parts:
                legend[block_id] = fields
    return legend


def _tiles_by_block(path: Path, width: int) -> dict[int, list[tuple[int, int]]]:
    values = _read_matrix(path)
    tiles: dict[int, list[tuple[int, int]]] = {}
    for index, value in enumerate(values):
        if value == 0:
            continue
        tiles.setdefault(value, []).append((index % width, index // width))
    return tiles


def _read_matrix(path: Path) -> list[int]:
    return [
        int(token)
        for token in path.read_text(encoding="utf-8").replace("\n", ",").split(",")
        if token.strip()
    ]


def _bbox(tiles: list[tuple[int, int]]) -> tuple[int, int, int, int]:
    xs = [x for x, _ in tiles]
    ys = [y for _, y in tiles]
    return (min(xs), min(ys), max(xs), max(ys))


def _center(tiles: list[tuple[int, int]]) -> tuple[int, int]:
    xs = sorted(x for x, _ in tiles)
    ys = sorted(y for _, y in tiles)
    return (xs[len(xs) // 2], ys[len(ys) // 2])


def _pick_home_sector(places: list[VillePlace]) -> str:
    """First sector (alphabetical) with the most complete home arena set."""
    by_sector: dict[str, set[str]] = {}
    for place in places:
        arena = place.arena.lower()
        for kind in ("kitchen", "bathroom", "bedroom"):
            if kind in arena:
                by_sector.setdefault(place.sector, set()).add(kind)
    ranked = sorted(
        by_sector.items(),
        key=lambda item: (-len(item[1]), item[0]),
    )
    for sector, kinds in ranked:
        if {"kitchen", "bathroom"} <= kinds:
            return sector
    return places[0].sector if places else "the Ville"
