from dataclasses import dataclass, field

from .agent import Agent
from .architecture import IDDAgentArchitecture
from .skills import SkillLibrary
from .testbed import Scenario
from .world import World


@dataclass(frozen=True)
class SimulationEvent:
    agent_id: str
    scenario_id: str
    step_id: str
    action_type: str
    completed: bool
    unmet_need: float
    retrieved_skills: list[str]
    support_partner: str | None
    observed_cues: list[str]
    missed_cues: list[str]
    plan_substeps: int
    emotion_level: float
    emotional_shift: float
    replan_triggered: bool
    explanation: str
    visible_objects: list[str] = field(default_factory=list)
    visible_people: list[str] = field(default_factory=list)
    blocked_objects: list[str] = field(default_factory=list)
    environment_cues: list[str] = field(default_factory=list)
    environment_success: bool = True
    environment_missing_objects: list[str] = field(default_factory=list)
    environment_missing_people: list[str] = field(default_factory=list)
    environment_occupied_objects: list[str] = field(default_factory=list)
    environment_feedback: str = ""
    long_term_plan_id: str = ""
    scenario_step_index: int = 0
    scenario_total_steps: int = 0
    long_term_plan_steps: list[str] = field(default_factory=list)
    support_strategy: str = ""
    replan_count: int = 0
    retrieved_memory_count: int = 0
    short_term_memory_count: int = 0
    associative_memory_count: int = 0
    spatial_memory_count: int = 0
    reflection_memory_count: int = 0
    reflection_triggered: bool = False
    reflection_summary: str = ""
    reflection_adjustment: str = ""
    scratch_memory_used: bool = False
    loop_stages: list[str] = field(default_factory=list)
    plan_rationale: str = ""
    fatigue: float = 0.0
    sensory_load: float = 0.0
    regulation_load: float = 0.0
    routine_stability: float = 1.0
    state_pressure: float = 0.0
    support_relationship_closeness: float = 0.0
    support_memory_bonus: float = 0.0
    support_rationale: str = ""
    adaptive_estimate: float = 0.0
    support_need_estimate: float = 0.0
    learning_signal: str = ""
    adaptive_delta: float = 0.0
    support_need_delta: float = 0.0
    profile_update_reason: str = ""
    bottleneck_evidence_count: int = 0
    care_gap_count: int = 0
    vineland_evidence_count: int = 0
    vineland_prerequisite_gap_count: int = 0
    vineland_prerequisite_uncertainty_count: int = 0
    active_prompt_conditions: list[str] = field(default_factory=list)
    related_vineland_skill_codes: list[str] = field(default_factory=list)
    constraint_source: str = "profile_baseline"
    support_calibration_source: str = "hand_specified"
    demand_dimensions: dict[str, float] = field(default_factory=dict)
    dimension_capacities: dict[str, float] = field(default_factory=dict)
    exceeded_dimensions: list[str] = field(default_factory=list)
    binding_dimension: str = ""
    support_level: str = "monitoring"
    support_domain_coverage: float = 0.0
    location: str = ""
    step_label: str = ""
    timeline_actions: list[dict] = field(default_factory=list)


@dataclass(frozen=True)
class CharacterInsightEvent:
    """Scenario-level personality-system output for one agent."""

    agent_id: str
    scenario_id: str
    insight_summary: str
    referenced_dimensions: list[str]
    completion_rate: float
    support_reliance: float
    mean_emotion: float
    mood: str
    traits: dict[str, float]
    conflicts: dict[str, float]
    growth_notes: list[str]
    long_term_record_count: int
    long_term_retention_reasons: list[str]


@dataclass(frozen=True)
class SimulationResult:
    events: list[SimulationEvent] = field(default_factory=list)
    insights: list[CharacterInsightEvent] = field(default_factory=list)

    def summary(self) -> str:
        if not self.events:
            return "events=0, task_goal_completion=0.000, bottlenecks=0"
        completed = sum(1 for event in self.events if event.completed)
        bottlenecks = len(self.events) - completed
        completion = completed / len(self.events)
        return (
            f"events={len(self.events)}, "
            f"task_goal_completion={completion:.3f}, "
            f"bottlenecks={bottlenecks}"
        )


class Simulation:
    def __init__(
        self,
        agents: list[Agent],
        world: World,
        scenarios: list[Scenario],
        skills: SkillLibrary | None = None,
    ) -> None:
        self.agents = agents
        self.world = world
        self.scenarios = scenarios
        self.skills = skills or SkillLibrary.baseline()

    @classmethod
    def from_config(cls, config: dict) -> "Simulation":
        agents = [Agent.from_config(agent) for agent in config["agents"]]
        world = World.from_config(config["world"])
        scenarios = [Scenario.from_config(scenario) for scenario in config["scenarios"]]
        return cls(agents=agents, world=world, scenarios=scenarios)

    def run(self) -> SimulationResult:
        events: list[SimulationEvent] = []
        insights: list[CharacterInsightEvent] = []

        for agent in self.agents:
            architecture = IDDAgentArchitecture(agent, self.skills)
            for scenario in self.scenarios:
                for step in scenario.steps:
                    result = architecture.execute_step(scenario, step, self.world)
                    events.append(
                        SimulationEvent(
                            agent_id=agent.agent_id,
                            scenario_id=scenario.scenario_id,
                            step_id=step.step_id,
                            action_type=result.decision.action_type,
                            completed=result.decision.completed,
                            unmet_need=result.decision.unmet_need,
                            retrieved_skills=[skill.name for skill in result.retrieved_skills],
                            support_partner=result.support.partner,
                            observed_cues=result.observation.visible_cues,
                            missed_cues=result.observation.missed_cues,
                            visible_objects=result.observation.visible_objects,
                            visible_people=result.observation.visible_people,
                            blocked_objects=result.observation.blocked_objects,
                            environment_cues=result.observation.environment_cues,
                            plan_substeps=result.adjusted_plan.substep_count,
                            emotion_level=result.emotion_level,
                            emotional_shift=result.emotional_shift,
                            replan_triggered=result.replan_triggered,
                            explanation=result.decision.explanation,
                            environment_success=result.environment_feedback.success,
                            environment_missing_objects=list(
                                result.environment_feedback.missing_objects
                            ),
                            environment_missing_people=list(
                                result.environment_feedback.missing_people
                            ),
                            environment_occupied_objects=list(
                                result.environment_feedback.occupied_objects
                            ),
                            environment_feedback=result.environment_feedback.explanation,
                            long_term_plan_id=result.adjusted_plan.scenario_plan_id,
                            scenario_step_index=result.adjusted_plan.scenario_step_index,
                            scenario_total_steps=result.adjusted_plan.scenario_total_steps,
                            long_term_plan_steps=result.adjusted_plan.long_term_step_ids,
                            support_strategy=result.adjusted_plan.support_strategy,
                            replan_count=result.replan_count,
                            retrieved_memory_count=result.adjusted_plan.retrieved_memory_count,
                            short_term_memory_count=result.adjusted_plan.short_term_memory_count,
                            associative_memory_count=result.adjusted_plan.associative_memory_count,
                            spatial_memory_count=result.adjusted_plan.spatial_memory_count,
                            reflection_memory_count=(
                                result.adjusted_plan.reflection_memory_count
                            ),
                            reflection_triggered=result.reflection.triggered,
                            reflection_summary=result.reflection.summary,
                            reflection_adjustment=result.reflection.adjustment,
                            scratch_memory_used=result.adjusted_plan.scratch_memory_used,
                            loop_stages=result.loop_stages,
                            plan_rationale=result.adjusted_plan.rationale,
                            fatigue=result.humanoid_state.fatigue,
                            sensory_load=result.humanoid_state.sensory_load,
                            regulation_load=result.humanoid_state.regulation_load,
                            routine_stability=result.humanoid_state.routine_stability,
                            state_pressure=result.humanoid_state.state_pressure,
                            support_relationship_closeness=result.support.relationship_closeness,
                            support_memory_bonus=result.support.memory_bonus,
                            support_rationale=result.support.rationale,
                            adaptive_estimate=result.functional_state.adaptive_estimate_for(
                                scenario.domain
                            ),
                            support_need_estimate=result.functional_state.support_need_for(
                                scenario.domain
                            ),
                            learning_signal=result.learning_signal.signal_type,
                            adaptive_delta=result.learning_signal.adaptive_delta,
                            support_need_delta=result.learning_signal.support_need_delta,
                            profile_update_reason=result.learning_signal.reason,
                            bottleneck_evidence_count=result.functional_state.evidence_count_for(
                                scenario.domain
                            ),
                            care_gap_count=result.functional_state.care_gap_count_for(
                                scenario.domain
                            ),
                            vineland_evidence_count=result.constraints.vineland_evidence_count,
                            vineland_prerequisite_gap_count=(
                                result.constraints.vineland_prerequisite_gap_count
                            ),
                            vineland_prerequisite_uncertainty_count=(
                                result.constraints.vineland_prerequisite_uncertainty_count
                            ),
                            active_prompt_conditions=list(
                                result.constraints.active_prompt_conditions
                            ),
                            related_vineland_skill_codes=list(
                                result.constraints.related_vineland_skill_codes
                            ),
                            constraint_source=result.constraints.constraint_source,
                            support_calibration_source=result.support.calibration_source,
                            demand_dimensions={
                                gap.dimension: gap.demand
                                for gap in result.dimensional_gaps
                            },
                            dimension_capacities={
                                gap.dimension: gap.capacity
                                for gap in result.dimensional_gaps
                            },
                            exceeded_dimensions=list(result.exceeded_dimensions),
                            binding_dimension=result.binding_dimension,
                            support_level=result.support.support_level,
                            support_domain_coverage=result.support.domain_coverage,
                            location=step.location or "",
                            step_label=step.label,
                            timeline_actions=step.timeline_payload(),
                        )
                    )
                conclusion = architecture.conclude_scenario(scenario)
                insights.append(
                    CharacterInsightEvent(
                        agent_id=agent.agent_id,
                        scenario_id=scenario.scenario_id,
                        insight_summary=conclusion.insight.summary,
                        referenced_dimensions=list(
                            conclusion.insight.referenced_dimensions
                        ),
                        completion_rate=conclusion.insight.completion_rate,
                        support_reliance=conclusion.insight.support_reliance,
                        mean_emotion=conclusion.insight.mean_emotion,
                        mood=str(conclusion.character.current_state.get("mood", "")),
                        traits=dict(conclusion.character.traits),
                        conflicts=dict(conclusion.character.conflicts),
                        growth_notes=list(conclusion.new_growth_notes),
                        long_term_record_count=len(conclusion.long_term_records),
                        long_term_retention_reasons=list(
                            dict.fromkeys(
                                record.retention_reason
                                for record in conclusion.long_term_records
                            )
                        ),
                    )
                )

        return SimulationResult(events=events, insights=insights)
