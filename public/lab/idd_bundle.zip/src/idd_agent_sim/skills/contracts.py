from dataclasses import dataclass, field


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    domain: str = "general"
    clinical_tags: tuple[str, ...] = ()
    environment_requirements: tuple[str, ...] = ()
    source_reference: str = "proposal"
    validation_status: str = "scaffold"
    version: int = 1


@dataclass(frozen=True)
class TaskContext:
    task_description: str
    domain: str
    required_skill: str | None = None
    available_affordances: frozenset[str] = field(default_factory=frozenset)
    observed_cues: tuple[str, ...] = ()
    missed_cues: tuple[str, ...] = ()
    emotion_level: float = 0.0
    accessible_skill_names: frozenset[str] = field(default_factory=frozenset)

    def missing_requirements_for(self, skill: Skill) -> tuple[str, ...]:
        return tuple(
            requirement
            for requirement in skill.environment_requirements
            if requirement not in self.available_affordances
        )

    def profile_allows(self, skill: Skill) -> bool:
        if not self.accessible_skill_names:
            return True
        return skill.name in self.accessible_skill_names


@dataclass(frozen=True)
class SkillOutcome:
    skill_name: str
    succeeded: bool
    missing_requirements: tuple[str, ...] = ()
    execution_errors: tuple[str, ...] = ()
    feedback: str = ""

    @property
    def is_error_free(self) -> bool:
        return (
            self.succeeded
            and not self.missing_requirements
            and not self.execution_errors
        )


@dataclass(frozen=True)
class SkillLifecycleRecord:
    skill: Skill
    action: str
    rationale: str
    source_outcome: SkillOutcome | None = None
