"""Scenario-domain to skill-domain relations.

Skill definitions are grounded in two clinical anchor domains (`self_care`
for personal/domestic adaptive behavior, `activity` for community-facing
behavior). ADL/IADL scenario domains from the proposal map onto those anchors
so the same clinically grounded skills stay retrievable without duplicating
skill definitions per scenario domain.
"""

RELATED_SKILL_DOMAINS: dict[str, tuple[str, ...]] = {
    # Meals span personal routines (preparing, eating) and safety-critical
    # verification (medication), so both anchors apply.
    "meal": ("self_care", "activity"),
    "household_tasks": ("self_care",),
    "mobility": ("activity",),
    "community": ("activity",),
}


def skill_domains_for(scenario_domain: str) -> frozenset[str]:
    """All skill domains whose skills apply in the given scenario domain."""
    return frozenset(
        ("general", scenario_domain)
        + RELATED_SKILL_DOMAINS.get(scenario_domain, ())
    )
