"""Embedding interface for semantic skill retrieval.

The proposal retrieves task-specific skills by semantic similarity:
``TopK({a : sim(task, a) > delta}, K)``. This module provides the pluggable
embedding boundary for that rule.

The default `HashedNgramEmbedder` is a deterministic, dependency-free local
model: it hashes word tokens and character trigrams into a fixed-size vector.
It approximates surface/lexical similarity rather than deep semantics, which
keeps tests reproducible and offline. When the project is ready to depend on
a real embedding service or local model, implement `EmbeddingModel` and pass
it to `SkillRetriever`.
"""

import hashlib
import math
from typing import Protocol


class EmbeddingModel(Protocol):
    def embed(self, text: str) -> tuple[float, ...]:
        """Return a fixed-size normalized vector for the text."""
        ...


def cosine_similarity(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


class HashedNgramEmbedder:
    """Deterministic offline embedder over word tokens and char trigrams."""

    def __init__(self, dimensions: int = 256) -> None:
        self.dimensions = dimensions
        self._cache: dict[str, tuple[float, ...]] = {}

    def embed(self, text: str) -> tuple[float, ...]:
        cached = self._cache.get(text)
        if cached is not None:
            return cached
        vector = [0.0] * self.dimensions
        for feature in self._features(text):
            digest = hashlib.md5(feature.encode("utf-8")).digest()
            index = int.from_bytes(digest[:4], "big") % self.dimensions
            # second hash byte decides sign to reduce collision bias
            sign = 1.0 if digest[4] % 2 == 0 else -1.0
            vector[index] += sign
        norm = math.sqrt(sum(value * value for value in vector))
        if norm > 0:
            vector = [value / norm for value in vector]
        result = tuple(vector)
        self._cache[text] = result
        return result

    @staticmethod
    def _features(text: str) -> list[str]:
        normalized = text.lower().replace("_", " ").replace("-", " ")
        words = [token for token in normalized.split() if token]
        features = [f"w:{word}" for word in words]
        for word in words:
            padded = f" {word} "
            features.extend(
                f"g:{padded[i:i + 3]}" for i in range(len(padded) - 2)
            )
        return features
