from idd_agent_sim.skills.contracts import Skill, SkillOutcome, TaskContext


class SkillExecutor:
    def verify_prerequisites(self, skill: Skill, context: TaskContext) -> SkillOutcome:
        missing = context.missing_requirements_for(skill)
        return SkillOutcome(
            skill_name=skill.name,
            succeeded=not missing,
            missing_requirements=missing,
            feedback=(
                "All environmental prerequisites are available."
                if not missing
                else "Skill cannot run because environmental prerequisites are missing."
            ),
        )
