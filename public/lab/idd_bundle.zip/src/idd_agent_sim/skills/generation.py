from dataclasses import replace

from idd_agent_sim.skills.contracts import (
    Skill,
    SkillLifecycleRecord,
    SkillOutcome,
    TaskContext,
)


class SkillLifecycle:
    """Reference-grounded scaffold for skill generation, update, and save.

    This deliberately records generated skills as unvalidated candidates. The
    project can later attach an LLM/code executor, but the research code should
    not treat generated skills as clinically validated just because they exist.
    """

    def generate_candidate(self, context: TaskContext, rationale: str) -> SkillLifecycleRecord:
        skill_name = self._candidate_name(context)
        skill = Skill(
            name=skill_name,
            description=f"Candidate skill for: {context.task_description}",
            domain=context.domain,
            clinical_tags=(context.domain,),
            source_reference="voyager_style_generation_candidate",
            validation_status="generated_unvalidated",
        )
        return SkillLifecycleRecord(skill=skill, action="generate", rationale=rationale)

    def update_after_failure(self, skill: Skill, outcome: SkillOutcome) -> SkillLifecycleRecord:
        updated = replace(
            skill,
            description=f"{skill.description} Updated after feedback: {outcome.feedback}",
            source_reference=f"{skill.source_reference}+voyager_feedback_update",
            validation_status="updated_unvalidated",
            version=skill.version + 1,
        )
        return SkillLifecycleRecord(
            skill=updated,
            action="update",
            rationale="Execution feedback indicated that the skill needs revision.",
            source_outcome=outcome,
        )

    def save_after_success(self, skill: Skill, outcome: SkillOutcome) -> SkillLifecycleRecord:
        status = (
            "technically_validated"
            if outcome.is_error_free
            else "save_rejected_execution_not_clean"
        )
        saved = replace(skill, validation_status=status)
        return SkillLifecycleRecord(
            skill=saved,
            action="save" if outcome.is_error_free else "reject_save",
            rationale=(
                "Execution completed without missing prerequisites or errors."
                if outcome.is_error_free
                else "Skill was not saved because execution feedback was not clean."
            ),
            source_outcome=outcome,
        )

    def _candidate_name(self, context: TaskContext) -> str:
        base = context.required_skill or context.task_description
        normalized = "_".join(
            token
            for token in base.lower().replace("-", " ").split()
            if token.isalnum()
        )
        return f"generated_{normalized or context.domain}_skill"
