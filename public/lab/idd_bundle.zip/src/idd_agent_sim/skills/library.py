from idd_agent_sim.skills.contracts import Skill, SkillLifecycleRecord, SkillOutcome, TaskContext
from idd_agent_sim.skills.execution import SkillExecutor
from idd_agent_sim.skills.generation import SkillLifecycle
from idd_agent_sim.skills.registry import SkillRegistry
from idd_agent_sim.skills.retrieval import SkillRetriever


class SkillLibrary:
    def __init__(self, skills: list[Skill] | None = None) -> None:
        self.registry = SkillRegistry(skills or [])
        self.executor = SkillExecutor()
        self.lifecycle = SkillLifecycle()

    @classmethod
    def baseline(cls) -> "SkillLibrary":
        return cls(skills=SkillRegistry.baseline().skills)

    @property
    def skills(self) -> list[Skill]:
        return self.registry.skills

    def retrieve(self, domain: str, required_skill: str | None = None) -> list[Skill]:
        return SkillRetriever(self.skills).retrieve(domain, required_skill)

    def retrieve_for_context(self, context: TaskContext, top_k: int = 5) -> list[Skill]:
        return SkillRetriever(self.skills).retrieve_for_context(context, top_k)

    def verify_prerequisites(self, skill: Skill, context: TaskContext) -> SkillOutcome:
        return self.executor.verify_prerequisites(skill, context)

    def generate_candidate(self, context: TaskContext, rationale: str) -> SkillLifecycleRecord:
        return self.lifecycle.generate_candidate(context, rationale)

    def update_after_failure(self, skill: Skill, outcome: SkillOutcome) -> SkillLifecycleRecord:
        return self.lifecycle.update_after_failure(skill, outcome)

    def save_after_success(self, skill: Skill, outcome: SkillOutcome) -> SkillLifecycleRecord:
        record = self.lifecycle.save_after_success(skill, outcome)
        if outcome.is_error_free:
            saved = self.registry.save(record.skill)
            return SkillLifecycleRecord(
                skill=saved,
                action=record.action,
                rationale=record.rationale,
                source_outcome=record.source_outcome,
            )
        return record
