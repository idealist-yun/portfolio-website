from dataclasses import replace

from idd_agent_sim.skills.contracts import Skill


class SkillRegistry:
    def __init__(self, skills: list[Skill]) -> None:
        self._skills = {skill.name: skill for skill in skills}

    @classmethod
    def baseline(cls) -> "SkillRegistry":
        return cls(
            skills=[
                Skill("check_prerequisites", "Check whether required objects and people are available."),
                Skill(
                    "replan_after_block",
                    "Create a smaller next step when execution is blocked.",
                    clinical_tags=("planning", "flexibility"),
                    source_reference="voyager_feedback_loop",
                ),
                Skill(
                    "request_support",
                    "Ask the highest-weight support partner for help.",
                    clinical_tags=("support_need", "communication"),
                    environment_requirements=("support_available",),
                    source_reference="proposal_sis_a_support",
                ),
                Skill(
                    "locate_object",
                    "Search expected places for a needed object.",
                    "self_care",
                    clinical_tags=("daily_living_skills", "attention"),
                ),
                Skill(
                    "sequence_task",
                    "Follow a known multi-step routine.",
                    "self_care",
                    clinical_tags=("daily_living_skills", "sequencing"),
                ),
                Skill(
                    "sustain_task",
                    "Continue an action until a clear stopping cue.",
                    "self_care",
                    clinical_tags=("daily_living_skills", "attention"),
                ),
                Skill(
                    "navigate_environment",
                    "Move through a familiar public environment.",
                    "activity",
                    clinical_tags=("motor_skills", "community"),
                ),
                Skill(
                    "verify_information",
                    "Confirm instructions or medication details.",
                    "activity",
                    clinical_tags=("communication", "safety"),
                ),
            ]
        )

    @property
    def skills(self) -> list[Skill]:
        return list(self._skills.values())

    def get(self, name: str) -> Skill | None:
        return self._skills.get(name)

    def save(self, skill: Skill) -> Skill:
        previous = self._skills.get(skill.name)
        saved = (
            replace(skill, version=previous.version + 1)
            if previous is not None
            else skill
        )
        self._skills[saved.name] = saved
        return saved
