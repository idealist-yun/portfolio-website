from idd_agent_sim.skills.contracts import Skill, TaskContext
from idd_agent_sim.skills.domains import skill_domains_for
from idd_agent_sim.skills.embedding import (
    EmbeddingModel,
    HashedNgramEmbedder,
    cosine_similarity,
)


def _tokens(text: str) -> set[str]:
    return {
        token
        for token in text.lower().replace("_", " ").replace("-", " ").split()
        if token
    }


class SkillRetriever:
    """Semantic Top-K skill retrieval.

    Implements the proposal's retrieval rule
    ``TopK({a : sim(task, a) > delta}, K)`` over an embedding model. General
    skills are always included; task-specific skills are ranked by semantic
    similarity plus clinical/contextual boosts. The default embedder is a
    deterministic offline approximation (see `skills/embedding.py`).
    """

    def __init__(
        self,
        skills: list[Skill],
        embedder: EmbeddingModel | None = None,
        similarity_threshold: float = 0.05,
    ) -> None:
        self.skills = skills
        self.embedder = embedder or HashedNgramEmbedder()
        self.similarity_threshold = similarity_threshold

    def retrieve(self, domain: str, required_skill: str | None = None) -> list[Skill]:
        applicable = skill_domains_for(domain)
        general = [skill for skill in self.skills if skill.domain == "general"]
        task_specific = [
            skill
            for skill in self.skills
            if skill.domain in applicable or skill.name == required_skill
        ]
        return self._dedupe(general + task_specific)

    def retrieve_for_context(self, context: TaskContext, top_k: int = 5) -> list[Skill]:
        """Retrieve proposal-relevant skills that can run in the current environment."""
        applicable = skill_domains_for(context.domain)
        general = [skill for skill in self.skills if skill.domain == "general"]
        candidates = [
            skill
            for skill in self.skills
            if skill.domain != "general"
            and (skill.domain in applicable or skill.name == context.required_skill)
        ]

        task_vector = self.embedder.embed(self._task_text(context))
        runnable = [
            skill
            for skill in candidates
            if context.profile_allows(skill)
            and not context.missing_requirements_for(skill)
        ]
        scored = [
            (self._semantic_similarity(task_vector, skill), skill)
            for skill in runnable
        ]
        # Proposal rule: keep skills above the similarity threshold; the
        # step's required skill is always eligible.
        eligible = [
            (similarity, skill)
            for similarity, skill in scored
            if similarity > self.similarity_threshold
            or skill.name == context.required_skill
        ]
        ranked = sorted(
            eligible,
            key=lambda pair: self._score(pair[1], pair[0], context),
            reverse=True,
        )

        runnable_general = [
            skill
            for skill in general
            if context.profile_allows(skill)
            and not context.missing_requirements_for(skill)
        ]
        return self._dedupe(
            runnable_general + [skill for _, skill in ranked[:top_k]]
        )

    def semantic_similarity(self, context: TaskContext, skill: Skill) -> float:
        """Similarity between the task context and one skill (0-1-ish)."""
        return self._semantic_similarity(
            self.embedder.embed(self._task_text(context)),
            skill,
        )

    def _semantic_similarity(
        self,
        task_vector: tuple[float, ...],
        skill: Skill,
    ) -> float:
        skill_vector = self.embedder.embed(self._skill_text(skill))
        return max(0.0, cosine_similarity(task_vector, skill_vector))

    @staticmethod
    def _task_text(context: TaskContext) -> str:
        return " ".join(
            (
                context.task_description,
                context.required_skill or "",
                " ".join(context.observed_cues),
                " ".join(context.missed_cues),
            )
        )

    @staticmethod
    def _skill_text(skill: Skill) -> str:
        return f"{skill.name} {skill.description} {' '.join(skill.clinical_tags)}"

    def _score(self, skill: Skill, similarity: float, context: TaskContext) -> float:
        score = similarity
        if skill.name == context.required_skill:
            score += 3.0
        if skill.domain == context.domain:
            score += 1.0
        elif skill.domain in skill_domains_for(context.domain):
            score += 0.5

        cue_tokens = _tokens(" ".join(context.observed_cues + context.missed_cues))
        tag_tokens = set(skill.clinical_tags)
        if cue_tokens and tag_tokens:
            score += 0.5 * len(cue_tokens & tag_tokens)

        if context.emotion_level >= 4 and "support_need" in skill.clinical_tags:
            score += 0.5
        return score

    def _dedupe(self, skills: list[Skill]) -> list[Skill]:
        seen: set[str] = set()
        retrieved: list[Skill] = []
        for skill in skills:
            if skill.name in seen:
                continue
            retrieved.append(skill)
            seen.add(skill.name)
        return retrieved
