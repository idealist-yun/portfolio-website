"""Multidimensional task-demand definitions.

A scenario step's demand can be a single scalar (backward compatible) or a
vector over named demand dimensions. Dimensional demand makes bottleneck
localization identifiable: instead of "demand 0.72 exceeded capacity 0.41",
events can state which functional dimension (e.g. receptive language) exceeded
the profile's capacity on that dimension.

Dimensions are anchored to VABS/K-Vineland-II structure so profile-side
capacities can be derived from the same clinical scaffold.
"""

DEMAND_DIMENSIONS = (
    "receptive_language",
    "expressive_language",
    "sequencing",
    "sustained_attention",
    "motor",
    "social",
)


def validate_demand_dimensions(dimensions: dict[str, float]) -> dict[str, float]:
    unknown = set(dimensions) - set(DEMAND_DIMENSIONS)
    if unknown:
        raise ValueError(
            f"Unknown demand dimensions {sorted(unknown)}. "
            f"Expected a subset of {DEMAND_DIMENSIONS}."
        )
    return {name: float(value) for name, value in dimensions.items()}


def scalar_demand(dimensions: dict[str, float]) -> float:
    """Aggregate dimensional demand into the scalar used by the step loop.

    The binding-constraint rule: overall difficulty is the hardest
    dimensional requirement, since any single unmet dimension gates
    completion.
    """
    return max(dimensions.values()) if dimensions else 0.0
