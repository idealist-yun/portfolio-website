from dataclasses import dataclass, field
from typing import Any

from idd_agent_sim.testbed.demand import scalar_demand, validate_demand_dimensions


ATOMIC_ACTION_TYPES = (
    "move_to",
    "observe",
    "interact",
    "communicate",
    "verify",
    "wait",
)


@dataclass(frozen=True)
class ScenarioAction:
    """One observable action on a scenario's shared time axis."""

    action_id: str
    action_type: str
    label: str
    duration_ticks: int = 1
    target: str | None = None
    location: str | None = None

    @classmethod
    def from_config(
        cls,
        config: dict[str, Any],
        *,
        default_id: str,
        default_location: str | None = None,
    ) -> "ScenarioAction":
        action_type = str(config.get("type", "interact"))
        if action_type not in ATOMIC_ACTION_TYPES:
            raise ValueError(f"Unknown atomic action type: {action_type}")
        return cls(
            action_id=str(config.get("id", default_id)),
            action_type=action_type,
            label=str(config.get("label", config.get("id", default_id))),
            duration_ticks=max(1, int(config.get("duration_ticks", 1))),
            target=(str(config["target"]) if config.get("target") else None),
            location=(
                str(config["location"])
                if config.get("location")
                else default_location
            ),
        )


@dataclass(frozen=True)
class ScenarioStep:
    step_id: str
    label: str
    demand: float
    required_skill: str | None = None
    required_objects: tuple[str, ...] = ()
    required_people: tuple[str, ...] = ()
    location: str | None = None
    demand_dimensions: dict[str, float] = field(default_factory=dict)
    actions: tuple[ScenarioAction, ...] = ()

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "ScenarioStep":
        raw_demand = config["demand"]
        if isinstance(raw_demand, dict):
            dimensions = validate_demand_dimensions(raw_demand)
            demand = scalar_demand(dimensions)
        else:
            dimensions = {}
            demand = float(raw_demand)
        step_id = str(config["id"])
        location = config.get("location")
        raw_actions = list(config.get("actions", ()))
        actions = (
            tuple(
                ScenarioAction.from_config(
                    action,
                    default_id=f"{step_id}_{index}",
                    default_location=location,
                )
                for index, action in enumerate(raw_actions, start=1)
            )
            if raw_actions
            else _default_actions(
                step_id=step_id,
                label=str(config.get("label", config["id"])),
                required_skill=config.get("required_skill"),
                required_objects=tuple(config.get("required_objects", ())),
                required_people=tuple(config.get("required_people", ())),
                location=location,
            )
        )
        return cls(
            step_id=step_id,
            label=str(config.get("label", config["id"])),
            demand=demand,
            required_skill=config.get("required_skill"),
            required_objects=tuple(config.get("required_objects", ())),
            required_people=tuple(config.get("required_people", ())),
            location=location,
            demand_dimensions=dimensions,
            actions=actions,
        )

    def timeline_payload(self) -> list[dict[str, Any]]:
        return [
            {
                "id": action.action_id,
                "type": action.action_type,
                "label": action.label,
                "duration_ticks": action.duration_ticks,
                "target": action.target,
                "location": action.location,
            }
            for action in self.actions
        ]


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    domain: str
    description: str
    steps: list[ScenarioStep]

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "Scenario":
        return cls(
            scenario_id=str(config["id"]),
            domain=str(config["domain"]),
            description=str(config.get("description", "")),
            steps=[ScenarioStep.from_config(step) for step in config["steps"]],
        )


def _default_actions(
    *,
    step_id: str,
    label: str,
    required_skill: str | None,
    required_objects: tuple[str, ...],
    required_people: tuple[str, ...],
    location: str | None,
) -> tuple[ScenarioAction, ...]:
    """Compile legacy coarse steps into an inspectable action timeline."""

    actions: list[ScenarioAction] = []
    if location:
        actions.append(
            ScenarioAction(
                action_id=f"{step_id}_move",
                action_type="move_to",
                label=f"Move to {location}",
                duration_ticks=1,
                target=location,
                location=location,
            )
        )
    cue_target = next(iter(required_objects or required_people), None)
    actions.append(
        ScenarioAction(
            action_id=f"{step_id}_observe",
            action_type="observe",
            label=f"Check {cue_target or label}",
            duration_ticks=1,
            target=cue_target,
            location=location,
        )
    )
    primary_type = {
        "request_support": "communicate",
        "verify_information": "verify",
        "locate_object": "observe",
    }.get(str(required_skill), "interact")
    actions.append(
        ScenarioAction(
            action_id=f"{step_id}_perform",
            action_type=primary_type,
            label=label,
            duration_ticks=2 if primary_type == "interact" else 1,
            target=cue_target,
            location=location,
        )
    )
    if primary_type != "verify":
        actions.append(
            ScenarioAction(
                action_id=f"{step_id}_verify",
                action_type="verify",
                label=f"Confirm {label} done",
                duration_ticks=1,
                target=cue_target,
                location=location,
            )
        )
    return tuple(actions)
