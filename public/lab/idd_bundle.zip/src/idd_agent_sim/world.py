from dataclasses import dataclass

from .environment import EnvironmentState
from .profiles import FunctionalProfile


@dataclass(frozen=True)
class World:
    """Shared environment parameters for one simulation run."""

    support_availability: float
    environment_state: EnvironmentState | None = None

    @classmethod
    def from_config(cls, config: dict) -> "World":
        environment = config.get("environment", {})
        state = EnvironmentState(
            available_objects=frozenset(environment.get("available_objects", ())),
            occupied_objects=frozenset(environment.get("occupied_objects", ())),
            available_people=frozenset(environment.get("available_people", ())),
            locations=dict(environment.get("locations", {})),
        ) if environment else None
        return cls(
            support_availability=float(config["support_availability"]),
            environment_state=state,
        )

    def supported_completion(
        self,
        unmet_need: float,
        profile: FunctionalProfile,
        support_partner: str | None,
    ) -> bool:
        if unmet_need == 0:
            return True
        if support_partner is None:
            return False
        support_weight = profile.support_need_profile().partner_weights.get(support_partner, 0.0)
        return support_weight * self.support_availability >= unmet_need

    def environment_for(self, profile: FunctionalProfile) -> EnvironmentState:
        if self.environment_state is not None:
            return self.environment_state
        available_people = (
            frozenset(profile.support_need_profile().partner_weights)
            if self.support_availability > 0
            else frozenset()
        )
        return EnvironmentState(available_people=available_people)
